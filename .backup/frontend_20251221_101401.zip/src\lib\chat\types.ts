// Chat Command System Types

import type { SemanticCommand } from "./semanticEngine";

export type CommandType = 
  | "query"       // "show groups with X", "find all grid > 500"
  | "set"         // "set grid to 600 for groups 1-8"
  | "semantic"    // "30% more aggressive", "make it safer" - handled by semantic engine
  | "progression" // "create progression from 600 to 3000 fibonacci"
  | "copy"        // "copy power settings from group 1 to groups 2-5"
  | "compare"     // "compare grid between group 1 and group 5"
  | "reset"       // "reset group 3 to defaults"
  | "formula"     // "apply formula grid * 1.5 to groups 2-8"
  | "unknown";

export interface ParsedCommand {
  type: CommandType;
  target: CommandTarget;
  params: Record<string, any>;
  raw: string;
  semantic?: SemanticCommand; // For semantic commands - rule-based NL operations
}

export interface CommandTarget {
  engines?: string[];      // ["A", "B", "C"]
  groups?: number[];       // [1, 2, 3, 4, 5]
  logics?: string[];       // ["POWER", "REPOWER"]
  field?: string;          // "grid", "initial_lot", "trail_value"
}

export interface CommandResult {
  success: boolean;
  message: string;
  changes?: FieldChange[];
  queryResult?: QueryResult;
}

export interface FieldChange {
  engine: string;
  group: number;
  logic: string;
  field: string;
  oldValue: any;
  newValue: any;
}

export interface QueryResult {
  matches: QueryMatch[];
  summary: string;
  // Navigation metadata for hybrid mode
  navigationTargets?: {
    engines?: string[];
    groups?: number[];
    logics?: string[];
  };
  isSnapshot?: boolean;
}
export interface QueryMatch {
  engine: string;
  group: number;
  logic: string;
  field: string;
  value: any;
}

// Progression types
export type ProgressionType = "linear" | "fibonacci" | "exponential" | "custom";

export interface ProgressionParams {
  type: ProgressionType;
  startValue: number;
  endValue?: number;
  steps: number;
  factor?: number;        // For exponential/custom
  customFormula?: string; // For custom: "prev * 1.5 + 100"
}

// Chat message types
export interface ChatMessage {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: number;
  command?: ParsedCommand;
  result?: CommandResult;
}
