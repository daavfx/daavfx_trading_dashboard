import React, { createContext, useContext, useState, useEffect } from "react";

export interface SettingsState {
  theme: "dark" | "light" | "system";
  accentColor: string;
  density: "compact" | "comfortable" | "spacious";
  fontSize: number;
  animations: boolean;
  autosave: boolean;
  autosaveInterval: number;
  notifications: boolean;
  soundEffects: boolean;
  confirmOnClose: boolean;
  keyboardShortcuts: boolean;
  showTooltips: boolean;
  gridLines: boolean;
  highlightChanges: boolean;
  autoApproveTransactions: boolean;
}

export const defaultSettings: SettingsState = {
  theme: "dark",
  accentColor: "gold",
  density: "comfortable",
  fontSize: 13,
  animations: true,
  autosave: true,
  autosaveInterval: 30,
  notifications: true,
  soundEffects: false,
  confirmOnClose: true,
  keyboardShortcuts: true,
  showTooltips: true,
  gridLines: true,
  highlightChanges: true,
  autoApproveTransactions: false,
};

interface SettingsContextType {
  settings: SettingsState;
  updateSetting: <K extends keyof SettingsState>(key: K, value: SettingsState[K]) => void;
  saveSettings: () => void;
  resetSettings: () => void;
  hasChanges: boolean;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export function SettingsProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<SettingsState>(defaultSettings);
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem("daavfx-settings");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setSettings({ ...defaultSettings, ...parsed });
      } catch (e) {
        console.error("Failed to parse settings", e);
      }
    }
  }, []);

  const updateSetting = <K extends keyof SettingsState>(key: K, value: SettingsState[K]) => {
    setSettings((prev) => ({ ...prev, [key]: value }));
    setHasChanges(true);
  };

  const saveSettings = () => {
    localStorage.setItem("daavfx-settings", JSON.stringify(settings));
    setHasChanges(false);
  };

  const resetSettings = () => {
    setSettings(defaultSettings);
    setHasChanges(true);
  };

  return (
    <SettingsContext.Provider value={{ settings, updateSetting, saveSettings, resetSettings, hasChanges }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error("useSettings must be used within a SettingsProvider");
  }
  return context;
}
