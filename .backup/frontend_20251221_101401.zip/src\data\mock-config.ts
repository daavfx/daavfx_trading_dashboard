import { MTConfig, EngineConfig, GroupConfig, LogicConfig, SessionConfig, TimeFiltersConfig, NewsFilterConfig, GeneralConfig, RiskManagementConfig, LogicReference } from "@/types/mt-config";

const mockRiskManagement: RiskManagementConfig = {
  spread_filter_enabled: false,
  max_spread_points: 25.0,
  equity_stop_enabled: false,
  equity_stop_value: 35.0,
  drawdown_stop_enabled: false,
  max_drawdown_percent: 35.0
};

const mockTimeFilters: TimeFiltersConfig = {
  priority_settings: {
    news_filter_overrides_session: false,
    session_filter_overrides_news: true
  },
  sessions: Array.from({ length: 7 }, (_, i) => ({
    session_number: i + 1,
    enabled: false,
    day: i % 7,
    start_hour: 9,
    start_minute: 30,
    end_hour: 17,
    end_minute: 0,
    action: "TriggerAction_StopEA_KeepTrades",
    auto_restart: true,
    restart_mode: "Restart_Immediate",
    restart_bars: 0,
    restart_minutes: 0,
    restart_pips: 0
  }))
};

const mockNewsFilter: NewsFilterConfig = {
  enabled: false,
  api_key: "",
  api_url: "https://www.jblanked.com/news/api/calendar/",
  countries: "US,GB,EU",
  impact_level: 3,
  minutes_before: 30,
  minutes_after: 30,
  action: "TriggerAction_StopEA_KeepTrades"
};

const mockGeneralConfig: GeneralConfig = {
  license_key: "MOCK-LICENSE-KEY",
  license_server_url: "https://license.daavfx.com",
  require_license: true,
  license_check_interval: 3600,
  config_file_name: "DAAVFX_Config.json",
  config_file_is_common: true,
  allow_buy: true,
  allow_sell: true,
  enable_logs: false,
  compounding_enabled: false,
  compounding_type: "Compound_Balance",
  compounding_target: 40.0,
  compounding_increase: 2.0,
  restart_policy_power: "Restart_Default",
  restart_policy_non_power: "Restart_Default",
  close_non_power_on_power_close: false,
  hold_timeout_bars: 10,
  magic_number: 777,
  max_slippage_points: 30.0,
  risk_management: mockRiskManagement,
  time_filters: mockTimeFilters,
  news_filter: mockNewsFilter
};

const createMockLogic = (name: string, id: string, grid: number, lot: number): LogicConfig => ({
  logic_name: name,
  logic_id: id,
  enabled: true,
  initial_lot: lot,
  multiplier: 1.5,
  grid: grid,
  trail_method: "Points",
  trail_value: 50,
  trail_start: 20,
  trail_step: 10,
  trail_step_method: "Step_Points",
  close_targets: "Logic_A_Power,Logic_A_Repower,Logic_A_Scalp,Logic_A_Stopper",
  order_count_reference: "Logic_Self",
  reset_lot_on_restart: true,
  use_tp: true,
  tp_mode: "TPSL_Points",
  tp_value: 500,
  use_sl: true,
  sl_mode: "TPSL_Points",
  sl_value: 1000,
  // Reverse/Hedge (V17.04+)
  reverse_enabled: false,
  hedge_enabled: false,
  reverse_scale: 100.0,
  hedge_scale: 50.0,
  reverse_reference: "Logic_None" as LogicReference,
  hedge_reference: "Logic_None" as LogicReference,
  // Trail Step Advanced (V17.04+)
  trail_step_mode: "TrailStepMode_Auto",
  trail_step_cycle: 1,
  trail_step_balance: 0.0,
  // Close Partial
  close_partial: false,
  close_partial_cycle: 3,
  close_partial_mode: "PartialMode_Balanced",
  close_partial_balance: "PartialBalance_Balanced",
  close_partial_trail_step_mode: "TrailStepMode_Auto"
});

const createMockGroup = (groupNum: number): GroupConfig => {
  // Vary grid values to test queries like "grid > 500"
  // Group 1: 300, Group 2: 600, Group 3: 400, Group 4: 800...
  const baseGrid = groupNum % 2 === 0 ? 600 + (groupNum * 50) : 300 + (groupNum * 20);
  
  // Get engine prefix (A for now, will be overridden by createMockEngine)
  const getLogicName = (base: string, enginePrefix: string) => 
    enginePrefix === "" ? base : `${enginePrefix}${base}`;
  
  return {
    group_number: groupNum,
    enabled: true,
    // Group-level Reverse/Hedge controls (V17.04+)
    reverse_mode: false,
    hedge_mode: false,
    hedge_reference: "Logic_None" as LogicReference,
    entry_delay_bars: 0,
    logics: [
      // All 7 logics per group
      createMockLogic("Power", `Power_G${groupNum}`, baseGrid, 0.01),
      createMockLogic("Repower", `Repower_G${groupNum}`, baseGrid * 0.9, 0.02),
      createMockLogic("Scalper", `Scalper_G${groupNum}`, baseGrid * 0.8, 0.02),
      createMockLogic("Stopper", `Stopper_G${groupNum}`, baseGrid * 1.2, 0.01),
      createMockLogic("STO", `STO_G${groupNum}`, baseGrid * 1.1, 0.015),
      createMockLogic("SCA", `SCA_G${groupNum}`, baseGrid * 0.95, 0.015),
      createMockLogic("RPO", `RPO_G${groupNum}`, baseGrid * 1.05, 0.015),
    ]
  };
};

const createMockEngine = (id: "A" | "B" | "C", name: string): EngineConfig => ({
  engine_id: id,
  engine_name: name,
  max_power_orders: 5,
  groups: Array.from({ length: 20 }, (_, i) => createMockGroup(i + 1)) // All 20 groups
});

export const mockFullConfig: MTConfig = {
  version: "1.0.0",
  platform: "MT5",
  timestamp: new Date().toISOString(),
  total_inputs: 11000,
  last_saved_at: new Date().toISOString(),
  last_saved_platform: "MT5",
  current_set_name: "Mock_Config.set",
  general: mockGeneralConfig,
  engines: [
    createMockEngine("A", "Engine A"),
    createMockEngine("B", "Engine B"),
    createMockEngine("C", "Engine C")
  ]
};
