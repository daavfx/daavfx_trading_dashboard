import { useRef, useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Send, 
  Bot, 
  User, 
  Command, 
  ChevronLeft, 
  ChevronRight, 
  Sparkles,
  Trash2,
  Zap,
  ChevronUp,
  ChevronDown,
  Search,
  Sliders,
  TrendingUp,
  Copy as CopyIcon,
  GitCompare,
  Terminal,
  ShieldAlert,
  Camera,
  LineChart
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { useChatCommands } from "@/hooks/useChatCommands";
import { commandExecutor } from "@/lib/chat";
import { ChatMessageContent } from "@/components/chat/ChatMessageContent";
import { QuickActionsPanel } from "@/components/chat/QuickActionsPanel";
import type { MTConfig } from "@/types/mt-config";

interface ChatPanelProps {
  config?: MTConfig | null;
  onConfigChange?: (config: MTConfig) => void;
  onNavigate?: (target: { engines?: string[]; groups?: number[]; logics?: string[] }) => void;
}

interface CommandTemplate {
  label: string;
  example: string;
}

// Get styled background based on risk level in message content
function getPlanStyle(content: string): string {
  if (content.includes("CRITICAL RISK") || content.includes("🔴")) {
    return "bg-red-500/10 border border-red-500/30 text-foreground";
  }
  if (content.includes("HIGH RISK") || content.includes("🟠")) {
    return "bg-orange-500/10 border border-orange-500/30 text-foreground";
  }
  if (content.includes("MEDIUM RISK") || content.includes("🟡")) {
    return "bg-yellow-500/10 border border-yellow-500/30 text-foreground";
  }
  if (content.includes("LOW RISK") || content.includes("🟢")) {
    return "bg-green-500/10 border border-green-500/30 text-foreground";
  }
  // Default assistant style
  return "bg-card border border-border/60 text-foreground";
}

export function ChatPanel({ config = null, onConfigChange, onNavigate }: ChatPanelProps) {
  const [collapsed, setCollapsed] = useState(false);
  const [showGuide, setShowGuide] = useState(false);
  const [showQuickActions, setShowQuickActions] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  
  const commandGroups: { title: string; icon: any; items: CommandTemplate[] }[] = [
    {
      title: "Query",
      icon: Search,
      items: [
        { label: "show grid", example: "show grid for all groups" },
        { label: "find high grid", example: "show all groups with grid > 500" },
        { label: "analyze power", example: "analyze power settings for group 1" },
      ],
    },
    {
      title: "Set",
      icon: Sliders,
      items: [
        { label: "set grid", example: "set grid to 600 for groups 1-8" },
        { label: "set lot", example: "set initial_lot to 0.02 for power" },
        { label: "bulk update", example: "set multiplier to 1.5 where grid > 500" },
      ],
    },
    {
      title: "Progression",
      icon: TrendingUp,
      items: [
        { label: "fibonacci", example: "create progression for grid from 600 to 3000 fibonacci groups 1-8" },
        { label: "linear", example: "create linear progression for lot from 0.01 to 0.08 groups 1-8" },
        { label: "exponential", example: "create exponential progression for lot from 0.01 factor 1.5 groups 1-8" },
      ],
    },
    {
      title: "Risk & Safety",
      icon: ShieldAlert,
      items: [
        { label: "equity stop", example: "set equity_stop_value to 35%" },
        { label: "max drawdown", example: "set max_drawdown_percent to 25%" },
        { label: "news filter", example: "enable news_filter for all" },
      ],
    },
    {
      title: "Copy / Compare",
      icon: CopyIcon,
      items: [
        { label: "copy settings", example: "copy power settings from group 1 to groups 2-8" },
        { label: "compare", example: "compare grid between group 1 and group 5" },
      ],
    },
    {
      title: "Meta",
      icon: Terminal,
      items: [
        { label: "apply plan", example: "apply" },
        { label: "cancel plan", example: "cancel" },
        { label: "full guide", example: "help" },
      ],
    },
  ];
  
  const {
    messages,
    suggestions,
    inputValue,
    setInputValue,
    sendMessage,
    applySuggestion,
    clearHistory
  } = useChatCommands({
    config,
    onConfigChange: onConfigChange || (() => {}),
    onNavigate
  });

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage(inputValue);
    }
  };

  if (collapsed) {
    return (
      <aside className="h-full border-l border-border bg-background-elevated flex flex-col items-center py-4">
        <button 
          onClick={() => setCollapsed(false)} 
          className="p-2 text-muted-foreground hover:text-foreground rounded-md hover:bg-muted/30 transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
        <div className="mt-4 writing-mode-vertical text-[10px] text-muted-foreground tracking-widest uppercase font-medium">
          Ryiuk
        </div>
        <div className="mt-2">
          <Sparkles className="w-3.5 h-3.5 text-primary" />
        </div>
      </aside>
    );
  }

  return (
    <aside className="h-full border-l border-border bg-background-elevated flex flex-col">
      {/* Header */}
      <div className="h-12 border-b border-border flex items-center justify-between px-4 shrink-0">
        <div className="flex items-center gap-2.5 min-w-0 overflow-hidden">
          <div className="p-1.5 rounded-md bg-gradient-to-br from-amber-500/20 to-yellow-500/10 shrink-0">
            <Bot className="w-4 h-4 text-amber-500" />
          </div>
          <div className="min-w-0 flex flex-col">
            <span className="text-xs font-semibold text-foreground truncate">Ryiuk</span>
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-success animate-pulse shrink-0" />
              <span className="text-[10px] text-muted-foreground truncate">
                {config ? "Config loaded" : "No config"}
              </span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1 shrink-0 ml-2">
          <button
            onClick={() => setShowQuickActions((prev) => !prev)}
            className={cn(
              "p-1.5 rounded-md transition-colors",
              showQuickActions 
                ? "bg-amber-500/20 text-amber-400"
                : "text-muted-foreground hover:text-foreground hover:bg-muted/30"
            )}
            title="Quick Actions"
          >
            <Zap className="w-3.5 h-3.5" />
          </button>
          <button 
            onClick={clearHistory}
            className="p-1.5 text-muted-foreground hover:text-foreground rounded-md hover:bg-muted/30 transition-colors"
            title="Clear history"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setShowGuide((prev) => !prev)}
            className="px-1.5 py-1 text-[10px] text-muted-foreground hover:text-foreground rounded-md hover:bg-muted/30 transition-colors"
            title="Command guide"
          >
            /help
          </button>
          <button 
            onClick={() => setCollapsed(true)} 
            className="p-1.5 text-muted-foreground hover:text-foreground rounded-md hover:bg-muted/30 transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {showGuide && (
        <div className="px-4 py-2 border-b border-border/60 bg-muted/10 text-[10px]">
          <div className="flex items-center justify-between mb-1.5">
            <span className="font-semibold text-foreground">Command guide</span>
            <span className="text-muted-foreground">Type / or # before commands if you like</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {commandGroups.map((group) => (
              <div key={group.title} className="space-y-1">
                <div className="flex items-center gap-1.5 mb-1">
                  {group.icon && <group.icon className="w-3 h-3 text-primary/70" />}
                  <div className="uppercase tracking-wide text-[9px] text-muted-foreground font-semibold">{group.title}</div>
                </div>
                <div className="flex flex-col gap-1">
                  {group.items.map((item) => (
                    <button
                      key={item.example}
                      onClick={() => setInputValue(item.example)}
                      className="text-left text-[10px] px-2 py-1 rounded bg-muted/40 text-muted-foreground hover:bg-muted/70 hover:text-foreground transition-colors truncate"
                    >
                      {item.example}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Actions Panel */}
      {showQuickActions && (
        <div className="border-b border-border/60">
          <QuickActionsPanel
            config={config}
            onConfigChange={onConfigChange || (() => {})}
            onMessage={(msg) => {
              // Add message to chat
              const assistantMessage = {
                id: `assistant-${Date.now()}`,
                role: "assistant" as const,
                content: msg,
                timestamp: Date.now()
              };
              // We need to trigger this through the hook
              sendMessage(`/quick-action-result: ${msg}`);
            }}
          />
        </div>
      )}

      {/* Messages */}
      <ScrollArea className="flex-1" ref={scrollRef}>
        <div className="p-4 space-y-3">
          <AnimatePresence>
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className={cn("flex gap-2.5", msg.role === "user" && "flex-row-reverse")}
              >
                <div className={cn(
                  "w-6 h-6 rounded-lg flex items-center justify-center shrink-0",
                  msg.role === "assistant" ? "bg-amber-500/10" : 
                  msg.role === "system" ? "bg-primary/10" : "bg-accent/10"
                )}>
                  {msg.role === "user" 
                    ? <User className="w-3 h-3 text-accent" />
                    : <Bot className="w-3 h-3 text-amber-500" />
                  }
                </div>
                <div className={cn(
                  "flex-1 max-w-[95%] px-3 py-2 rounded-lg text-xs leading-relaxed",
                  msg.role === "user" 
                    ? "bg-accent/10 border border-accent/20 text-foreground"
                    : msg.role === "system"
                    ? "bg-muted/30 border border-border/40 text-muted-foreground"
                    : getPlanStyle(msg.content)
                )}>
                  <ChatMessageContent 
                  message={msg} 
                  onSend={sendMessage} 
                  onNavigate={onNavigate} 
                  onCompose={setInputValue}
                />
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </ScrollArea>

      {/* Suggestions */}
      {suggestions.length > 0 && (
        <div className="px-4 py-2 border-t border-border/50 bg-muted/20">
          <div className="text-[9px] text-muted-foreground uppercase tracking-wider mb-1.5">Suggestions</div>
          <div className="flex flex-wrap gap-1">
            {suggestions.map((suggestion, idx) => (
              <button
                key={idx}
                onClick={() => applySuggestion(suggestion)}
                className="text-[10px] px-2 py-1 rounded bg-muted/40 text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors truncate max-w-full"
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="p-3 border-t border-border">
        <div className="relative">
          <Command className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="set grid to 600 for groups 1-8..."
            className="pl-9 pr-10 h-9 text-xs input-refined"
          />
          <Button
            size="icon"
            onClick={() => sendMessage(inputValue)}
            disabled={!inputValue.trim()}
            className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7 bg-gradient-to-r from-amber-500 to-yellow-500 text-black hover:from-amber-400 hover:to-yellow-400"
          >
            <Send className="w-3.5 h-3.5" />
          </Button>
        </div>
        <div className="mt-2 flex flex-wrap gap-1.5 text-[9px] text-muted-foreground/60">
          <button onClick={() => setInputValue("show grid for all groups")} className="hover:text-muted-foreground">show grid</button>
          <span>·</span>
          <button onClick={() => setInputValue("set grid to 500 for groups 1-8")} className="hover:text-muted-foreground">set grid</button>
          <span>·</span>
          <button onClick={() => setInputValue("create progression for grid fibonacci groups 1-8")} className="hover:text-muted-foreground">fibonacci</button>
        </div>
      </div>
    </aside>
  );
}
