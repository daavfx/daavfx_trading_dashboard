
import { useCallback } from "react";
import { invoke } from "@tauri-apps/api/core";
import { save, open } from "@tauri-apps/plugin-dialog";
import { toast } from "sonner";
import type { MTConfig, Platform } from "@/types/mt-config";
import { useMTConfig } from "./useMTConfig";

export function useMTFileOps(platform: Platform) {
  // Ensure platform is uppercase to match backend expectations (MT4/MT5)
  const mtPlatform = platform.toUpperCase() as Platform;
  const { config, loadConfig, saveConfig } = useMTConfig(mtPlatform);

  const exportSetFile = useCallback(async () => {
    if (!config) {
      toast.error("No configuration loaded to export");
      return;
    }

    try {
      const filePath = await save({
        filters: [{
          name: 'MT4/MT5 Set File',
          extensions: ['set']
        }],
        defaultPath: `${mtPlatform}_Config.set`
      });

      if (!filePath) return; // User cancelled

      await invoke("export_set_file", {
        config,
        filePath,
        platform: mtPlatform,
        includeOptimizationHints: true
      });

      toast.success("Successfully exported .set file");
    } catch (err) {
      console.error("Export error:", err);
      toast.error(`Failed to export .set file: ${err}`);
    }
  }, [config, mtPlatform]);

  const importSetFile = useCallback(async () => {
    try {
      const filePath = await open({
        filters: [{
          name: 'MT4/MT5 Set File',
          extensions: ['set']
        }]
      });

      if (!filePath) return; // User cancelled

      const importedConfig = await invoke<MTConfig>("import_set_file", {
        filePath
      });

      // Update the current config with the imported one
      // We assume the user wants to overwrite the current active config
      try {
        await saveConfig(importedConfig);
        await loadConfig(); // Refresh state
        toast.success("Successfully imported .set file");
      } catch (saveErr) {
        const errorMsg = saveErr as string;
        // If path not set, try to auto-detect and retry
        if (typeof errorMsg === 'string' && errorMsg.includes("path not set")) {
          try {
            toast.info(`Auto-detecting ${mtPlatform} config path...`);
            const cmd = mtPlatform === "MT4" ? "get_default_mt4_path" : "get_default_mt5_path";
            const defaultPath = await invoke<string>(cmd);
            
            await invoke("set_mt_path", { platform: mtPlatform, path: defaultPath });
            toast.success(`Found and set ${mtPlatform} path: ${defaultPath}`);
            
            // Retry save
            await saveConfig(importedConfig);
            await loadConfig();
            toast.success("Successfully imported .set file");
            return;
          } catch (detectErr) {
            console.error("Auto-detect failed:", detectErr);
            toast.error(`Could not auto-detect ${mtPlatform} path. Please configure it in Settings.`);
            return;
          }
        }
        throw saveErr;
      }
    } catch (err) {
      console.error("Import error:", err);
      // Avoid double toast if it was already handled above
      if (err instanceof Error || typeof err === 'string') {
         // Check if we already showed a specific error toast
         const msg = String(err);
         if (!msg.includes("Could not auto-detect")) {
            toast.error(`Failed to import .set file: ${err}`);
         }
      }
    }
  }, [saveConfig, loadConfig, mtPlatform]);

  const exportJsonFile = useCallback(async () => {
    if (!config) {
      toast.error("No configuration loaded to export");
      return;
    }

    try {
      const filePath = await save({
        filters: [{
          name: 'JSON Configuration',
          extensions: ['json']
        }],
        defaultPath: `${mtPlatform}_Config.json`
      });

      if (!filePath) return; // User cancelled

      await invoke("export_json_file", {
        config,
        filePath
      });

      toast.success("Successfully exported JSON file");
    } catch (err) {
      console.error("Export error:", err);
      toast.error(`Failed to export JSON file: ${err}`);
    }
  }, [config, mtPlatform]);

  const importJsonFile = useCallback(async () => {
    try {
      const filePath = await open({
        filters: [{
          name: 'JSON Configuration',
          extensions: ['json']
        }]
      });

      if (!filePath) return; // User cancelled

      const importedConfig = await invoke<MTConfig>("import_json_file", {
        filePath
      });

      await saveConfig(importedConfig);
      await loadConfig(); // Refresh state

      toast.success("Successfully imported JSON file");
    } catch (err) {
      console.error("Import error:", err);
      toast.error(`Failed to import JSON file: ${err}`);
    }
  }, [saveConfig, loadConfig]);

  return {
    exportSetFile,
    importSetFile,
    exportJsonFile,
    importJsonFile
  };
}
