
import { Search, Download, Upload, FileDown, Save, Undo, Redo, Settings, HelpCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { useMTFileOps } from "@/hooks/useMTFileOps";
import { useNavigate } from "react-router-dom";

export type Platform = "mt4" | "mt5" | "python" | "c" | "cpp" | "rust";

interface TopBarProps {
  onSaveToVault: () => void;
  onOpenVaultManager: () => void;
  platform: Platform;
  onPlatformChange: (platform: Platform) => void;
  onOpenSettings: () => void;
  lastSavedLabel?: string;
}

const platforms: { id: Platform; label: string }[] = [
  { id: "mt4", label: "MT4" },
  { id: "mt5", label: "MT5" },
  { id: "python", label: "PY" },
  { id: "c", label: "C" },
  { id: "cpp", label: "C++" },
  { id: "rust", label: "RS" },
];

const platformColors: Record<Platform, { active: string; inactive: string }> = {
  mt4: { active: "bg-platform-mt4 text-background", inactive: "text-platform-mt4" },
  mt5: { active: "bg-platform-mt5 text-background", inactive: "text-platform-mt5" },
  python: { active: "bg-platform-python text-background", inactive: "text-platform-python" },
  c: { active: "bg-platform-c text-background", inactive: "text-platform-c" },
  cpp: { active: "bg-platform-cpp text-background", inactive: "text-platform-cpp" },
  rust: { active: "bg-platform-rust text-background", inactive: "text-platform-rust" },
};

export function TopBar({ onSaveToVault, onOpenVaultManager, platform, onPlatformChange, onOpenSettings, lastSavedLabel }: TopBarProps) {
  // Map UI platform (lowercase) to Hook platform (uppercase)
  const mtPlatform = (platform === "mt5" ? "MT5" : "MT4");
  const { exportSetFile, importSetFile, exportJsonFile, importJsonFile } = useMTFileOps(mtPlatform);
  const navigate = useNavigate();

  return (
    <header className="h-14 border-b border-border bg-background-elevated flex items-center justify-between px-4 gap-4">
      {/* Logo */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded bg-primary/15 flex items-center justify-center border border-primary/20">
            <span className="text-primary font-semibold text-sm">D</span>
          </div>
          <div>
            <span className="font-semibold text-sm tracking-tight text-foreground">DAAVFX</span>
            <span className="text-[10px] text-muted-foreground ml-2">Config Studio</span>
          </div>
        </div>

        {/* Platform Selector */}
        <div className="flex items-center bg-background rounded border border-border/60">
          {platforms.map((p) => (
            <button
              key={p.id}
              onClick={() => onPlatformChange(p.id)}
              className={cn(
                "px-2.5 py-1.5 text-[11px] font-medium transition-colors",
                platform === p.id
                  ? platformColors[p.id].active
                  : cn("text-muted-foreground hover:text-foreground", "hover:bg-muted/50")
              )}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* Search */}
      <div className="flex-1 max-w-md">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            placeholder="Search inputs..."
            className="pl-9 h-8 text-sm input-refined"
          />
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-1">
        {lastSavedLabel && (
          <div className="hidden md:flex flex-col items-end mr-3 text-[9px] text-muted-foreground">
            <span>{lastSavedLabel}</span>
          </div>
        )}
        
        {/* Import Menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8 px-2.5 text-xs text-muted-foreground hover:text-foreground">
              <Upload className="w-3.5 h-3.5 mr-1.5" />
              Import
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem className="text-xs" onClick={importSetFile}>
              Import .set file (MT4/MT5)
            </DropdownMenuItem>
            <DropdownMenuItem className="text-xs" onClick={importJsonFile}>
              Import .json file
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Export Menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8 px-2.5 text-xs text-muted-foreground hover:text-foreground">
              <Download className="w-3.5 h-3.5 mr-1.5" />
              Export
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem className="text-xs" onClick={exportSetFile}>
              Export .set file (MT4/MT5)
            </DropdownMenuItem>
            <DropdownMenuItem className="text-xs" onClick={exportJsonFile}>
              Export .json file
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8 px-2.5 text-xs text-muted-foreground hover:text-foreground">
              <FileDown className="w-3.5 h-3.5 mr-1.5" />
              Load
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-44">
            <DropdownMenuItem className="text-xs" onClick={importSetFile}>Load from file...</DropdownMenuItem>
            <DropdownMenuItem className="text-xs" onClick={onOpenVaultManager}>Load from vault</DropdownMenuItem>
            <DropdownMenuItem className="text-xs">Load preset</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <div className="w-px h-5 bg-border mx-1" />

        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
          <Undo className="w-3.5 h-3.5" />
        </Button>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
          <Redo className="w-3.5 h-3.5" />
        </Button>

        <div className="w-px h-5 bg-border mx-1" />

        <Button 
          onClick={onSaveToVault}
          size="sm"
          className="h-8 px-3 text-xs bg-primary/15 text-primary border border-primary/25 hover:bg-primary/25"
        >
          <Save className="w-3.5 h-3.5 mr-1.5" />
          Save to Vault
        </Button>

        <Button 
          variant="ghost" 
          size="icon" 
          onClick={onOpenSettings}
          className="h-8 w-8 text-muted-foreground hover:text-foreground ml-1"
        >
          <Settings className="w-4 h-4" />
        </Button>

        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => navigate("/help")}
          className="h-8 px-2.5 text-xs text-muted-foreground hover:text-foreground"
        >
          <HelpCircle className="w-3.5 h-3.5 mr-1" />
          Help
        </Button>
      </div>
    </header>
  );
}
