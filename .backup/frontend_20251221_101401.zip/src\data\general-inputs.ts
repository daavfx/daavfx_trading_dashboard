
// This file contains the input mappings extracted from the MT4 codebase.
// Source: c:\Users\neto_\Desktop\trading_5.0\daavfx_trading_ecosystem_4.0\main_ecosystem_trading\trading_algorithms\mt4_implementation\input_mapping\general\

const generateSessionFields = () => {
  const sessions = [];
  for (let i = 1; i <= 7; i++) {
    sessions.push(
      // Session Header (Visual separator)
      { id: `session_${i}_header`, mt4_variable: "", type: "header", label: `=== SESSION ${i} ===`, default: "", description: "" },
      
      // Session Fields
      { id: `session_${i}_enabled`, mt4_variable: `gInput_Session${i}Enabled`, type: "bool", default: false, description: `Enable/disable Session ${i}` },
      { id: `session_${i}_day`, mt4_variable: `gInput_Session${i}Day`, type: "int", default: i % 7, description: `Day of week (0=Sunday, 1=Monday, ..., 6=Saturday)`, min: 0, max: 6 },
      { id: `session_${i}_start_hour`, mt4_variable: `gInput_Session${i}StartHour`, type: "int", default: 9, description: `Session ${i} start hour (0-23)`, unit: "hour", min: 0, max: 23 },
      { id: `session_${i}_start_minute`, mt4_variable: `gInput_Session${i}StartMinute`, type: "int", default: 30, description: `Session ${i} start minute (0-59)`, unit: "min", min: 0, max: 59 },
      { id: `session_${i}_end_hour`, mt4_variable: `gInput_Session${i}EndHour`, type: "int", default: 17, description: `Session ${i} end hour (0-23)`, unit: "hour", min: 0, max: 23 },
      { id: `session_${i}_end_minute`, mt4_variable: `gInput_Session${i}EndMinute`, type: "int", default: 0, description: `Session ${i} end minute (0-59)`, unit: "min", min: 0, max: 59 },
      { id: `session_${i}_action`, mt4_variable: `gInput_Session${i}Action`, type: "enum", default: "TriggerAction_StopEA_KeepTrades", description: `Action to take during session ${i} window`, options: ["TriggerAction_StopEA_KeepTrades", "TriggerAction_StopEA_CloseTrades", "TriggerAction_Continue"] },
      { id: `session_${i}_auto_restart`, mt4_variable: `gInput_Session${i}AutoRestart`, type: "bool", default: true, description: `Auto-restart EA after session ${i} ends` },
      { id: `session_${i}_restart_mode`, mt4_variable: `gInput_Session${i}RestartMode`, type: "enum", default: "Restart_Immediate", description: `When to restart after session ${i} ends`, options: ["Restart_Immediate", "Restart_AfterBars", "Restart_AfterMinutes", "Restart_AfterPips"] },
      { id: `session_${i}_restart_bars`, mt4_variable: `gInput_Session${i}RestartBars`, type: "int", default: 0, description: `Bars to wait after session ${i}`, unit: "bars" },
      { id: `session_${i}_restart_minutes`, mt4_variable: `gInput_Session${i}RestartMinutes`, type: "int", default: 0, description: `Minutes to wait after session ${i}`, unit: "min" },
      { id: `session_${i}_restart_pips`, mt4_variable: `gInput_Session${i}RestartPips`, type: "double", default: 0.0, description: `Pips movement required after session ${i}`, unit: "pips" }
    );
  }
  return sessions;
};

export const generalInputs = {
  risk_management: {
    fields: [
      { id: "spread_filter_enabled", mt4_variable: "gInput_UseSpreadFilter", type: "bool", default: false, description: "Enable spread filter to stop trading on wide spreads" },
      { id: "max_spread_points", mt4_variable: "gInput_MaxSpreadPoints", type: "double", default: 25.0, description: "Maximum allowed spread in points", unit: "points" },
      { id: "equity_stop_enabled", mt4_variable: "gInput_UseEquityStop", type: "bool", default: false, description: "Enable equity-based stop loss" },
      { id: "equity_stop_value", mt4_variable: "gInput_EquityStopValue", type: "double", default: 35.0, description: "Equity stop value (percentage or absolute)", unit: "%" },
      { id: "drawdown_stop_enabled", mt4_variable: "gInput_UseDrawdownStop", type: "bool", default: false, description: "Enable maximum drawdown stop" },
      { id: "max_drawdown_percent", mt4_variable: "gInput_MaxDrawdownPercent", type: "double", default: 35.0, description: "Maximum allowed drawdown percentage", unit: "%" }
    ]
  },
  time_filters: {
    fields: [
      { id: "priority_header", mt4_variable: "", type: "header", label: "=== PRIORITY SETTINGS ===", default: "", description: "" },
      { id: "news_filter_overrides_session", mt4_variable: "gInput_NewsFilterOverridesSession", type: "bool", default: false, description: "When true, news filter takes priority over session filter" },
      { id: "session_filter_overrides_news", mt4_variable: "gInput_SessionFilterOverridesNews", type: "bool", default: true, description: "When true, session filter takes priority over news filter (DEFAULT)" },
      ...generateSessionFields()
    ]
  },
  compounding: {
    fields: [
      { id: "enabled", mt4_variable: "gInput_Input_Compounding", type: "bool", default: false, description: "Enable dynamic lot compounding based on account growth" },
      { id: "type", mt4_variable: "gInput_Input_CompoundingType", type: "enum", default: "Compound_Balance", description: "Reference for calculating growth (Balance vs Equity)", options: ["Compound_Balance", "Compound_Equity"] },
      { id: "target", mt4_variable: "gInput_Input_CompoundingTarget", type: "double", default: 40.0, description: "Percentage growth required to trigger lot increase", unit: "%" },
      { id: "increase", mt4_variable: "gInput_Input_CompoundIncrease", type: "double", default: 2.0, description: "Multiplier applied to lot sizes when threshold is reached" }
    ]
  },
  global_system: { // General Category
    fields: [
      { id: "magic_number", mt4_variable: "gInput_MagicNumber", type: "int", default: 777, description: "BASE MAGIC NUMBER - Not directly used for trades" },
      { id: "max_slippage_points", mt4_variable: "gInput_MaxSlippagePoints", type: "double", default: 30.0, description: "Maximum allowed slippage for order execution (in points)", unit: "points" },
      { id: "allow_buy", mt4_variable: "gInput_allowBuy", type: "bool", default: true, description: "Allow EA to open BUY orders" },
      { id: "allow_sell", mt4_variable: "gInput_allowSell", type: "bool", default: true, description: "Allow EA to open SELL orders" },
      { id: "enable_logs", mt4_variable: "gInput_EnableLogs", type: "bool", default: false, description: "Enable detailed logging (DEFAULT: OFF for performance)" },
      { id: "config_file_name", mt4_variable: "gInput_ConfigFileName", type: "string", default: "DAAVFX_Config.json", description: "Dashboard configuration file name" },
      { id: "config_file_is_common", mt4_variable: "gInput_ConfigFileIsCommon", type: "bool", default: true, description: "Use Common\\Files directory (true) or MQL4\\Files directory (false)" }
    ]
  },
  license: {
    fields: [
      { id: "license_key", mt4_variable: "gInput_LicenseKey", type: "string", default: "", description: "License key for EA activation" },
      { id: "license_server_url", mt4_variable: "gInput_LicenseServerURL", type: "string", default: "https://license.daavfx.com", description: "License validation server URL" },
      { id: "require_license", mt4_variable: "gInput_RequireLicense", type: "bool", default: true, description: "Enable/disable license requirement" },
      { id: "license_check_interval", mt4_variable: "gInput_LicenseCheckInterval", type: "int", default: 3600, description: "Seconds between license validation checks", unit: "seconds" }
    ]
  },
  news_filter: {
    fields: [
      { id: "enabled", mt4_variable: "gInput_EnableNewsFilter", type: "bool", default: false, description: "Enable news event avoidance" },
      { id: "api_key", mt4_variable: "gInput_NewsAPIKey", type: "string", default: "KDrZNvJp.2Hh3GjfDZ0uyo2DWRQKExEYt5jktA3w1", description: "JBlanked News API authentication key" },
      { id: "api_url", mt4_variable: "gInput_NewsAPIURL", type: "string", default: "https://www.jblanked.com/news/api/calendar/", description: "News API endpoint URL" },
      { id: "countries", mt4_variable: "gInput_NewsFilterCountries", type: "string", default: "US,GB,EU", description: "Countries to monitor (comma-separated)" },
      { id: "impact_level", mt4_variable: "gInput_NewsImpactLevel", type: "int", default: 3, description: "Minimum impact level to trigger filter (1-3)", min: 1, max: 3 },
      { id: "minutes_before", mt4_variable: "gInput_MinutesBeforeNews", type: "int", default: 30, description: "Stop trading X minutes before news event", unit: "minutes", min: 0 },
      { id: "minutes_after", mt4_variable: "gInput_MinutesAfterNews", type: "int", default: 30, description: "Resume trading X minutes after news event", unit: "minutes", min: 0 },
      { id: "action", mt4_variable: "gInput_NewsAction", type: "enum", default: "TriggerAction_StopEA_KeepTrades", description: "Action to take during news event window", options: ["TriggerAction_StopEA_KeepTrades", "TriggerAction_StopEA_CloseTrades", "TriggerAction_Continue"] },
      { id: "check_interval", mt4_variable: "gInput_NewsCheckInterval", type: "int", default: 60, description: "Seconds between news checks", unit: "seconds", min: 10 },
      { id: "filter_high_only", mt4_variable: "gInput_FilterHighImpactOnly", type: "bool", default: true, description: "Only filter high impact news events" },
      { id: "filter_weekends", mt4_variable: "gInput_FilterWeekendNews", type: "bool", default: false, description: "Also filter weekend news announcements" },
      { id: "use_local_cache", mt4_variable: "gInput_UseLocalNewsCache", type: "bool", default: true, description: "Cache news data locally to reduce API calls" },
      { id: "cache_duration", mt4_variable: "gInput_NewsCacheDuration", type: "int", default: 3600, description: "Cache duration in seconds", unit: "seconds", min: 300 },
      { id: "fallback_on_error", mt4_variable: "gInput_NewsFallbackOnError", type: "enum", default: "Fallback_Continue", description: "Action if API fails", options: ["Fallback_Continue", "Fallback_Stop", "Fallback_UseCache"] },
      { id: "filter_currencies", mt4_variable: "gInput_FilterCurrencies", type: "string", default: "", description: "Only filter news for these currencies (empty = use symbol currencies)" },
      { id: "include_speeches", mt4_variable: "gInput_IncludeSpeeches", type: "bool", default: true, description: "Include central bank speeches in filter" },
      { id: "include_reports", mt4_variable: "gInput_IncludeReports", type: "bool", default: true, description: "Include economic reports in filter" },
      { id: "visual_indicator", mt4_variable: "gInput_NewsVisualIndicator", type: "bool", default: true, description: "Show visual indicator on chart during news events" },
      { id: "alert_before_news", mt4_variable: "gInput_AlertBeforeNews", type: "bool", default: false, description: "Send alert X minutes before news" },
      { id: "alert_minutes", mt4_variable: "gInput_AlertMinutesBefore", type: "int", default: 5, description: "Minutes before news to send alert", unit: "minutes", min: 1 }
    ]
  },
  restart_policies: {
    fields: [
      { id: "power_a_policy", mt4_variable: "gInput_RestartPolicy_PowerA", type: "enum", default: "Restart_Default", description: "Restart policy for Power-A logic (MAIN logic)", options: ["Restart_Default", "Restart_Always", "Restart_Never", "Restart_Conditional"] },
      { id: "non_power_policy", mt4_variable: "gInput_RestartPolicy_NonPower", type: "enum", default: "Restart_Default", description: "Restart policy for all non-Power logics", options: ["Restart_Default", "Restart_Always", "Restart_Never", "Restart_Conditional"] },
      { id: "close_non_power_on_power_close", mt4_variable: "gInput_CloseNonPowerOnPowerClose", type: "bool", default: false, description: "When Power logic closes in profit, also close all non-Power logics" }
    ]
  }
};
