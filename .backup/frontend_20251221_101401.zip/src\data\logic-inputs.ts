
// Logic Input Definitions derived from input_mapping templates (V17.04+)
// These definitions map UI fields to MT4/MT5 variables and handle Group 1 vs Standard differences
// Supports all 21 logics across 3 engines (A, B, C)

export interface LogicFieldDef {
  id: string;
  label: string;
  type: "number" | "toggle" | "text" | "select";
  mt4_variable_pattern?: string; // e.g. "gInput_Initial_loT_{suffix}"
  default: any;
  description?: string;
  unit?: string;
  options?: string[];
  category: "Core" | "Grid" | "Trail" | "Trail Advanced" | "Logic" | "Restart" | "TPSL" | "Reverse/Hedge" | "Close Partial" | "Safety" | "Triggers";
}

export interface LogicInputConfig {
  group_1: LogicFieldDef[];
  standard: LogicFieldDef[]; // Groups 2-20
}

// Enum options matching MT4/MT5 definitions
const TRAIL_METHODS = ["Points", "Percent", "AVG_Points", "AVG_Percent"];
const TRAIL_STEP_METHODS = ["Step_Points", "Step_Percent", "Step_Pips"];
const TRAIL_STEP_MODES = ["TrailStepMode_Auto", "TrailStepMode_Fixed", "TrailStepMode_PerOrder", "TrailStepMode_Disabled"];
const TPSL_MODES = ["TPSL_Points", "TPSL_Percent", "TPSL_Currency"];
const PARTIAL_MODES = ["PartialMode_Low", "PartialMode_High", "PartialMode_Balanced"];
const PARTIAL_BALANCES = ["PartialBalance_Aggressive", "PartialBalance_Balanced", "PartialBalance_Conservative"];
const LOGIC_REFERENCES = [
  "Logic_None", "Logic_Self",
  // Engine A
  "Logic_Power", "Logic_Repower", "Logic_Scalp", "Logic_Stopper", "Logic_STO", "Logic_SCA", "Logic_RPO",
  // Engine B
  "Logic_BPower", "Logic_BRepower", "Logic_BScalp", "Logic_BStopper", "Logic_BSTO", "Logic_BSCA", "Logic_BRPO",
  // Engine C
  "Logic_CPower", "Logic_CRepower", "Logic_CScalp", "Logic_CStopper", "Logic_CSTO", "Logic_CSCA", "Logic_CRPO"
];

// Common fields shared across most logics
const getBaseFields = (suffix: string, isStandard = false): LogicFieldDef[] => {
  const fields: LogicFieldDef[] = [
    { id: "initial_lot", label: "Initial Lot", type: "number", default: 0.02, unit: "lots", description: "Starting position size for first order. Subsequent orders = Initial × Multiplier^n. For $10k account, 0.01 = ~$1/pip risk.", category: "Core", mt4_variable_pattern: "gInput_Initial_loT_{suffix}" },
    { id: "multiplier", label: "Multiplier", type: "number", default: 1.2, description: "Lot increase factor per grid level. 1.0=flat, 1.2-1.5=moderate, 1.8+=aggressive (martingale). Ex: 0.02→0.024→0.029...", category: "Core", mt4_variable_pattern: "gInput_Mult_{suffix}" },
    { id: "grid", label: "Grid Spacing", type: "number", default: isStandard ? 300 : 2750, unit: "pts", description: "Distance in points before opening next grid level. 300pts=30pips. Group 1 uses wider grids (2750), Groups 2-20 use tighter (300-500).", category: "Grid", mt4_variable_pattern: "gInput_Grid_{suffix}" },
    // Base Trail
    { id: "trail_method", label: "Trail Method", type: "select", default: "Points", options: TRAIL_METHODS, description: "How trail distance is calculated. Points=fixed distance, Percent=% of profit, AVG_*=from average entry price of all positions.", category: "Trail", mt4_variable_pattern: "gInput_Trail_{suffix}" },
    { id: "trail_value", label: "Trail Value", type: "number", default: 3000, unit: "pts", description: "Trail distance value (3000pts=300pips). Tighter=locks profit faster but may exit early. Wider=lets trades breathe but risks giving back gains.", category: "Trail", mt4_variable_pattern: "gInput_TrailValue_{suffix}" },
    { id: "trail_start", label: "Trail Start", type: "number", default: 1, unit: "pts", description: "Minimum profit before trailing activates. Prevents premature exits on small profits. Set higher than typical spread+noise.", category: "Trail", mt4_variable_pattern: "gInput_Trail_Start_{suffix}" },
    { id: "trail_step", label: "Trail Step", type: "number", default: 1500, unit: "pts", description: "Minimum price movement before trail updates. Smooths trail movement, reduces server load. 100-500=responsive, 1000+=conservative.", category: "Trail", mt4_variable_pattern: "gInput_TrailStep_{suffix}" },
    { id: "trail_step_method", label: "Trail Step Method", type: "select", default: "Step_Points", options: TRAIL_STEP_METHODS, description: "Unit for Trail Step. Step_Points=fixed distance, Step_Percent=% of profit increase, Step_Pips=pips (÷10 for 5-digit).", category: "Trail", mt4_variable_pattern: "gInput_TrailStepMethod_{suffix}" },
  ];

  if (isStandard) {
    // Remove initial_lot for Standard groups (2-20) as they use Group 1's lot
    return fields.filter(f => f.id !== "initial_lot");
  }
  return fields;
};

// V17.04+: Trail Step Advanced fields (TrailStepCycle, TrailStepBalance)
const getTrailAdvancedFields = (suffix: string): LogicFieldDef[] => {
  const fields: LogicFieldDef[] = [
    { id: "trail_step_mode", label: "Trail Step Mode", type: "select", default: "TrailStepMode_Auto", options: TRAIL_STEP_MODES, description: "Advanced trail update control. Auto=system optimizes, Fixed=consistent intervals, PerOrder=individual position profit, Disabled=basic trail only.", category: "Trail Advanced", mt4_variable_pattern: "gInput_TrailStepMode_{suffix}" },
    { id: "trail_step_cycle", label: "Trail Step Cycle", type: "number", default: 1, description: "Update trail every Nth tick cycle. 1=every tick (responsive), 5-10=lighter load. Higher values reduce CPU usage on VPS.", category: "Trail Advanced", mt4_variable_pattern: "gInput_TrailStepCycle_{suffix}" },
    { id: "trail_step_balance", label: "Trail Step Balance", type: "number", default: 0, unit: "$", description: "Skip trail updates if account balance below this threshold. Safety net during drawdown. 0=disabled, set to 80% of starting balance for protection.", category: "Trail Advanced", mt4_variable_pattern: "gInput_TrailStepBalance_{suffix}" },
  ];

  // Extended Trail Step Levels 2-7
  for (let i = 2; i <= 7; i++) {
    fields.push(
      { id: `trail_step_${i}`, label: `Trail Step ${i}`, type: "number", default: 1500, unit: "pts", description: `Trail Step for Level ${i}`, category: "Trail Advanced", mt4_variable_pattern: `gInput_TrailStep${i}_{suffix}` },
      { id: `trail_step_method_${i}`, label: `Trail Step Method ${i}`, type: "select", default: "Step_Points", options: TRAIL_STEP_METHODS, description: `Trail Step Method for Level ${i}`, category: "Trail Advanced", mt4_variable_pattern: `gInput_TrailStepMethod${i}_{suffix}` },
      { id: `trail_step_cycle_${i}`, label: `Trail Step Cycle ${i}`, type: "number", default: 1, description: `Trail Step Cycle for Level ${i}`, category: "Trail Advanced", mt4_variable_pattern: `gInput_TrailStepCycle${i}_{suffix}` },
      { id: `trail_step_balance_${i}`, label: `Trail Step Balance ${i}`, type: "number", default: 0, unit: "$", description: `Trail Step Balance for Level ${i}`, category: "Trail Advanced", mt4_variable_pattern: `gInput_TrailStepBalance${i}_{suffix}` },
      { id: `trail_step_mode_${i}`, label: `Trail Step Mode ${i}`, type: "select", default: "TrailStepMode_Auto", options: TRAIL_STEP_MODES, description: `Trail Step Mode for Level ${i}`, category: "Trail Advanced", mt4_variable_pattern: `gInput_TrailStepMode${i}_{suffix}` }
    );
  }

  return fields;
};

const getTPSLFields = (suffix: string): LogicFieldDef[] => [
  { id: "use_tp", label: "Use TP", type: "toggle", default: false, description: "Enable fixed take-profit per position. Unlike trail (dynamic), TP is set at order open and doesn't move. Use for known profit targets.", category: "TPSL", mt4_variable_pattern: "gInput_G{group}_UseTP_{logic_short}" },
  { id: "tp_mode", label: "TP Mode", type: "select", default: "TPSL_Points", options: TPSL_MODES, description: "TP calculation method. Points=fixed distance, Percent=% of entry price, Currency=$ value per position.", category: "TPSL", mt4_variable_pattern: "gInput_G{group}_TP_Mode_{logic_short}" },
  { id: "tp_value", label: "TP Value", type: "number", default: 0, description: "Take-profit value (interpreted based on TP Mode). 0=disabled. Ex: 500 points = 50 pips on 5-digit broker.", category: "TPSL", mt4_variable_pattern: "gInput_G{group}_TP_Value_{logic_short}" },
  { id: "use_sl", label: "Use SL", type: "toggle", default: false, description: "Enable fixed stop-loss per position. ⚠️ Grid strategies often keep this OFF since grid is designed to average down. Use account-level protection instead.", category: "TPSL", mt4_variable_pattern: "gInput_G{group}_UseSL_{logic_short}" },
  { id: "sl_mode", label: "SL Mode", type: "select", default: "TPSL_Points", options: TPSL_MODES, description: "SL calculation method. Points=fixed distance, Percent=% of entry price, Currency=$ loss limit per position.", category: "TPSL", mt4_variable_pattern: "gInput_G{group}_SL_Mode_{logic_short}" },
  { id: "sl_value", label: "SL Value", type: "number", default: 0, description: "Stop-loss value (interpreted based on SL Mode). 0=disabled. Broker-level protection even if EA crashes.", category: "TPSL", mt4_variable_pattern: "gInput_G{group}_SL_Value_{logic_short}" },
];

// V17.04+: Complete Reverse/Hedge fields (8 fields per logic)
const getReverseHedgeFields = (suffix: string): LogicFieldDef[] => [
  // Toggles
  { id: "reverse_enabled", label: "Reverse Enabled", type: "toggle", default: false, description: "FLIP trade direction: BUY signal opens SELL instead. Converts counter-trend to trend-follow. Orders tagged [REV]. Use to test opposite hypothesis.", category: "Reverse/Hedge", mt4_variable_pattern: "gInput_G{group}_{logic_short}_ReverseEnabled" },
  { id: "hedge_enabled", label: "Hedge Enabled", type: "toggle", default: false, description: "Open BOTH directions: original + opposite. Creates offsetting positions to lock profit or reduce exposure. Orders tagged [HEDGE]. Has cost (2× spread).", category: "Reverse/Hedge", mt4_variable_pattern: "gInput_G{group}_{logic_short}_HedgeEnabled" },
  // Scales (percentage)
  { id: "reverse_scale", label: "Reverse Scale", type: "number", default: 100.0, unit: "%", description: "Lot size for reversed trades as % of original. 100%=same size, 50%=half size. Ex: 0.10 lots @ 75% scale = 0.075 lots reversed.", category: "Reverse/Hedge", mt4_variable_pattern: "gInput_G{group}_Scale_{logic_short}_Reverse" },
  { id: "hedge_scale", label: "Hedge Scale", type: "number", default: 50.0, unit: "%", description: "Lot size for hedge as % of main position. 100%=fully locked (0 net exposure), 50%=half hedged. Net = Main - Hedge.", category: "Reverse/Hedge", mt4_variable_pattern: "gInput_G{group}_Scale_{logic_short}_Hedge" },
  // References
  { id: "reverse_reference", label: "Reverse Reference", type: "select", default: "Logic_None", options: LOGIC_REFERENCES, description: "Which logic's signals to reverse against. Logic_Self=own signals, Logic_Power=reverse when Power signals. Enables coordinated opposite positions.", category: "Reverse/Hedge", mt4_variable_pattern: "gInput_G{group}_{logic_short}_ReverseReference" },
  { id: "hedge_reference", label: "Hedge Reference", type: "select", default: "Logic_None", options: LOGIC_REFERENCES, description: "Which logic's positions trigger hedges. One logic can act as 'hedge engine' for another. Logic_None=disabled.", category: "Reverse/Hedge", mt4_variable_pattern: "gInput_G{group}_{logic_short}_HedgeReference" },
];

const getClosePartialFields = (suffix: string): LogicFieldDef[] => {
  const fields: LogicFieldDef[] = [
    { id: "close_partial", label: "Close Partial", type: "toggle", default: false, description: "Enable partial position closing. Locks in some profit while letting rest run. Reduces exposure progressively instead of all-or-nothing exit.", category: "Close Partial", mt4_variable_pattern: "gInput_ClosePartial_{suffix}" },
    { id: "close_partial_cycle", label: "Partial Cycle", type: "number", default: 3, description: "Close every Nth profitable position. 1=close all winners (aggressive), 3=close 1/3rd (balanced), 5+=conservative. Ex: 5 winners @ cycle 3 → close positions 3 and 6.", category: "Close Partial", mt4_variable_pattern: "gInput_ClosePartialCycle_{suffix}" },
    { id: "close_partial_mode", label: "Partial Mode", type: "select", default: "PartialMode_Low", options: PARTIAL_MODES, description: "Which positions to close first. Low=close smallest profits (let big ones run), High=grab big wins first, Balanced=alternate.", category: "Close Partial", mt4_variable_pattern: "gInput_ClosePartialMode_{suffix}" },
    { id: "close_partial_balance", label: "Partial Balance", type: "select", default: "PartialBalance_Balanced", options: PARTIAL_BALANCES, description: "Risk profile for partial closes. Aggressive=close more frequently, Balanced=moderate, Conservative=close less. Affects 'in profit' threshold.", category: "Close Partial", mt4_variable_pattern: "gInput_ClosePartialBalance_{suffix}" },
    { id: "close_partial_trail_step_mode", label: "Partial Trail Mode", type: "select", default: "TrailStepMode_Auto", options: TRAIL_STEP_MODES, description: "Trail mode specifically for partial close operations. Usually matches main trail mode but can be independent.", category: "Close Partial", mt4_variable_pattern: "gInput_ClosePartialTrailStepMode_{suffix}" },
  ];

  // Extended Close Partial Levels 2-4
  for (let i = 2; i <= 4; i++) {
    fields.push(
      { id: `close_partial_${i}`, label: `Close Partial ${i}`, type: "toggle", default: false, description: `Enable partial position closing for Level ${i}`, category: "Close Partial", mt4_variable_pattern: `gInput_ClosePartial${i}_{suffix}` },
      { id: `close_partial_cycle_${i}`, label: `Partial Cycle ${i}`, type: "number", default: 3, description: `Partial Cycle for Level ${i}`, category: "Close Partial", mt4_variable_pattern: `gInput_ClosePartialCycle${i}_{suffix}` },
      { id: `close_partial_mode_${i}`, label: `Partial Mode ${i}`, type: "select", default: "PartialMode_Low", options: PARTIAL_MODES, description: `Partial Mode for Level ${i}`, category: "Close Partial", mt4_variable_pattern: `gInput_ClosePartialMode${i}_{suffix}` },
      { id: `close_partial_balance_${i}`, label: `Partial Balance ${i}`, type: "select", default: "PartialBalance_Balanced", options: PARTIAL_BALANCES, description: `Partial Balance for Level ${i}`, category: "Close Partial", mt4_variable_pattern: `gInput_ClosePartialBalance${i}_{suffix}` }
    );
  }

  return fields;
};

// CloseTargets default values per logic (matching MT4/MT5 inputs)
const CLOSE_TARGETS_DEFAULTS: Record<string, string> = {
  // Engine A
  POWER: "Logic_A_Power,Logic_A_Repower,Logic_A_Scalp,Logic_A_Stopper",
  REPOWER: "Logic_A_Repower",
  SCALPER: "Logic_A_Scalp",
  STOPPER: "Logic_A_Stopper",
  STO: "Logic_A_Repower,Logic_A_Scalp,Logic_A_Stopper,Logic_A_Power,Logic_A_STO",
  SCA: "Logic_A_Scalp,Logic_A_Stopper,Logic_A_Repower,Logic_A_SCA",
  RPO: "Logic_A_Repower,Logic_A_Scalp,Logic_A_Stopper,Logic_A_SCA,Logic_A_RPO,Logic_A_Power,Logic_A_STO",
  // Engine B
  BPOWER: "Logic_B_Repower,Logic_B_Scalp,Logic_B_Stopper,Logic_B_Power",
  BREPOWER: "Logic_B_Repower",
  BSCALPER: "Logic_B_Scalp",
  BSTOPPER: "Logic_B_Stopper",
  BSTO: "Logic_B_Repower,Logic_B_Scalp,Logic_B_Stopper,Logic_B_Power,Logic_B_STO",
  BSCA: "Logic_B_Scalp,Logic_B_Stopper,Logic_B_Repower,Logic_B_SCA",
  BRPO: "Logic_B_Repower,Logic_B_Scalp,Logic_B_Stopper,Logic_B_Power,Logic_B_STO,Logic_B_SCA,Logic_B_RPO",
  // Engine C
  CPOWER: "Logic_A_Power,Logic_B_Power,Logic_C_Power",
  CREPOWER: "Logic_C_Repower,Logic_A_Repower,Logic_A_Power,Logic_B_Repower",
  CSCALPER: "Logic_C_Scalp,Logic_B_Scalp,Logic_A_Scalp,Logic_A_Stopper",
  CSTOPPER: "Logic_C_Stopper,Logic_B_Stopper,Logic_A_Stopper",
  CSTO: "Logic_C_Power,Logic_C_Repower,Logic_C_Scalp,Logic_C_Stopper,Logic_C_STO,Logic_A_Repower,Logic_A_Power,Logic_A_Scalp,Logic_A_Stopper,Logic_A_RPO,Logic_A_STO",
  CSCA: "Logic_A_Scalp,Logic_A_Stopper,Logic_A_STO,Logic_A_SCA,Logic_C_Scalp,Logic_C_Stopper,Logic_C_STO,Logic_C_SCA",
  CRPO: "Logic_A_Power,Logic_A_Repower,Logic_A_Scalp,Logic_A_Stopper,Logic_A_STO,Logic_A_SCA,Logic_A_RPO,Logic_B_Power,Logic_B_Repower,Logic_B_Scalp,Logic_B_Stopper,Logic_B_STO,Logic_B_SCA,Logic_B_RPO,Logic_C_Power,Logic_C_Repower,Logic_C_Scalp,Logic_C_Stopper,Logic_C_STO,Logic_C_SCA,Logic_C_RPO",
};

const getUniqueFields = (type: string, logicKey?: string): LogicFieldDef[] => {
  // CloseTargets field for ALL logics (not just POWER)
  const closeTargetsDefault = logicKey ? (CLOSE_TARGETS_DEFAULTS[logicKey] || "Logic_A_Power") : "Logic_A_Power";
  const closeTargetsField: LogicFieldDef = {
    id: "close_targets",
    label: "Close Targets",
    type: "text",
    default: closeTargetsDefault,
    description: "⭐ POWERFUL: Comma-separated logic labels to close when THIS logic profits. Ex: 'Logic_A_Power,Logic_A_Repower' → when RPO profits, it also closes Power & Repower. Remove a logic to prevent closure.",
    category: "Logic",
    mt4_variable_pattern: `gInput_CloseTargets_{logic_name}`
  };

  if (type === "POWER") {
    return [
      closeTargetsField,
      { id: "order_count_reference", label: "Order Count Ref", type: "select", default: "Logic_Self", options: ["Logic_Power", "Logic_Repower", "Logic_Scalp", "Logic_Stopper", "Logic_STO", "Logic_SCA", "Logic_RPO", "Logic_Self"], description: "Which logic's order count determines grid level. Logic_Self=independent, Logic_Power=sync with Power's level for coordinated lot sizing.", category: "Logic", mt4_variable_pattern: "gInput_Power_OrderCountReference" },
      { id: "reset_lot_on_restart", label: "Reset Lot", type: "toggle", default: true, description: "Reset to initial lot when starting new grid sequence after full close. ON=clean slate (recommended), OFF=continue from last lot size.", category: "Logic", mt4_variable_pattern: "gInput_Power_ResetLotOnRestart" },
    ];
  }
  
  return [
    closeTargetsField,
    { id: "start_level", label: "Start Level", type: "number", default: 4, description: "Grid level required before this logic activates. Delays secondary logics until grid deepens. Ex: Power=1 (immediate), Repower=4 (joins at level 4).", category: "Core", mt4_variable_pattern: "gInput_Start{logic_name}" },
    { id: "last_lot", label: "Last Lot", type: "number", default: 0.12, unit: "lots", description: "Maximum lot size cap regardless of multiplier. Safety limit for risk management. Lots are capped, not grid levels. Critical for prop firm compliance.", category: "Safety", mt4_variable_pattern: "gInput_LastLot{logic_name}" },
  ];
};

const getTriggerFields = (suffix: string): LogicFieldDef[] => [
  { id: "trigger_type", label: "Trigger Type", type: "text", default: "Default", description: "Entry signal type for Group 1. Default=logic's built-in, Manual=require confirmation, External=wait for indicator signal.", category: "Triggers", mt4_variable_pattern: "gInput_G1_TriggerType_{suffix}" },
  { id: "trigger_bars", label: "Trigger Bars", type: "number", default: 3, description: "Bars to wait before confirming entry. Filters false breakouts. Signal must remain valid for N bars. 1-2=quick, 3-5=moderate, 10+=strong confirmation.", category: "Triggers", mt4_variable_pattern: "gInput_G1_TriggerBars_{suffix}" },
  { id: "trigger_minutes", label: "Trigger Minutes", type: "number", default: 15, unit: "min", description: "Time delay before executing entry. Cooldown period between entries. 5=quick, 15=standard, 60=hourly entries only.", category: "Triggers", mt4_variable_pattern: "gInput_G1_TriggerMinutes_{suffix}" },
  { id: "trigger_pips", label: "Trigger Pips", type: "number", default: 0.0, unit: "pips", description: "Minimum price movement in pips before triggering entry. 0=disabled. Filters noise. Ex: 5 pips = wait for 50 points (5-digit broker).", category: "Triggers", mt4_variable_pattern: "gInput_G1_TriggerPips_{suffix}" },
];

const buildLogicConfig = (type: string, suffix: string, logicKey: string): LogicInputConfig => {
  const baseG1 = getBaseFields(suffix, false);
  const baseStd = getBaseFields(suffix, true);
  const unique = getUniqueFields(type, logicKey);
  const tpsl = getTPSLFields(suffix);
  const reverseHedge = getReverseHedgeFields(suffix);
  const trailAdvanced = getTrailAdvancedFields(suffix);
  const partial = getClosePartialFields(suffix);
  const triggers = getTriggerFields(suffix);

  return {
    // Group 1: all fields including triggers
    group_1: [...unique, ...baseG1, ...trailAdvanced, ...triggers, ...tpsl, ...reverseHedge, ...partial],
    // Groups 2-20: no triggers
    standard: [...unique, ...baseStd, ...trailAdvanced, ...tpsl, ...reverseHedge, ...partial],
  };
};

// All 21 logics across 3 engines
export const logicInputs: Record<string, LogicInputConfig> = {
  // ===== ENGINE A (7 logics) =====
  POWER: buildLogicConfig("POWER", "P", "POWER"),
  REPOWER: buildLogicConfig("REPOWER", "R", "REPOWER"),
  SCALPER: buildLogicConfig("SCALPER", "S", "SCALPER"),
  STOPPER: buildLogicConfig("STOPPER", "ST", "STOPPER"),
  STO: buildLogicConfig("STO", "STO", "STO"),
  SCA: buildLogicConfig("SCA", "SCA", "SCA"),
  RPO: buildLogicConfig("RPO", "RPO", "RPO"),
  
  // ===== ENGINE B (7 logics) =====
  BPOWER: buildLogicConfig("POWER", "BP", "BPOWER"),
  BREPOWER: buildLogicConfig("REPOWER", "BR", "BREPOWER"),
  BSCALPER: buildLogicConfig("SCALPER", "BS", "BSCALPER"),
  BSTOPPER: buildLogicConfig("STOPPER", "BST", "BSTOPPER"),
  BSTO: buildLogicConfig("STO", "BSTO", "BSTO"),
  BSCA: buildLogicConfig("SCA", "BSCA", "BSCA"),
  BRPO: buildLogicConfig("RPO", "BRPO", "BRPO"),
  
  // ===== ENGINE C (7 logics) =====
  CPOWER: buildLogicConfig("POWER", "CP", "CPOWER"),
  CREPOWER: buildLogicConfig("REPOWER", "CR", "CREPOWER"),
  CSCALPER: buildLogicConfig("SCALPER", "CS", "CSCALPER"),
  CSTOPPER: buildLogicConfig("STOPPER", "CST", "CSTOPPER"),
  CSTO: buildLogicConfig("STO", "CSTO", "CSTO"),
  CSCA: buildLogicConfig("SCA", "CSCA", "CSCA"),
  CRPO: buildLogicConfig("RPO", "CRPO", "CRPO"),
};

// Engine-to-logics mapping for UI
export const ENGINE_LOGICS: Record<string, string[]> = {
  A: ["POWER", "REPOWER", "SCALPER", "STOPPER", "STO", "SCA", "RPO"],
  B: ["BPOWER", "BREPOWER", "BSCALPER", "BSTOPPER", "BSTO", "BSCA", "BRPO"],
  C: ["CPOWER", "CREPOWER", "CSCALPER", "CSTOPPER", "CSTO", "CSCA", "CRPO"],
};

// Logic display names (friendly names for UI)
export const LOGIC_DISPLAY_NAMES: Record<string, string> = {
  // Engine A
  POWER: "Power", REPOWER: "Repower", SCALPER: "Scalper", STOPPER: "Stopper",
  STO: "STO", SCA: "SCA", RPO: "RPO",
  // Engine B
  BPOWER: "B-Power", BREPOWER: "B-Repower", BSCALPER: "B-Scalper", BSTOPPER: "B-Stopper",
  BSTO: "B-STO", BSCA: "B-SCA", BRPO: "B-RPO",
  // Engine C
  CPOWER: "C-Power", CREPOWER: "C-Repower", CSCALPER: "C-Scalper", CSTOPPER: "C-Stopper",
  CSTO: "C-STO", CSCA: "C-SCA", CRPO: "C-RPO",
};
