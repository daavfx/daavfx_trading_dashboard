// Comprehensive Help Documentation for DAAVFX Trading System
// This file contains detailed explanations for all inputs and trading concepts

export interface HelpEntry {
  id: string;
  title: string;
  category: string;
  shortDesc: string;
  fullDesc: string;
  examples?: string[];
  tips?: string[];
  relatedInputs?: string[];
  mt4Variable?: string;
}

export interface HelpCategory {
  id: string;
  name: string;
  icon: string;
  description: string;
}

// =============================================================================
// CATEGORIES
// =============================================================================
export const HELP_CATEGORIES: HelpCategory[] = [
  { id: "core", name: "Core Settings", icon: "⚙️", description: "Fundamental position sizing and multiplier settings" },
  { id: "grid", name: "Grid Trading", icon: "📊", description: "Grid spacing and level management for DCA strategies" },
  { id: "trail", name: "Trailing System", icon: "📈", description: "Dynamic stop-loss management to lock in profits" },
  { id: "trail_advanced", name: "Trail Advanced", icon: "🎯", description: "Advanced trailing controls for fine-tuning" },
  { id: "logic", name: "Logic Controls", icon: "🧠", description: "Logic-specific behavior and cross-logic coordination" },
  { id: "tpsl", name: "Take Profit / Stop Loss", icon: "🎚️", description: "Fixed profit targets and loss limits per position" },
  { id: "reverse_hedge", name: "Reverse & Hedge", icon: "🔄", description: "Advanced position flipping and hedging strategies" },
  { id: "close_partial", name: "Close Partial", icon: "✂️", description: "Partial position closing to secure profits" },
  { id: "safety", name: "Safety Controls", icon: "🛡️", description: "Risk management and position limits" },
  { id: "triggers", name: "Entry Triggers", icon: "⚡", description: "Conditions for opening new positions" },
  { id: "concepts", name: "Trading Concepts", icon: "📚", description: "General trading terminology and system architecture" },
];

// =============================================================================
// DETAILED HELP ENTRIES
// =============================================================================
export const HELP_ENTRIES: HelpEntry[] = [
  // ===== CORE SETTINGS =====
  {
    id: "initial_lot",
    title: "Initial Lot",
    category: "core",
    shortDesc: "Starting position size for the first order in a grid sequence",
    fullDesc: `The Initial Lot is the foundation of your position sizing. This is the lot size used for the FIRST order when a logic opens a new grid sequence.

**How it works:**
- When no positions exist and a signal triggers, the EA opens a position with this lot size
- Subsequent orders in the grid use this as the base, multiplied by the Multiplier
- Example: Initial Lot = 0.02, Multiplier = 1.5 → Orders: 0.02, 0.03, 0.045, 0.0675...

**Risk Calculation:**
- For a $10,000 account, 0.01 lot typically risks ~$1 per pip on major pairs
- Consider your maximum grid depth when setting this value
- Total exposure = Sum of all potential grid levels`,
    examples: [
      "Conservative: 0.01 for $5,000 account",
      "Moderate: 0.02 for $10,000 account",
      "Aggressive: 0.05 for $25,000+ account"
    ],
    tips: [
      "Start smaller than you think - you can always increase",
      "Account for maximum grid depth in your risk calculations",
      "Different logics can have different initial lots for diversification"
    ],
    relatedInputs: ["multiplier", "last_lot", "grid"],
    mt4Variable: "gInput_Initial_loT_{suffix}"
  },
  {
    id: "multiplier",
    title: "Multiplier",
    category: "core",
    shortDesc: "Lot size increase factor between consecutive grid orders",
    fullDesc: `The Multiplier determines how aggressively your position size grows with each grid level.

**Formula:** Next Lot = Previous Lot × Multiplier

**Common Strategies:**
- **1.0 (Flat):** Same lot size for every level - lowest risk, slowest recovery
- **1.2-1.5 (Moderate):** Gradual increase - balanced approach
- **1.8-2.0 (Aggressive):** Martingale-style - fast recovery but high risk
- **2.0+ (Extreme):** Very high risk - not recommended for most traders

**Example Progression (Initial: 0.02, Mult: 1.5):**
Level 1: 0.02 → Level 2: 0.03 → Level 3: 0.045 → Level 4: 0.0675...`,
    examples: [
      "Safe recovery: 1.2 multiplier",
      "Balanced: 1.4-1.5 multiplier",
      "Fast recovery: 1.8 multiplier (high risk)"
    ],
    tips: [
      "Lower multiplier = more grid levels needed to recover",
      "Higher multiplier = fewer levels but exponential risk",
      "Test with backtester before going live"
    ],
    relatedInputs: ["initial_lot", "last_lot", "grid"],
    mt4Variable: "gInput_Mult_{suffix}"
  },

  // ===== GRID SETTINGS =====
  {
    id: "grid",
    title: "Grid Spacing",
    category: "grid",
    shortDesc: "Distance in points between grid levels (DCA entries)",
    fullDesc: `Grid Spacing defines how far price must move against you before opening the next grid level.

**Understanding Points:**
- For 5-digit brokers: 1 pip = 10 points (e.g., EURUSD)
- Grid of 300 points = 30 pips
- Grid of 2750 points = 275 pips

**Group 1 vs Standard Groups:**
- **Group 1:** Uses wider grids (2750+ pts) - main trend-following entries
- **Groups 2-20:** Use tighter grids (300-500 pts) - recovery/averaging layers

**Strategy Considerations:**
- Wider grid = fewer orders, less exposure, slower recovery
- Tighter grid = more orders, higher exposure, faster recovery
- Volatility matters: Use wider grids on volatile pairs`,
    examples: [
      "Scalping: 100-200 points",
      "Day trading: 300-500 points",
      "Swing/Position: 1000-3000 points"
    ],
    tips: [
      "Match grid size to the timeframe you're trading",
      "Volatile pairs need wider grids",
      "Group 1 should have widest grid as trend confirmation"
    ],
    relatedInputs: ["initial_lot", "multiplier", "start_level"],
    mt4Variable: "gInput_Grid_{suffix}"
  },

  // ===== TRAIL SETTINGS =====
  {
    id: "trail_method",
    title: "Trail Method",
    category: "trail",
    shortDesc: "How the trailing stop calculates its distance from price",
    fullDesc: `The Trail Method determines the mathematical approach for calculating trail distance.

**Available Methods:**

1. **Points** - Fixed point distance
   - Trail stays X points behind price
   - Simple and predictable
   - Best for: Consistent market conditions

2. **Percent** - Percentage of profit
   - Trail follows at X% of current profit
   - Adapts to profit size
   - Best for: Variable profit targets

3. **AVG_Points** - Average position price + points
   - Calculates from grid's average entry price
   - Better for multi-position grids
   - Best for: Complex grid recovery

4. **AVG_Percent** - Average position price + percent
   - Percentage from average entry
   - Most adaptive method
   - Best for: Dynamic market conditions`,
    examples: [
      "Points: Trail at 500 points = 50 pips",
      "Percent: Trail at 50% = keeps half of floating profit",
      "AVG_Points: 1000 points from average entry"
    ],
    tips: [
      "Use Points for simple single-position trades",
      "Use AVG methods for grid/martingale strategies",
      "Percent methods adapt to volatile markets better"
    ],
    relatedInputs: ["trail_value", "trail_start", "trail_step"],
    mt4Variable: "gInput_Trail_{suffix}"
  },
  {
    id: "trail_value",
    title: "Trail Value",
    category: "trail",
    shortDesc: "The trailing distance value (interpretation depends on Trail Method)",
    fullDesc: `Trail Value is the numeric distance/percentage used by the selected Trail Method.

**Interpretation by Method:**
- **Points:** Actual point distance (3000 = 300 pips)
- **Percent:** Percentage value (50 = 50% of profit)
- **AVG_Points:** Points from average entry
- **AVG_Percent:** Percent from average entry

**Example - Points Method:**
- Trail Value = 3000 (300 pips)
- Price at 1.2000, position profit = 500 pips
- Trail stop placed at 1.1700 (300 pips behind)
- As price rises, trail follows 300 pips behind`,
    examples: [
      "Tight trail: 1000 points (locks profit quickly)",
      "Moderate: 2000-3000 points (balanced)",
      "Wide trail: 5000+ points (lets trades breathe)"
    ],
    tips: [
      "Tighter trails lock profit but may exit too early",
      "Wider trails allow for retracements but risk giving back gains",
      "Match to your typical profit targets"
    ],
    relatedInputs: ["trail_method", "trail_start", "trail_step"],
    mt4Variable: "gInput_TrailValue_{suffix}"
  },
  {
    id: "trail_start",
    title: "Trail Start",
    category: "trail",
    shortDesc: "Minimum profit level before trailing begins",
    fullDesc: `Trail Start prevents the trailing stop from activating until a minimum profit threshold is reached.

**Why This Matters:**
- Prevents premature exits on small profits
- Lets positions develop before protection kicks in
- Reduces noise from small price fluctuations

**How It Works:**
- Position must reach X points/percent profit first
- Once threshold is hit, trailing begins
- Trail then follows price according to Trail Method/Value`,
    examples: [
      "Trail Start = 1: Begin trailing immediately when in profit",
      "Trail Start = 100: Wait for 10 pips profit first",
      "Trail Start = 500: Wait for 50 pips before trailing"
    ],
    tips: [
      "Higher start = more room for position to develop",
      "Set based on typical spread + noise of your pair",
      "Consider combining with Trail Step for dynamic behavior"
    ],
    relatedInputs: ["trail_method", "trail_value", "trail_step"],
    mt4Variable: "gInput_Trail_Start_{suffix}"
  },
  {
    id: "trail_step",
    title: "Trail Step",
    category: "trail",
    shortDesc: "Minimum price movement before trail updates",
    fullDesc: `Trail Step controls how frequently the trailing stop moves to follow price.

**Purpose:**
- Prevents trail from updating on every tick (reduces server load)
- Smooths out trail movement
- Can be used strategically to "step up" protection

**Example:**
- Trail Step = 100 points
- Trail updates only when price moves 10+ pips in your favor
- Reduces whipsaw from small fluctuations`,
    examples: [
      "Smooth trail: 50-100 points",
      "Stepped protection: 500 points",
      "Conservative: 1000+ points"
    ],
    tips: [
      "Smaller steps = more responsive but more server calls",
      "Larger steps = less responsive but smoother",
      "Match to your trading style and timeframe"
    ],
    relatedInputs: ["trail_value", "trail_step_method", "trail_step_mode"],
    mt4Variable: "gInput_TrailStep_{suffix}"
  },
  {
    id: "trail_step_method",
    title: "Trail Step Method",
    category: "trail",
    shortDesc: "Unit type for the Trail Step value",
    fullDesc: `Determines how the Trail Step value is interpreted.

**Methods:**
- **Step_Points:** Trail Step in points (most common)
- **Step_Percent:** Trail Step as percentage of profit
- **Step_Pips:** Trail Step in pips (10× points for 5-digit)

**Example:**
- Step_Points with value 100 = update every 10 pips
- Step_Percent with value 5 = update every 5% profit increase
- Step_Pips with value 10 = update every 10 pips`,
    tips: [
      "Step_Points is most intuitive for fixed distances",
      "Step_Percent adapts to profit size automatically"
    ],
    relatedInputs: ["trail_step", "trail_step_mode"],
    mt4Variable: "gInput_TrailStepMethod_{suffix}"
  },

  // ===== TRAIL ADVANCED =====
  {
    id: "trail_step_mode",
    title: "Trail Step Mode",
    category: "trail_advanced",
    shortDesc: "How the trailing step is calculated",
    fullDesc: `Defines the method used to calculate when the trailing stop should move.

**Modes:**
- **TrailStepMode_Auto:** (Recommended) The system automatically decides the best timing based on volatility.
- **TrailStepMode_Fixed:** Updates at strict, fixed intervals (e.g., every 10 points).
- **TrailStepMode_PerOrder:** Updates based on the profit of individual orders rather than the basket.
- **TrailStepMode_Disabled:** Turns off the stepping mechanism (standard trailing only).`,
    tips: [
      "Use 'Auto' for most strategies.",
      "Use 'Fixed' if you want precise, predictable movements."
    ],
    relatedInputs: ["trail_step", "trail_step_cycle", "trail_step_balance"],
    mt4Variable: "gInput_TrailStepMode_{suffix}"
  },
  {
    id: "trail_step_cycle",
    title: "Trail Step Cycle",
    category: "trail_advanced",
    shortDesc: "Frequency of trail updates (1 = Every Tick)",
    fullDesc: `Controls how often the EA checks to update the trailing stop.

**Values:**
- **1:** Checks every single tick (Most precise, highest CPU usage).
- **2-5:** Checks every few ticks (Balanced).
- **10+:** Checks infrequently (Low CPU usage).

**Why use this?**
If you are running on a slow VPS or have many charts open, increasing this value helps reduce lag without significantly affecting performance.`,
    examples: [
      "1: High-frequency scalping",
      "5: Swing trading or weak VPS"
    ],
    tips: [
      "Leave at 1 unless you experience lag.",
      "Higher values = less CPU load."
    ],
    relatedInputs: ["trail_step_mode", "trail_step_balance"],
    mt4Variable: "gInput_TrailStepCycle_{suffix}"
  },
  {
    id: "trail_step_balance",
    title: "Trail Step Balance",
    category: "trail_advanced",
    shortDesc: "Minimum account balance to activate trailing",
    fullDesc: `A safety filter: The trailing step logic will ONLY work if your account balance is above this amount.

**Value:**
- **0:** Disabled (Always trail, regardless of balance).
- **1000:** Only trail if balance is > $1,000.

**Usage:**
This is rarely used for standard trading. It is designed for specific recovery strategies where you want to disable trailing stops when the account is in severe drawdown (below a certain balance level) to give trades 'room to breathe'.`,
    examples: [
      "0: Normal operation (Recommended)",
      "5000: Stop trailing if balance drops below $5k"
    ],
    tips: [
      "Leave at 0 for standard operation."
    ],
    relatedInputs: ["trail_step_mode", "trail_step_cycle"],
    mt4Variable: "gInput_TrailStepBalance_{suffix}"
  },

  // ===== GENERAL / NEWS FILTERS =====
  {
    id: "news_filter_enabled",
    title: "News Filter Enabled",
    category: "general",
    shortDesc: "Turn on/off news avoidance",
    fullDesc: `Master switch for the News Filter system.

**When ON:**
The EA will download the economic calendar and pause trading around high-impact events (like NFP, FOMC, CPI).

**When OFF:**
The EA ignores all news events and trades continuously.`,
    tips: [
      "Highly recommended for scalping strategies.",
      "Requires 'Allow WebRequest' to be enabled in MT4/MT5 settings."
    ],
    mt4Variable: "gInput_EnableNewsFilter"
  },
  {
    id: "news_impact_level",
    title: "News Impact Level",
    category: "general",
    shortDesc: "Severity of news to filter (1-3)",
    fullDesc: `Determines which news events trigger a trading pause.

**Levels:**
- **1:** Filter ALL news (Low, Medium, High).
- **2:** Filter Medium & High impact news.
- **3:** Filter ONLY High impact news (Recommended).

**High Impact Events:**
- NFP (Non-Farm Payrolls)
- Interest Rate Decisions
- GDP Releases
- CPI (Inflation Data)`,
    mt4Variable: "gInput_NewsImpactLevel"
  },
  {
    id: "minutes_before_news",
    title: "Minutes Before News",
    category: "general",
    shortDesc: "Pause trading X minutes before event",
    fullDesc: `How long BEFORE the news event the EA should stop opening new trades.

**Example:**
If news is at 14:00 and this is set to **30**:
- EA stops trading at 13:30.
- This prevents opening trades right before volatility spikes.`,
    tips: ["30-60 minutes is standard for high impact news."],
    mt4Variable: "gInput_MinutesBeforeNews"
  },
  {
    id: "minutes_after_news",
    title: "Minutes After News",
    category: "general",
    shortDesc: "Resume trading X minutes after event",
    fullDesc: `How long AFTER the news event to wait before resuming trading.

**Purpose:**
News events often cause 'whipsaw' movement (violent ups and downs) for 15-30 minutes. This setting keeps you out of the market until the spread normalizes and direction is clear.`,
    tips: ["30 minutes is usually safe."],
    mt4Variable: "gInput_MinutesAfterNews"
  },

  // ===== LOGIC CONTROLS =====
  {
    id: "close_targets",
    title: "Close Targets",
    category: "logic",
    shortDesc: "Which logics to close when THIS logic hits profit target",
    fullDesc: `**This is one of the most powerful features in the system!**

Close Targets defines cross-logic coordination - when one logic takes profit, it can also close positions from other logics.

**Format:** Comma-separated logic labels
Example: "Logic_A_Power,Logic_A_Repower,Logic_A_Scalp"

**How It Works:**
1. RPO logic hits its trail/profit target
2. System reads RPO's CloseTargets list
3. Closes ALL positions from logics in that list
4. Allows one "winning" logic to bail out others

**Strategy Use Cases:**
- **Coordinated exit:** Main logic profits → close support logics
- **Risk reduction:** RPO hits target → close all Engine A positions
- **Cross-engine:** C-Engine profit → close A & B engine positions

**Available Logic Labels:**
Engine A: Logic_A_Power, Logic_A_Repower, Logic_A_Scalp, Logic_A_Stopper, Logic_A_STO, Logic_A_SCA, Logic_A_RPO
Engine B: Logic_B_Power, Logic_B_Repower, etc.
Engine C: Logic_C_Power, Logic_C_Repower, etc.`,
    examples: [
      "Self only: 'Logic_A_Repower' (close only this logic)",
      "Engine A all: 'Logic_A_Power,Logic_A_Repower,Logic_A_Scalp,Logic_A_Stopper,Logic_A_STO,Logic_A_SCA,Logic_A_RPO'",
      "Cross-engine: 'Logic_A_Power,Logic_B_Power,Logic_C_Power' (all Powers close together)"
    ],
    tips: [
      "Order matters for some strategies - list main logic first",
      "Remove a logic from list to prevent it from being closed",
      "Test cross-logic coordination in backtester first"
    ],
    relatedInputs: ["order_count_reference"],
    mt4Variable: "gInput_CloseTargets_{logic}"
  },
  {
    id: "order_count_reference",
    title: "Order Count Reference",
    category: "logic",
    shortDesc: "Which logic's order count to use for grid level calculation",
    fullDesc: `Controls how the current grid level is determined.

**Why This Matters:**
Grid level affects: lot sizing, trigger conditions, and profit targets.

**Options:**
- **Logic_Self:** Use this logic's own order count
- **Logic_Power/Repower/etc.:** Reference another logic's count

**Use Cases:**
- **Independent:** Each logic manages its own grid (Logic_Self)
- **Synchronized:** Multiple logics share grid level (reference main logic)
- **Offset:** Start secondary logic only after primary reaches level N`,
    examples: [
      "Logic_Self: Repower manages its own 1-2-3-4-5 levels",
      "Logic_Power: Repower uses Power's level (if Power is at level 3, Repower acts as if at level 3)"
    ],
    tips: [
      "Use Logic_Self for independent operation",
      "Reference main logic for coordinated grid strategies",
      "Helps with lot sizing synchronization"
    ],
    relatedInputs: ["close_targets", "start_level"],
    mt4Variable: "gInput_{Logic}_OrderCountReference"
  },
  {
    id: "start_level",
    title: "Start Level",
    category: "logic",
    shortDesc: "Grid level at which this logic activates",
    fullDesc: `Defines the minimum grid level required before this logic can open positions.

**Purpose:**
- Delays activation of secondary/support logics
- Reduces early exposure
- Creates layered entry strategy

**Example:**
- Power: Start Level = 1 (activates immediately)
- Repower: Start Level = 4 (waits for Power to reach level 4)
- Scalper: Start Level = 6 (deep recovery support only)

**Grid Level Progression:**
Level 1 → Level 2 → Level 3 → Level 4 (Repower joins) → Level 5 → Level 6 (Scalper joins)...`,
    examples: [
      "Primary logic: Start Level = 1",
      "Secondary support: Start Level = 3-4",
      "Deep recovery: Start Level = 6+"
    ],
    tips: [
      "Higher start level = less frequent activation",
      "Consider order_count_reference for shared level counting",
      "Test different combinations in backtester"
    ],
    relatedInputs: ["order_count_reference", "grid"],
    mt4Variable: "gInput_Start{Logic}"
  },
  {
    id: "last_lot",
    title: "Last Lot",
    category: "safety",
    shortDesc: "Maximum lot size limit for this logic",
    fullDesc: `A safety cap that prevents lot sizes from exceeding this value, regardless of multiplier calculations.

**How It Works:**
- Normal progression: 0.02 → 0.03 → 0.045 → 0.0675...
- With Last Lot = 0.05: 0.02 → 0.03 → 0.045 → 0.05 → 0.05...
- Lots are capped, not the grid level

**Risk Management:**
- Prevents runaway position sizing
- Limits maximum single-position exposure
- Critical for prop firm compliance`,
    examples: [
      "Conservative: 0.05 last lot",
      "Moderate: 0.12 last lot",
      "Based on max risk: Calculate from max acceptable $ risk"
    ],
    tips: [
      "Set based on your broker's max lot and risk tolerance",
      "Lower last_lot = more grid levels to recover",
      "Consider broker margin requirements"
    ],
    relatedInputs: ["initial_lot", "multiplier"],
    mt4Variable: "gInput_LastLot{Logic}"
  },
  {
    id: "reset_lot_on_restart",
    title: "Reset Lot on Restart",
    category: "logic",
    shortDesc: "Reset to initial lot when reopening after full close",
    fullDesc: `Controls whether the lot size resets when starting a new grid sequence.

**When ON:**
- After closing all positions, next sequence starts with initial_lot
- Clean slate for each new grid cycle

**When OFF:**
- Remembers last used lot size
- Continues progression from where it left off
- Useful for maintaining momentum after partial closes`,
    examples: [
      "ON: Fresh start each cycle (recommended for most)",
      "OFF: Continue progression (for specific strategies)"
    ],
    tips: [
      "Leave ON unless you have a specific reason",
      "OFF can lead to large starting lots after drawdown recovery"
    ],
    relatedInputs: ["initial_lot", "multiplier"],
    mt4Variable: "gInput_{Logic}_ResetLotOnRestart"
  },

  // ===== REVERSE/HEDGE =====
  {
    id: "reverse_enabled",
    title: "Reverse Enabled",
    category: "reverse_hedge",
    shortDesc: "Flip trade direction: counter-trend becomes trend-follow",
    fullDesc: `**Advanced Feature:** Reverse Mode flips the direction of trades.

**Normal Operation:**
- Logic detects BUY signal → Opens BUY position

**With Reverse Enabled:**
- Logic detects BUY signal → Opens SELL position instead
- Complete 180° flip of trading direction

**Use Cases:**
- Convert counter-trend logic to trend-following
- Test opposite hypothesis
- Create balanced long/short exposure

**How It Works with Scale:**
1. Signal triggers (e.g., BUY)
2. Reverse flips to SELL
3. Lot size = Original lot × Reverse Scale %
4. Order opens with [REV] comment tag`,
    examples: [
      "Reverse Enabled + 100% Scale: Full opposite position",
      "Reverse Enabled + 50% Scale: Half-size opposite position"
    ],
    tips: [
      "Start with 100% scale to test concept",
      "Monitor both directions for correlation",
      "Can help hedge overall portfolio exposure"
    ],
    relatedInputs: ["reverse_scale", "reverse_reference", "hedge_enabled"],
    mt4Variable: "gInput_G{group}_{logic}_ReverseEnabled"
  },
  {
    id: "hedge_enabled",
    title: "Hedge Enabled",
    category: "reverse_hedge",
    shortDesc: "Open opposite position to hedge existing exposure",
    fullDesc: `**Advanced Feature:** Hedge Mode creates offsetting positions.

**How It Differs from Reverse:**
- **Reverse:** Flips the signal direction
- **Hedge:** Opens BOTH directions (original + opposite)

**Use Cases:**
- Lock in floating profit during uncertainty
- Reduce net exposure while maintaining position
- Create spread/arbitrage setups

**How It Works:**
1. Logic opens normal position
2. Hedge opens opposite position (scaled by Hedge Scale)
3. Net exposure = Original - Hedge
4. Hedge orders tagged with [HEDGE]`,
    examples: [
      "50% Hedge: BUY 0.10 + SELL 0.05 = Net 0.05 long",
      "100% Hedge: BUY 0.10 + SELL 0.10 = Fully hedged/locked"
    ],
    tips: [
      "Hedging has cost (spread × 2)",
      "Use for temporary protection, not permanent",
      "Check if your broker allows hedging"
    ],
    relatedInputs: ["hedge_scale", "hedge_reference", "reverse_enabled"],
    mt4Variable: "gInput_G{group}_{logic}_HedgeEnabled"
  },
  {
    id: "reverse_scale",
    title: "Reverse Scale",
    category: "reverse_hedge",
    shortDesc: "Lot size percentage for reversed trades (100% = same size)",
    fullDesc: `Controls the position size of reversed trades as a percentage.

**Values:**
- **100%:** Reversed trade same size as original
- **50%:** Reversed trade half size
- **200%:** Reversed trade double size (aggressive)

**Example:**
- Original signal would open 0.10 lots BUY
- Reverse Scale = 75%
- Opens 0.075 lots SELL instead`,
    examples: [
      "100%: Full reversal",
      "50%: Partial reversal (reduced exposure)",
      "150%: Overweight reversal"
    ],
    tips: [
      "Start conservative with 50-100%",
      "Higher scale = more exposure to reversed direction"
    ],
    relatedInputs: ["reverse_enabled", "reverse_reference"],
    mt4Variable: "gInput_G{group}_Scale_{logic}_Reverse"
  },
  {
    id: "hedge_scale",
    title: "Hedge Scale",
    category: "reverse_hedge",
    shortDesc: "Lot size percentage for hedge trades (50% = half size)",
    fullDesc: `Controls the position size of hedge trades as a percentage of the main position.

**Values:**
- **100%:** Full hedge (complete offset)
- **50%:** Half hedge (reduces exposure by 50%)
- **25%:** Light hedge (minor protection)

**Net Exposure Calculation:**
- Main: 0.10 lots LONG
- Hedge Scale: 60%
- Hedge: 0.06 lots SHORT
- Net: 0.04 lots LONG`,
    examples: [
      "100%: Fully locked position",
      "50%: Half exposure remaining",
      "25%: Light protection"
    ],
    tips: [
      "Full hedge locks profit but costs double spread",
      "Partial hedge reduces risk while maintaining direction",
      "Consider hedge_reference for targeting specific logic"
    ],
    relatedInputs: ["hedge_enabled", "hedge_reference"],
    mt4Variable: "gInput_G{group}_Scale_{logic}_Hedge"
  },
  {
    id: "reverse_reference",
    title: "Reverse Reference",
    category: "reverse_hedge",
    shortDesc: "Which logic's signals to reverse against",
    fullDesc: `Specifies which logic's signals this reverse mode should flip.

**Options:**
- **Logic_None:** Disabled
- **Logic_Self:** Reverse this logic's own signals
- **Logic_Power/Repower/etc.:** Reverse based on another logic's signals

**Use Case:**
Secondary logic can reverse based on primary logic's signals, creating coordinated opposite positions.`,
    examples: [
      "Logic_Self: Reverse own signals",
      "Logic_Power: Open opposite to Power's direction"
    ],
    relatedInputs: ["reverse_enabled", "reverse_scale"],
    mt4Variable: "gInput_G{group}_{logic}_ReverseReference"
  },
  {
    id: "hedge_reference",
    title: "Hedge Reference",
    category: "reverse_hedge",
    shortDesc: "Which logic's positions to hedge against",
    fullDesc: `Specifies which logic's positions trigger hedge orders.

**Options:**
- **Logic_None:** Disabled
- **Logic_Self:** Hedge this logic's own positions
- **Logic_Power/Repower/etc.:** Hedge based on another logic's positions

**Use Case:**
One logic can act as a "hedge engine" for another logic's positions.`,
    examples: [
      "Logic_Self: Hedge own positions",
      "Logic_Power: Create hedges when Power opens positions"
    ],
    relatedInputs: ["hedge_enabled", "hedge_scale"],
    mt4Variable: "gInput_G{group}_{logic}_HedgeReference"
  },

  // ===== CLOSE PARTIAL =====
  {
    id: "close_partial",
    title: "Close Partial",
    category: "close_partial",
    shortDesc: "Enable partial position closing on profit targets",
    fullDesc: `Allows closing a portion of profitable positions instead of all-or-nothing.

**Benefits:**
- Lock in some profit while letting rest run
- Reduce exposure progressively
- More flexible exit management

**How It Works:**
1. Positions reach profit threshold
2. System identifies positions to close (based on Partial Mode)
3. Closes every Nth position (based on Partial Cycle)
4. Remaining positions continue with trail`,
    examples: [
      "ON: Gradually take profit from winning grid",
      "OFF: Close all or nothing (simpler)"
    ],
    tips: [
      "Good for volatile markets",
      "Reduces sudden large drawdowns",
      "Test parameters in backtester"
    ],
    relatedInputs: ["close_partial_cycle", "close_partial_mode", "close_partial_balance"],
    mt4Variable: "gInput_ClosePartial_{suffix}"
  },
  {
    id: "close_partial_cycle",
    title: "Partial Cycle",
    category: "close_partial",
    shortDesc: "Close every Nth position in profit sequence",
    fullDesc: `Controls frequency of partial closes.

**Values:**
- **1:** Close every profitable position (aggressive)
- **2:** Close every 2nd profitable position
- **3:** Close every 3rd profitable position (balanced)
- **5+:** Less frequent closes

**Example (Cycle = 3):**
5 positions in profit → Close positions 3 and 6 (skip 1,2,4,5)`,
    examples: [
      "Cycle 2: Close half of winners",
      "Cycle 3: Close third of winners",
      "Cycle 5: Close 20% of winners"
    ],
    relatedInputs: ["close_partial", "close_partial_mode"],
    mt4Variable: "gInput_ClosePartialCycle_{suffix}"
  },
  {
    id: "close_partial_mode",
    title: "Partial Mode",
    category: "close_partial",
    shortDesc: "Which positions to prioritize for partial close",
    fullDesc: `Determines the order in which positions are selected for partial closing.

**Modes:**
- **PartialMode_Low:** Close lowest-profit positions first
  - Locks in smaller wins, lets bigger run
- **PartialMode_High:** Close highest-profit positions first
  - Secures big wins, risks smaller ones
- **PartialMode_Balanced:** Alternate between low and high
  - Diversified approach`,
    examples: [
      "PartialMode_Low: Conservative - secure small wins",
      "PartialMode_High: Aggressive - grab big wins first",
      "PartialMode_Balanced: Best of both worlds"
    ],
    relatedInputs: ["close_partial", "close_partial_cycle", "close_partial_balance"],
    mt4Variable: "gInput_ClosePartialMode_{suffix}"
  },
  {
    id: "close_partial_balance",
    title: "Partial Balance",
    category: "close_partial",
    shortDesc: "Risk profile for partial close decisions",
    fullDesc: `Sets the risk tolerance for partial close operations.

**Options:**
- **PartialBalance_Aggressive:** Close more frequently
- **PartialBalance_Balanced:** Moderate frequency
- **PartialBalance_Conservative:** Close less frequently

Affects internal thresholds for what qualifies as "in profit" for partial close.`,
    relatedInputs: ["close_partial", "close_partial_mode"],
    mt4Variable: "gInput_ClosePartialBalance_{suffix}"
  },

  // ===== TPSL =====
  {
    id: "use_tp",
    title: "Use TP",
    category: "tpsl",
    shortDesc: "Enable fixed take-profit for individual positions",
    fullDesc: `Enables a hard take-profit level for each position.

**Difference from Trailing:**
- **TP:** Fixed level set at order open, doesn't move
- **Trail:** Dynamic level that follows price

**When to Use:**
- Known profit targets
- Quick scalping exits
- Combined with trail for layered exits`,
    tips: [
      "TP exits faster but may miss larger moves",
      "Consider using with partial close for best of both"
    ],
    relatedInputs: ["tp_mode", "tp_value", "use_sl"],
    mt4Variable: "gInput_G{group}_UseTP_{logic}"
  },
  {
    id: "use_sl",
    title: "Use SL",
    category: "tpsl",
    shortDesc: "Enable fixed stop-loss for individual positions",
    fullDesc: `Enables a hard stop-loss level for each position.

**Risk Management:**
- Limits loss per position
- Overrides other exit logic
- Broker-level protection (works even if EA crashes)

**Warning:**
Grid strategies often DON'T use SL because:
- Grid is designed to average down
- SL would close positions meant to be held
- Use account-level protection instead`,
    tips: [
      "Grid strategies typically leave this OFF",
      "Use for anti-martingale or fixed-risk strategies",
      "Consider equity-based stops instead"
    ],
    relatedInputs: ["sl_mode", "sl_value", "use_tp"],
    mt4Variable: "gInput_G{group}_UseSL_{logic}"
  },

  // ===== TRIGGERS =====
  {
    id: "trigger_type",
    title: "Trigger Type",
    category: "triggers",
    shortDesc: "Entry signal/trigger type for Group 1",
    fullDesc: `Defines what type of signal triggers new position entries.

**Common Types:**
- **Default:** Use logic's built-in signal
- **Manual:** Require manual confirmation
- **External:** Wait for external indicator signal

This is a Group 1 specific setting as Group 1 handles initial entries.`,
    relatedInputs: ["trigger_bars", "trigger_minutes"],
    mt4Variable: "gInput_G1_TriggerType_{suffix}"
  },
  {
    id: "trigger_bars",
    title: "Trigger Bars",
    category: "triggers",
    shortDesc: "Bars to wait before confirming trigger",
    fullDesc: `Number of candlestick bars to wait before confirming an entry signal.

**Purpose:**
- Filter out false breakouts
- Wait for confirmation
- Reduce overtrading

**Example:**
- Signal appears on Bar 0
- Trigger Bars = 3
- Entry only if signal still valid after 3 bars close`,
    examples: [
      "1-2 bars: Quick confirmation",
      "3-5 bars: Moderate filter",
      "10+ bars: Strong confirmation (may miss entries)"
    ],
    relatedInputs: ["trigger_type", "trigger_minutes"],
    mt4Variable: "gInput_G1_TriggerBars_{suffix}"
  },
  {
    id: "trigger_minutes",
    title: "Trigger Minutes",
    category: "triggers",
    shortDesc: "Minutes to wait before triggering entry",
    fullDesc: `Time-based delay before executing entry after signal.

**Purpose:**
- Prevent rapid re-entries
- Time-based filtering
- Cooldown period

**Example:**
- Signal triggers at 10:00
- Trigger Minutes = 15
- Entry only after 10:15 if conditions still met`,
    examples: [
      "5 min: Quick cooldown",
      "15 min: Standard filter",
      "60 min: Hourly entries only"
    ],
    relatedInputs: ["trigger_type", "trigger_bars"],
    mt4Variable: "gInput_G1_TriggerMinutes_{suffix}"
  },
  {
    id: "trigger_pips",
    title: "Trigger Pips",
    category: "triggers",
    shortDesc: "Minimum price movement in pips before triggering entry",
    fullDesc: `Price threshold filter for entry signals. Signal must show at least N pips of price movement before executing.

**Purpose:**
- Filter market noise
- Ensure minimum momentum
- Prevent entries on tiny moves

**Example:**
- Trigger Pips = 5.0
- Signal appears at 1.10000
- Price must move to 1.10050 (5 pips = 50 points on 5-digit)
- Only then will entry execute`,
    examples: [
      "0.0: No pip filter (immediate entry)",
      "5.0 pips: Light noise filter",
      "10.0 pips: Medium momentum requirement",
      "20.0 pips: Strong breakout confirmation"
    ],
    relatedInputs: ["trigger_type", "trigger_bars", "trigger_minutes"],
    mt4Variable: "gInput_G1_TriggerPips_{suffix}"
  },

  // ===== CONCEPTS =====
  {
    id: "concept_engine",
    title: "Engines (A, B, C)",
    category: "concepts",
    shortDesc: "Independent trading modules with 7 logics each",
    fullDesc: `The DAAVFX system has 3 independent engines, each with 7 logics.

**Engine Structure:**
- **Engine A:** Primary engine (Logic_A_Power, Logic_A_Repower, etc.)
- **Engine B:** Secondary engine (Logic_B_Power, Logic_B_Repower, etc.)
- **Engine C:** Tertiary engine (Logic_C_Power, Logic_C_Repower, etc.)

**Each Engine Has 7 Logics:**
1. Power - Main logic
2. Repower - Power support
3. Scalper - Quick recovery
4. Stopper - Counter-trend
5. STO - Stopper support
6. SCA - Scalper support
7. RPO - Recovery/backup

**Independence:**
- Each engine can trade different pairs or strategies
- Engines can be coordinated via CloseTargets
- 3 × 7 = 21 total logics available`,
    tips: [
      "Start with Engine A only",
      "Add Engine B/C for diversification or different pairs",
      "CloseTargets can coordinate across engines"
    ]
  },
  {
    id: "concept_groups",
    title: "Groups (1-20)",
    category: "concepts",
    shortDesc: "Parameter layers for each logic (Group 1 = initial, 2-20 = grid levels)",
    fullDesc: `Each logic has 20 Groups - sets of parameters for different grid levels.

**Group 1: Initial Entry**
- First position in a new sequence
- Has Trigger settings (entry conditions)
- Usually widest grid, lowest lot

**Groups 2-20: Grid Levels**
- Activated as grid deepens
- Progressively tighter grids
- Can have different lot progressions

**Why Multiple Groups?**
- Different behavior at different grid depths
- Escalating recovery at deeper levels
- Fine-grained control over progression`,
    examples: [
      "Group 1: Wide grid (2750), low lot (0.02)",
      "Group 2-5: Medium grid (500), multiplied lots",
      "Group 6+: Tight grid (300), capped lots"
    ]
  },
  {
    id: "concept_magic",
    title: "Magic Numbers",
    category: "concepts",
    shortDesc: "Unique identifiers for orders from each logic",
    fullDesc: `Every order has a Magic Number that identifies which logic created it.

**Purpose:**
- Track which logic owns which orders
- Prevent interference between logics
- Enable CloseTargets cross-logic coordination

**Structure:**
Magic = Base + LogicIndex + GroupIndex

The system automatically manages magic numbers - you don't set them directly.`,
    tips: [
      "Magic numbers are internal - no user configuration needed",
      "Useful for debugging in MT4/MT5 terminal",
      "Check order comments for [REV] or [HEDGE] tags"
    ]
  },
  {
    id: "concept_points_pips",
    title: "Points vs Pips",
    category: "concepts",
    shortDesc: "Understanding price measurement units",
    fullDesc: `**Points and Pips are often confused:**

**5-Digit Brokers (Most Common):**
- 1 pip = 10 points
- EURUSD: 1.12345 → 5th decimal is points, 4th is pips
- 100 points = 10 pips

**4-Digit Brokers:**
- 1 pip = 1 point
- EURUSD: 1.1234 → 4th decimal

**In This System:**
- All values are in POINTS
- Grid 300 = 30 pips
- Trail 3000 = 300 pips

**Quick Conversion:**
Divide points by 10 to get pips on 5-digit brokers`,
    examples: [
      "300 points = 30 pips = ~$3 per 0.1 lot on EURUSD",
      "1000 points = 100 pips = ~$10 per 0.1 lot"
    ]
  }
];

// =============================================================================
// SEARCH AND LOOKUP FUNCTIONS
// =============================================================================
export const getHelpById = (id: string): HelpEntry | undefined => {
  return HELP_ENTRIES.find(entry => entry.id === id);
};

export const getHelpByCategory = (categoryId: string): HelpEntry[] => {
  return HELP_ENTRIES.filter(entry => entry.category === categoryId);
};

export const searchHelp = (query: string): HelpEntry[] => {
  const q = query.toLowerCase();
  return HELP_ENTRIES.filter(entry =>
    entry.title.toLowerCase().includes(q) ||
    entry.shortDesc.toLowerCase().includes(q) ||
    entry.fullDesc.toLowerCase().includes(q) ||
    entry.id.toLowerCase().includes(q)
  );
};

export const getCategoryById = (id: string): HelpCategory | undefined => {
  return HELP_CATEGORIES.find(cat => cat.id === id);
};
