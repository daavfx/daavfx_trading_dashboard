import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ChevronRight,
  Shield,
  Newspaper,
  Clock,
  Key,
  Settings2,
  Palette,
  FileText,
  TrendingUp,
  RotateCw,
  Terminal,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { ConfigField } from "./ConfigField";
import { Platform } from "@/components/layout/TopBar";
import type { GeneralConfig, Platform as MTPlatform } from "@/types/mt-config";
import { generalInputs } from "@/data/general-inputs";

interface GeneralCategoriesProps {
  platform: Platform;
  allCollapsed?: boolean;
  generalConfig?: GeneralConfig;
  mtPlatform?: MTPlatform;
  selectedCategory?: string;
  onSelectGeneralCategory?: (category: string | null) => void;
}

export const generalCategoriesList = [
  { id: "risk_management", label: "Risk Management", icon: Shield, color: "text-red-400" },
  { id: "compounding", label: "Compounding", icon: TrendingUp, color: "text-indigo-400" },
  { id: "restart_policy", label: "Restart Policy", icon: RotateCw, color: "text-orange-400" },
  { id: "news", label: "News Filter", icon: Newspaper, color: "text-amber-400" },
  { id: "time", label: "Time Filter", icon: Clock, color: "text-blue-400" },
  { id: "license", label: "License", icon: Key, color: "text-purple-400" },
  { id: "general", label: "General", icon: Settings2, color: "text-slate-400" },
  { id: "ui", label: "UI Settings", icon: Palette, color: "text-teal-400" },
  { id: "logs", label: "Logs", icon: Terminal, color: "text-green-400" },
] as const;

export function GeneralCategories({ 
  platform, 
  allCollapsed, 
  generalConfig, 
  mtPlatform, 
  selectedCategory,
  onSelectGeneralCategory 
}: GeneralCategoriesProps) {
  const [expandedCategories, setExpandedCategories] = useState<string[]>(["risk_management"]);

  const toggleCategory = (id: string) => {
    setExpandedCategories((prev) =>
      prev.includes(id) ? prev.filter((c) => c !== id) : [...prev, id]
    );
  };

  const expandAll = () => setExpandedCategories(generalCategoriesList.map((c) => c.id));
  const collapseAll = () => setExpandedCategories([]);

  // Helper to map type string to "number" | "toggle" | "text" | "select"
  const mapType = (type: string): "number" | "toggle" | "text" | "select" | "header" => {
    if (type === "bool") return "toggle";
    if (type === "int" || type === "double") return "number";
    if (type === "enum") return "select";
    if (type === "header") return "header";
    return "text";
  };

  // Map real config to fields
  const getRealCategoryFields = (categoryId: string) => {
    if (!generalConfig) return [];

    switch (categoryId) {
      case "risk_management":
        return generalInputs.risk_management.fields.map(field => ({
          id: field.id,
          label: field.mt4_variable.replace("gInput_", "").replace(/([A-Z])/g, ' $1').trim(),
          value: generalConfig.risk_management?.[field.id as keyof typeof generalConfig.risk_management] ?? field.default,
          type: mapType(field.type),
          unit: (field as any).unit,
          description: field.description,
          options: (field as any).options
        }));

      case "time":
        return generalInputs.time_filters.fields.map(field => {
          let value;
          const sessionIdMatch = field.id.match(/^session_(\d+)_(.+)$/);
          
          if (sessionIdMatch) {
             const sessionIndex = parseInt(sessionIdMatch[1]) - 1;
             const propName = sessionIdMatch[2];
             
             if (propName === "header") {
               value = ""; 
             } else {
               // Access session property dynamically
               // @ts-ignore
               value = generalConfig.time_filters?.sessions?.[sessionIndex]?.[propName] ?? field.default;
             }
          } else {
             // Priority settings
             // @ts-ignore
             value = generalConfig.time_filters?.priority_settings?.[field.id] ?? field.default;
          }

          return {
            id: field.id,
            label: (field as any).label || field.mt4_variable.replace("gInput_TimeFilter_", "").replace(/([A-Z])/g, ' $1').trim(),
            value: value,
            type: mapType(field.type),
            unit: (field as any).unit,
            description: field.description,
            options: (field as any).options
          };
        });

      case "news":
        return generalInputs.news_filter.fields.map(field => ({
          id: field.id,
          label: field.mt4_variable.replace("gInput_", "").replace(/([A-Z])/g, ' $1').trim(),
          value: generalConfig.news_filter?.[field.id as keyof typeof generalConfig.news_filter] ?? field.default,
          type: mapType(field.type),
          unit: (field as any).unit,
          description: field.description,
          options: (field as any).options
        }));

      case "license":
        return generalInputs.license.fields.map(field => ({
          id: field.id,
          label: field.mt4_variable.replace("gInput_", "").replace(/([A-Z])/g, ' $1').trim(),
          value: generalConfig[field.id as keyof GeneralConfig] ?? field.default,
          type: mapType(field.type),
          unit: (field as any).unit,
          description: field.description
        }));
        
      case "general":
        return generalInputs.global_system.fields.map(field => ({
          id: field.id,
          label: field.mt4_variable.replace("gInput_", "").replace(/([A-Z])/g, ' $1').trim(),
          value: generalConfig[field.id as keyof GeneralConfig] ?? field.default,
          type: mapType(field.type),
          unit: (field as any).unit,
          description: field.description
        }));
        
      case "compounding":
        return generalInputs.compounding.fields.map(field => ({
          id: field.id,
          label: field.mt4_variable.replace("gInput_", "").replace(/([A-Z])/g, ' $1').trim(),
          // Prefix with 'compounding_' because they are flattened in GeneralConfig but names in generalInputs are 'enabled', 'type' etc.
          value: generalConfig[`compounding_${field.id}` as keyof GeneralConfig] ?? field.default,
          type: mapType(field.type),
          unit: (field as any).unit,
          description: field.description,
          options: (field as any).options
        }));
        
      case "restart_policy":
        return generalInputs.restart_policies.fields.map(field => ({
          id: field.id,
          label: field.mt4_variable.replace("gInput_", "").replace(/([A-Z])/g, ' $1').trim(),
          value: generalConfig[field.id as keyof GeneralConfig] ?? field.default,
          type: mapType(field.type),
          unit: (field as any).unit,
          description: field.description,
          options: (field as any).options
        }));

      case "logs":
         return [
           { id: "enable_logs", label: "Enable Logs", value: generalConfig.enable_logs ? "ON" : "OFF", type: "toggle" as const, description: "Enable detailed logging (gInput_EnableLogs)" }
         ];
         
      case "ui":
        return [
          { id: "theme", label: "Theme", value: "Dark", type: "text" as const, description: "UI Theme" },
          { id: "language", label: "Language", value: "English", type: "text" as const, description: "UI Language" }
        ];

      default:
        return [];
    }
  };

  // Single Category View Mode
  if (selectedCategory) {
    const fields = getRealCategoryFields(selectedCategory);
    return (
      <div className="grid grid-cols-2 gap-4">
        {fields.map((field) => (
          field.type === "header" ? (
             <div key={field.id} className="col-span-2 mt-6 mb-2 pb-1 border-b border-white/10 flex items-center gap-2">
                <div className="w-1 h-4 bg-primary/50 rounded-full" />
                <h3 className="text-sm font-semibold text-primary/90 tracking-wide uppercase">{field.label}</h3>
             </div>
          ) : (
          <ConfigField
            key={field.id}
            label={field.label}
            value={field.value}
            type={field.type as any}
            unit={field.unit}
            description={field.description}
            options={field.options}
          />
          )
        ))}
      </div>
    );
  }

  // Accordion View Mode (for Sidebar if needed, or if no category selected)
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs text-muted-foreground">General Parameters</span>
        <div className="flex gap-1">
          <button
            onClick={expandAll}
            className="text-[10px] text-muted-foreground hover:text-foreground px-2 py-1 rounded hover:bg-muted/30 transition-colors"
          >
            Expand All
          </button>
          <button
            onClick={collapseAll}
            className="text-[10px] text-muted-foreground hover:text-foreground px-2 py-1 rounded hover:bg-muted/30 transition-colors"
          >
            Collapse All
          </button>
        </div>
      </div>

      {generalCategoriesList.map((category) => {
        const Icon = category.icon;
        const fields = getRealCategoryFields(category.id);
        const expanded = expandedCategories.includes(category.id);
        const filledCount = fields.filter((f) => f.value !== "-" && f.value !== "").length;

        return (
          <div
            key={category.id}
            className="rounded border border-border/40 bg-card/30 overflow-hidden"
          >
            <button
              onClick={() => toggleCategory(category.id)}
              className="w-full px-4 py-3 flex items-center justify-between hover:bg-muted/20 transition-colors"
            >
              <div className="flex items-center gap-3">
                <motion.div
                  animate={{ rotate: expanded ? 90 : 0 }}
                  transition={{ duration: 0.1 }}
                >
                  <ChevronRight className="w-3.5 h-3.5 text-muted-foreground" />
                </motion.div>
                <Icon className={cn("w-4 h-4", category.color)} />
                <span className="text-sm font-medium">{category.label}</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-16 h-1.5 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-accent/70 rounded-full transition-all"
                    style={{ width: `${(filledCount / fields.length) * 100}%` }}
                  />
                </div>
                <span className="text-[10px] text-muted-foreground font-mono w-8">
                  {filledCount}/{fields.length}
                </span>
              </div>
            </button>

            <AnimatePresence>
              {expanded && (
                <motion.div
                  initial={{ height: 0 }}
                  animate={{ height: "auto" }}
                  exit={{ height: 0 }}
                  transition={{ duration: 0.15 }}
                  className="overflow-hidden"
                >
                  <div className="px-4 pb-4 pt-1 grid grid-cols-2 gap-2">
                    {fields.map((field) => (
                      <ConfigField
                        key={field.id}
                        label={field.label}
                        value={field.value}
                        type={field.type}
                        unit={field.unit}
                        description={field.description}
                        options={field.options}
                      />
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
}
