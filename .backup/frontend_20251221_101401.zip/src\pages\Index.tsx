import { useState, useEffect } from "react";
import { invoke } from "@tauri-apps/api/core";
import { toast } from "sonner";
import { TopBar, Platform } from "@/components/layout/TopBar";
import { Sidebar, ViewMode } from "@/components/layout/Sidebar";
import { ChatPanel } from "@/components/layout/ChatPanel";
import { BatchEditPanel } from "@/components/config/BatchEditPanel";
import { EngineCard } from "@/components/config/EngineCard";
import { GeneralCategories } from "@/components/config/GeneralCategories";
import { MultiEditIndicator } from "@/components/config/MultiEditIndicator";
import { EmptyState } from "@/components/config/EmptyState";
import { FooterRibbon } from "@/components/config/FooterRibbon";
import { VaultSaveModal } from "@/components/config/VaultSaveModal";
import { VaultManager } from "@/components/config/VaultManager";
import { SettingsDrawer } from "@/components/config/SettingsDrawer";
import { BatchEditTab } from "@/components/config/BatchEditTab";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { useMTConfig, useConfigUpdater } from "@/hooks/useMTConfig";
import type { Platform as MTPlatform, GeneralConfig, MTConfig } from "@/types/mt-config";
import { mockFullConfig } from "@/data/mock-config";

import {
  ResizableHandle,
  ResizablePanel,
  ResizablePanelGroup,
} from "@/components/ui/resizable";

import { SingleEditContext } from "@/components/config/SingleEditContext";

// Mock data for when config is not loaded
const mockGeneralConfig: GeneralConfig = {
  license_key: "",
  license_server_url: "https://license.daavfx.com",
  require_license: true,
  license_check_interval: 3600,
  config_file_name: "DAAVFX_Config.json",
  config_file_is_common: true,
  allow_buy: true,
  allow_sell: true,
  enable_logs: true,
  compounding_enabled: false,
  compounding_type: "Compound_Balance",
  compounding_target: 40.0,
  compounding_increase: 2.0,
  restart_policy_power: "Restart_Default",
  restart_policy_non_power: "Restart_Default",
  close_non_power_on_power_close: false,
  hold_timeout_bars: 10,
  magic_number: 777,
  max_slippage_points: 30.0,
  risk_management: {
    spread_filter_enabled: false,
    max_spread_points: 25.0,
    equity_stop_enabled: false,
    equity_stop_value: 35.0,
    drawdown_stop_enabled: false,
    max_drawdown_percent: 35.0
  },
  time_filters: {
    priority_settings: {
      news_filter_overrides_session: false,
      session_filter_overrides_news: true
    },
    sessions: Array.from({ length: 7 }, (_, i) => ({
      session_number: i + 1,
      enabled: false,
      day: i % 7,
      start_hour: 9,
      start_minute: 30,
      end_hour: 17,
      end_minute: 0,
      action: "TriggerAction_StopEA_KeepTrades",
      auto_restart: true,
      restart_mode: "Restart_Immediate",
      restart_bars: 0,
      restart_minutes: 0,
      restart_pips: 0
    }))
  },
  news_filter: {
    enabled: false,
    api_key: "",
    api_url: "https://www.jblanked.com/news/api/calendar/",
    countries: "US,GB,EU",
    impact_level: 3,
    minutes_before: 30,
    minutes_after: 30,
    action: "TriggerAction_StopEA_KeepTrades"
  }
};

const engineConfigs = [
  { engine: "Engine A", tradingType: "Reverse Trading" },
  { engine: "Engine B", tradingType: "Hedge Trading" },
  { engine: "Engine C", tradingType: "Direct Trading" },
];

const canvasClasses: Record<Platform, string> = {
  mt4: "canvas-mt4", mt5: "canvas-mt5", python: "canvas-python",
  c: "canvas-c", cpp: "canvas-cpp", rust: "canvas-rust",
};

// Map UI platform to MT platform type
const platformToMT = (p: Platform): MTPlatform => {
  if (p === "mt4") return "MT4";
  if (p === "mt5") return "MT5";
  return "MT4"; // fallback
};

export default function Index() {
  const [selectedEngines, setSelectedEngines] = useState<string[]>([]);
  const [selectedGroups, setSelectedGroups] = useState<string[]>([]);
  const [selectedLogics, setSelectedLogics] = useState<string[]>([]);
  const [selectedFields, setSelectedFields] = useState<string[]>([]);
  const [vaultModalOpen, setVaultModalOpen] = useState(false);
  const [vaultManagerOpen, setVaultManagerOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [hasStarted, setHasStarted] = useState(false);
  const [platform, setPlatform] = useState<Platform>("mt5");
  const [viewMode, setViewMode] = useState<ViewMode>("logics");
  const [selectedGeneralCategory, setSelectedGeneralCategory] = useState<string>("risk");

  const handleViewModeChange = (mode: ViewMode) => {
    setViewMode(mode);
    setHasStarted(true);
  };

  const handleGeneralCategoryChange = (category: string) => {
    setSelectedGeneralCategory(category);
    setHasStarted(true);
  };

  // Wire up MT config hooks
  const mtPlatform = platformToMT(platform);
  const { config: realConfig, loading, loadConfig, saveConfig: realSaveConfig } = useMTConfig(mtPlatform);
  const { batchUpdateLogics } = useConfigUpdater(mtPlatform);

  const [mockConfig, setMockConfig] = useState<MTConfig | null>(null);
  const config = realConfig || mockConfig;

  const handleSaveConfig = async (newConfig: MTConfig) => {
    if (realConfig) {
      await realSaveConfig(newConfig);
    } else {
      setMockConfig(newConfig);
      toast.info("Updated mock configuration (not saved to disk)");
    }
  };

  const lastSavedLabel = config?.last_saved_at
    ? `Last saved ${new Date(config.last_saved_at).toLocaleString()}${config.current_set_name ? ` · ${config.current_set_name}` : ""}`
    : undefined;

  // Load config on mount or platform change
  useEffect(() => {
    loadConfig().then((loaded) => {
      if (!loaded) {
        console.log("Using mock data - config not loaded");
        setMockConfig(mockFullConfig);
      } else {
        setMockConfig(null);
      }
    }).catch(() => {
      console.log("Using mock data - config load failed");
      setMockConfig(mockFullConfig);
    });
  }, [loadConfig]);

  // Get real engine data from config or use mock
  const realEngineConfigs = config?.engines.map(engine => ({
    engine: `Engine ${engine.engine_id}`,
    tradingType: engine.engine_id === "A" ? "Multi-Logic System" : 
                 engine.engine_id === "B" ? "Hedge Trading" : "Direct Trading",
    engineData: engine
  })) || engineConfigs.map(e => ({ ...e, engineData: null }));

  const handleSelectionChange = (type: "engines" | "groups" | "logics", items: string[]) => {
    if (type === "engines") setSelectedEngines(items);
    if (type === "groups") setSelectedGroups(items);
    if (type === "logics") setSelectedLogics(items);
    
    // Auto-start when first selection made
    if (!hasStarted && items.length > 0) {
      setHasStarted(true);
    }
  };

  const handleChatNavigation = (target: { engines?: string[]; groups?: number[]; logics?: string[]; fields?: string[] }) => {
    setHasStarted(true);

    if (target.engines) {
      // Map "A" -> "Engine A"
      const mappedEngines = target.engines.map(e => e.startsWith("Engine") ? e : `Engine ${e}`);
      setSelectedEngines(mappedEngines);
    }
    
    if (target.groups) {
      // Map 1 -> "Group 1"
      const mappedGroups = target.groups.map(g => `Group ${g}`);
      setSelectedGroups(mappedGroups);
    }

    if (target.logics) {
      // Map "Power" -> "POWER"
      const mappedLogics = target.logics.map(l => l.toUpperCase());
      setSelectedLogics(mappedLogics);
    }

    if (target.fields) {
      setSelectedFields(target.fields);
    } else {
      setSelectedFields([]);
    }
    
    // Switch to logics view to see the result
    setViewMode("logics");
  };

  const handleVaultSave = async (data: { name: string; category: string; strategyType: "buy" | "sell" | "both"; tags: string[]; comments: string }) => {
    try {
      if (!config) {
        toast.error("No configuration loaded to save");
        return;
      }
      
      await invoke("save_to_vault", { 
        config, 
        name: data.name,
        category: data.category 
      });
      
      toast.success("Configuration saved to vault");
      setVaultModalOpen(false);
    } catch (error) {
      console.error("Failed to save to vault:", error);
      toast.error(`Failed to save to vault: ${error}`);
    }
  };

  const clearSelection = () => {
    setSelectedEngines([]);
    setSelectedGroups([]);
    setSelectedLogics([]);
  };

  const isGroup1Mode = selectedGroups.includes("Group 1") && selectedGroups.length === 1;
  const isMultiEdit = selectedEngines.length > 1 || selectedGroups.length > 1 || selectedLogics.length > 1;

  return (
    <div className="h-screen flex flex-col bg-background">
      <TopBar 
        onSaveToVault={() => setVaultModalOpen(true)}
        onOpenVaultManager={() => setVaultManagerOpen(true)}
        platform={platform}
        onPlatformChange={setPlatform}
        onOpenSettings={() => setSettingsOpen(true)}
        lastSavedLabel={lastSavedLabel}
      />
      
      <div className="flex-1 overflow-hidden">
        <ResizablePanelGroup direction="horizontal">
          <ResizablePanel defaultSize={18} minSize={15} maxSize={30}>
            <Sidebar
              selectedEngines={selectedEngines}
              selectedGroups={selectedGroups}
              selectedLogics={selectedLogics}
              onSelectionChange={handleSelectionChange}
              platform={platform}
              viewMode={viewMode}
              onViewModeChange={handleViewModeChange}
              selectedGeneralCategory={selectedGeneralCategory}
              onSelectGeneralCategory={handleGeneralCategoryChange}
            />
          </ResizablePanel>

          <ResizableHandle withHandle />

          <ResizablePanel defaultSize={62}>
            {hasStarted ? (
              <main className={cn("h-full flex flex-col overflow-hidden transition-colors duration-300", canvasClasses[platform])}>
                <ScrollArea className="flex-1">
                  <div className="p-5 max-w-4xl">
                    {/* Multi-Edit Indicator */}
                    {isMultiEdit && viewMode === "logics" && (
                      <MultiEditIndicator
                        selectedEngines={selectedEngines}
                        selectedGroups={selectedGroups}
                        selectedLogics={selectedLogics}
                        isGroup1Mode={isGroup1Mode}
                        onClearSelection={clearSelection}
                      />
                    )}

                    {viewMode === "logics" && (
                      <BatchEditPanel
                        selectedCount={{ 
                          engines: selectedEngines.length, 
                          groups: selectedGroups.length, 
                          logics: selectedLogics.length 
                        }}
                        platform={platform}
                        onClearEngines={() => setSelectedEngines([])}
                        onClearGroups={() => setSelectedGroups([])}
                        onClearLogics={() => setSelectedLogics([])}
                      />
                    )}

                    {viewMode === "logics" && (
                      <div className="space-y-3 mt-4">
                        {loading ? (
                          <div className="text-center py-8 text-muted-foreground">
                            Loading configuration...
                          </div>
                        ) : (
                          realEngineConfigs
                            .filter(ec => selectedEngines.includes(ec.engine))
                            .map((engineConfig, idx) => (
                            <EngineCard
                              key={`${engineConfig.engine}-${idx}`}
                              engine={engineConfig.engine}
                              tradingType={engineConfig.tradingType}
                              groups={selectedGroups}
                              platform={platform}
                              engineData={engineConfig.engineData}
                              mtConfig={config}
                              selectedLogics={selectedLogics}
                            />
                          ))
                        )}
                      </div>
                    )}
                    
                    {viewMode === "general" && (
                      <div className="mt-4">
                        <GeneralCategories 
                          platform={platform} 
                          generalConfig={config?.general || mockGeneralConfig}
                          mtPlatform={mtPlatform}
                          selectedCategory={selectedGeneralCategory}
                        />
                      </div>
                    )}

                    {viewMode === "batch" && (
                      <div className="mt-4">
                        <BatchEditTab platform={platform} />
                      </div>
                    )}
                  </div>
                </ScrollArea>
              </main>
            ) : (
              <EmptyState 
                onLoadSetfile={(loadedConfig) => {
                  setHasStarted(true);
                  if (loadedConfig) {
                    // Set default selections after loading config
                    setSelectedEngines(["Engine A"]);
                    setSelectedGroups(["Group 1"]);
                    setSelectedLogics(["POWER"]);
                    setViewMode("logics");
                  }
                }} 
                onChooseEngine={() => {
                  setHasStarted(true);
                  // Set default selections when starting fresh
                  setSelectedEngines(["Engine A"]);
                  setSelectedGroups(["Group 1"]);
                  setSelectedLogics(["POWER"]);
                  setViewMode("logics");
                }} 
              />
            )}
          </ResizablePanel>

          <ResizableHandle withHandle />

          <ResizablePanel defaultSize={20} minSize={5} maxSize={40}>
            <ChatPanel 
              config={config} 
              onConfigChange={handleSaveConfig}
              onNavigate={handleChatNavigation}
            />
          </ResizablePanel>
        </ResizablePanelGroup>
      </div>

      <FooterRibbon platform={platform} config={config} />
      <VaultSaveModal 
        open={vaultModalOpen} 
        onClose={() => setVaultModalOpen(false)} 
        onSave={handleVaultSave}
      />
      <VaultManager
        open={vaultManagerOpen}
        onClose={() => setVaultManagerOpen(false)}
        onLoadConfig={handleSaveConfig}
      />
      <SettingsDrawer open={settingsOpen} onClose={() => setSettingsOpen(false)} />
    </div>
  );
}
