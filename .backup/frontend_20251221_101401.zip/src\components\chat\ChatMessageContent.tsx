import { ChatMessage, QueryResult, QueryMatch, CommandResult, FieldChange } from "@/lib/chat/types";
import { cn } from "@/lib/utils";
import { 
  ChevronDown, ChevronRight, Copy, Check, ArrowRight, Eye, Pencil, Sparkles, Zap, AlertTriangle,
  Search, Sliders, TrendingUp, ShieldAlert, Terminal, Command
} from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { 
  WelcomeMessage, 
  SemanticPreviewPanel, 
  ResultStatus,
  SectionHeader,
  GradientDivider,
  LabeledDivider,
  OperationCard
} from "./PremiumChatStyles";

interface ChatMessageContentProps {
  message: ChatMessage;
  onSend?: (text: string) => void;
  onNavigate?: (target: { engines?: string[]; groups?: number[]; logics?: string[] }) => void;
  onCompose?: (text: string) => void;
}

export function ChatMessageContent({ message, onSend, onNavigate, onCompose }: ChatMessageContentProps) {
  // Welcome message - use premium component
  if (message.id === "welcome") {
    return <WelcomeMessage />;
  }

  // If it's a query result, render the structured view
  if (message.result?.queryResult) {
    // Note: Auto-navigation is handled by useChatCommands hook when command is executed
    // We don't do it here to avoid side effects in render and double-navigation during history replay
    return <QueryResultsRenderer result={message.result.queryResult} onNavigate={onNavigate} onCompose={onCompose} />;
  }
  // If it's a set/update result, render the changes view
  if (message.result?.changes && message.result.changes.length > 0) {
    return <ChangesRenderer result={message.result} />;
  }

  // Handle semantic preview
  if (message.content.includes("[SEMANTIC PREVIEW]")) {
    return <SemanticPreviewRenderer content={message.content} onSend={onSend} />;
  }

  // Handle plan previews or other structured content if added later
  // For now, check if content looks like a plan (heuristic)
  if (message.content.includes("Transaction Plan")) {
    return <PlanRenderer content={message.content} onSend={onSend} />;
  }

  // Handle legacy snapshot results (fallback)
  if (message.content.includes("Snapshot for")) {
    return <SnapshotRenderer content={message.content} />;
  }  // Handle help message
  if (message.content.includes("Command guide:")) {
    return <HelpRenderer content={message.content} />;
  }

  // Default text renderer with styling based on content
  const styleClass = getPlanStyle(message.content);
  
  return (
    <div className={cn(
      "text-xs leading-relaxed whitespace-pre-wrap break-words overflow-hidden",
      message.role === "user" ? "text-foreground" : "text-foreground",
      styleClass // Apply background/border styles if needed, though parent container handles bubble
    )}>
      {message.content}
    </div>
  );
}

function ChangesRenderer({ result }: { result: CommandResult }) {
  const changes = result.changes || [];
  const count = changes.length;
  const [expanded, setExpanded] = useState(count <= 5);

  const displayedChanges = expanded ? changes : changes.slice(0, 5);

  return (
    <div className="space-y-3 w-full max-w-full overflow-hidden">
      {/* Success Header */}
      <div className="flex items-center gap-3 p-3 rounded-lg bg-gradient-to-r from-emerald-500/15 to-emerald-500/5 border border-emerald-500/20 w-full">
        <div className="p-2 rounded-full bg-emerald-500/20 shrink-0">
          <Check className="w-4 h-4 text-emerald-400" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold text-emerald-400 truncate">Changes Applied</p>
          <p className="text-[10px] text-muted-foreground truncate">{result.message}</p>
        </div>
        <div className="shrink-0 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20">
          <span className="text-xs font-bold text-emerald-400">{count}</span>
          <span className="text-[10px] text-emerald-400/70 ml-1 hidden sm:inline">changes</span>
        </div>
      </div>

      {/* Changes Grid */}
      <div className="grid gap-2">
        {displayedChanges.map((change, i) => (
          <div 
            key={i} 
            className="relative overflow-hidden p-3 rounded-lg bg-gradient-to-br from-card to-card/60 border border-border/40 hover:border-border/60 transition-all group"
          >
            {/* Subtle glow */}
            <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            
            <div className="relative flex items-center gap-3">
              {/* Location Badge */}
              <div className="flex flex-col items-center gap-1 min-w-[50px] shrink-0">
                <span className="text-xs font-bold text-foreground">G{change.group}</span>
                <div className="flex gap-1">
                  <span className="px-1.5 py-0.5 text-[8px] rounded bg-blue-500/10 text-blue-400 font-medium uppercase truncate max-w-[60px]">
                    {change.engine}
                  </span>
                </div>
              </div>
              
              {/* Divider */}
              <div className="w-px h-8 bg-gradient-to-b from-transparent via-border to-transparent shrink-0" />
              
              {/* Field & Value */}
              <div className="flex-1 min-w-0">
                <p className="text-[10px] text-muted-foreground truncate">{change.logic}</p>
                <p className="text-xs font-medium text-foreground truncate">{change.field}</p>
              </div>
              
              {/* Value Change */}
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-background/50 border border-border/30 shrink-0">
                <span className="text-xs text-muted-foreground line-through opacity-60 font-mono hidden sm:inline">{change.oldValue}</span>
                <ArrowRight className="w-3 h-3 text-primary hidden sm:block" />
                <span className="text-xs text-primary font-bold font-mono">{change.newValue}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Expand/Collapse */}
      {count > 5 && (
        <button 
          onClick={() => setExpanded(!expanded)}
          className="w-full py-2 text-[10px] text-muted-foreground hover:text-foreground text-center rounded-lg bg-muted/20 hover:bg-muted/40 border border-border/30 transition-all flex items-center justify-center gap-2"
        >
          {expanded ? (
            <>Show less<ChevronDown className="w-3 h-3" /></>
          ) : (
            <>Show {count - 5} more changes<ChevronRight className="w-3 h-3" /></>
          )}
        </button>
      )}
    </div>
  );
}

// Helper for styling text-based messages
function getPlanStyle(content: string): string {
  if (content.includes("CRITICAL RISK") || content.includes("🔴")) return "text-red-500 font-medium";
  if (content.includes("HIGH RISK") || content.includes("🟠")) return "text-orange-500 font-medium";
  if (content.includes("MEDIUM RISK") || content.includes("🟡")) return "text-yellow-500 font-medium";
  if (content.includes("LOW RISK") || content.includes("🟢")) return "text-green-500 font-medium";
  return "";
}

function PlanRenderer({ content, onSend }: { content: string, onSend?: (text: string) => void }) {
  const lines = content.split('\n').map(l => l.trim()).filter(l => l);
  const isPending = content.includes("Type 'apply' to confirm") || content.includes("apply / cancel");
  
  // Extract risk level
  const riskLevel = content.includes("CRITICAL RISK") ? "critical" 
    : content.includes("HIGH RISK") ? "high"
    : content.includes("MEDIUM RISK") ? "medium"
    : "low";
  
  const riskColors = {
    critical: { bg: "from-red-500/20 to-red-500/5", border: "border-red-500/30", text: "text-red-400" },
    high: { bg: "from-orange-500/20 to-orange-500/5", border: "border-orange-500/30", text: "text-orange-400" },
    medium: { bg: "from-amber-500/20 to-amber-500/5", border: "border-amber-500/30", text: "text-amber-400" },
    low: { bg: "from-emerald-500/20 to-emerald-500/5", border: "border-emerald-500/30", text: "text-emerald-400" },
  };
  
  const colors = riskColors[riskLevel];

  // Extract description (lines that are not headers and not bullets)
  // Skip the first line (Title)
  const descriptionLines = lines.slice(1).filter(l => 
    !l.startsWith("•") && 
    !l.startsWith("⚠️") && 
    !l.startsWith("💡") && 
    !l.startsWith("📋") &&
    !l.includes("Type 'apply'")
  );

  const bulletLines = lines.filter(l => l.startsWith("•"));

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className={cn(
        "p-3 rounded-lg border bg-gradient-to-r",
        colors.bg, colors.border
      )}>
        <div className="flex items-center gap-2 mb-2">
          <AlertTriangle className={cn("w-4 h-4", colors.text)} />
          <span className={cn("text-sm font-semibold", colors.text)}>Transaction Plan</span>
          <span className={cn(
            "ml-auto px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider",
            riskLevel === "critical" ? "bg-red-500/20 text-red-400" :
            riskLevel === "high" ? "bg-orange-500/20 text-orange-400" :
            riskLevel === "medium" ? "bg-amber-500/20 text-amber-400" :
            "bg-emerald-500/20 text-emerald-400"
          )}>
            {riskLevel} risk
          </span>
        </div>
        <p className="text-[10px] text-muted-foreground">Review changes before applying</p>
      </div>
      
      {/* Description */}
      {descriptionLines.length > 0 && (
        <div className="text-xs text-foreground/90 bg-card/50 p-3 rounded-md border border-border/40">
          {descriptionLines.map((line, i) => (
            <p key={i} className={cn("leading-relaxed", i > 0 && "mt-1.5")}>
              {line}
            </p>
          ))}
        </div>
      )}

      {/* Changes List / Risk Factors */}
      {bulletLines.length > 0 && (
        <div className="space-y-1 pl-3 border-l-2 border-primary/20">
          {bulletLines.map((line, i) => (
            <div key={i} className="text-xs text-muted-foreground flex items-start gap-2">
              <span className="text-primary mt-0.5">•</span>
              <span>{line.substring(1).trim()}</span>
            </div>
          ))}
        </div>
      )}
      
      {/* Action Buttons */}
      {isPending && onSend && (
        <>
          <GradientDivider />
          <div className="flex flex-col sm:flex-row gap-2">
            <button
              onClick={() => onSend("apply")}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-gradient-to-r from-emerald-600 to-emerald-500 text-white text-xs font-medium hover:from-emerald-500 hover:to-emerald-400 transition-all shadow-lg shadow-emerald-500/20"
            >
              <Check className="w-4 h-4" />
              Apply Changes
            </button>
            <button
              onClick={() => onSend("cancel")}
              className="px-4 py-2.5 rounded-lg border border-border/50 text-muted-foreground text-xs hover:bg-muted/30 hover:text-foreground transition-all"
            >
              Cancel
            </button>
          </div>
        </>
      )}
    </div>
  );
}

function QueryResultsRenderer({ 
  result, 
  onNavigate,
  onCompose
}: { 
  result: QueryResult; 
  onNavigate?: (target: { engines?: string[]; groups?: number[]; logics?: string[] }) => void;
  onCompose?: (text: string) => void;
}) {
  const matches = result.matches;
  const count = matches.length;
  
  // If huge number of matches, group efficiently
  // Group by Group Number -> Engine -> Logic
  const grouped = matches.reduce((acc, match) => {
    const gKey = `Group ${match.group}`;
    if (!acc[gKey]) acc[gKey] = [];
    acc[gKey].push(match);
    return acc;
  }, {} as Record<string, QueryMatch[]>);

  const groupKeys = Object.keys(grouped).sort((a, b) => {
    const numA = parseInt(a.replace(/\D/g, '')) || 0;
    const numB = parseInt(b.replace(/\D/g, '')) || 0;
    return numA - numB;
  });

  // Render Logic
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({});
  const toggleGroup = (key: string) => {
    setExpandedGroups(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const expandAll = () => {
    const all = groupKeys.reduce((acc, key) => ({ ...acc, [key]: true }), {});
    setExpandedGroups(all);
  };

  const collapseAll = () => setExpandedGroups({});

  return (
    <div className="flex flex-col gap-2 mt-1 w-full">
      <div className="flex items-center justify-between text-[10px] text-muted-foreground px-1">
        <span>Found {count} matches</span>
        <div className="flex gap-2">
          <button onClick={expandAll} className="hover:text-foreground transition-colors">Expand All</button>
          <button onClick={collapseAll} className="hover:text-foreground transition-colors">Collapse All</button>
        </div>
      </div>
      <div className="space-y-2">
        {groupKeys.map(groupKey => {
          const groupMatches = grouped[groupKey];
          const groupNum = parseInt(groupKey.replace(/\D/g, ''));
          const isExpanded = expandedGroups[groupKey];
          
          return (
            <div key={groupKey} className="bg-card/50 border border-border/40 rounded-md overflow-hidden transition-all hover:border-border/80">
              <div className="flex items-center w-full bg-muted/20 hover:bg-muted/40 transition-colors">
                <button 
                  onClick={() => toggleGroup(groupKey)}
                  className="flex-1 flex items-center gap-2 p-2 text-left"
                >
                  {isExpanded ? <ChevronDown className="w-3 h-3 text-muted-foreground" /> : <ChevronRight className="w-3 h-3 text-muted-foreground" />}
                  <span className="text-xs font-medium">{groupKey}</span>
                  <span className="text-[10px] text-muted-foreground px-1.5 py-0.5 bg-background rounded-full border border-border/50">
                    {groupMatches.length} items
                  </span>
                </button>
                
                <div className="flex items-center mr-1">
                  {onNavigate && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 hover:bg-background hover:text-primary"
                      title="View in Canvas"
                      onClick={() => onNavigate({ groups: [groupNum] })}
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </Button>
                  )}
                </div>
              </div>
              
              {isExpanded && (
                <div className="p-2 pt-0 grid gap-2">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 mt-2">                    {groupMatches.map((match, i) => (
                      <div 
                        key={i} 
                        className="bg-background/80 p-2 rounded border border-border/50 text-[10px] flex flex-col gap-1 hover:border-primary/30 transition-colors group relative"
                      >
                        <div 
                          className="cursor-pointer"
                          onClick={() => onNavigate && onNavigate({ 
                            groups: [match.group], 
                            engines: [match.engine], 
                            logics: [match.logic] 
                          })}
                          title="Click to view specifically"
                        >
                          <div className="flex justify-between items-center border-b border-border/30 pb-1 mb-1">
                            <span className="font-semibold text-muted-foreground group-hover:text-foreground transition-colors">
                              {match.engine}
                            </span>
                            <span className={cn(
                              "px-1 rounded text-[9px] font-medium",
                              match.logic === "Power" ? "bg-blue-500/10 text-blue-500" :
                              match.logic === "Scalper" ? "bg-amber-500/10 text-amber-500" :
                              "bg-red-500/10 text-red-500"
                            )}>
                              {match.logic}
                            </span>
                          </div>
                          <div className="flex justify-between items-end">
                            <span className="text-muted-foreground">{match.field}</span>
                            <span className="font-mono font-medium text-foreground">{match.value}</span>
                          </div>
                        </div>

                        {onCompose && (
                          <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-5 w-5 bg-background shadow-sm border border-border/50 hover:bg-primary hover:text-primary-foreground"
                              title="Edit value"
                              onClick={(e) => {
                                e.stopPropagation();
                                onCompose(`set ${match.field} to ${match.value} for group ${match.group} engine ${match.engine} logic ${match.logic}`);
                              }}
                            >
                              <Pencil className="w-3 h-3" />
                            </Button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ============================================================================
// SEMANTIC PREVIEW RENDERER - Premium Styled
// ============================================================================

function SemanticPreviewRenderer({ content, onSend }: { content: string; onSend?: (text: string) => void }) {
  // Parse the semantic preview message
  const descMatch = content.match(/\[SEMANTIC PREVIEW\]\s*(.+)/);
  const description = descMatch ? descMatch[1] : "Semantic Operation";
  
  return (
    <div className="space-y-3">
      <SectionHeader 
        icon={Sparkles} 
        title="Semantic Command Preview"
        subtitle={description}
        variant="info"
      />
      
      <div className="p-3 rounded-lg bg-gradient-to-br from-blue-500/10 to-purple-500/5 border border-blue-500/20">
        <p className="text-xs text-muted-foreground mb-2">
          This command uses AI-powered semantic understanding to interpret your intent.
        </p>
        <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
          <Zap className="w-3.5 h-3.5 text-amber-400" />
          <span>Operations will be applied based on natural language interpretation</span>
        </div>
      </div>
      
      <GradientDivider />
      
      {onSend && (
        <div className="flex flex-col sm:flex-row gap-2">
          <button
            onClick={() => onSend("apply")}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-gradient-to-r from-emerald-600 to-emerald-500 text-white text-xs font-medium hover:from-emerald-500 hover:to-emerald-400 transition-all shadow-lg shadow-emerald-500/20"
          >
            <Check className="w-4 h-4" />
            Apply Changes
          </button>
          <button
            onClick={() => onSend("cancel")}
            className="px-4 py-2.5 rounded-lg border border-border/50 text-muted-foreground text-xs hover:bg-muted/30 hover:text-foreground transition-all"
          >
            Cancel
          </button>
        </div>
      )}
    </div>
  );
}

// ============================================================================
// SNAPSHOT RENDERER - Premium Styled
// ============================================================================

function SnapshotRenderer({ content }: { content: string }) {
  // Parse snapshot content into structured data
  const lines = content.split('\n').filter(l => l.trim());
  const titleLine = lines.find(l => l.includes('Snapshot for'));
  const dataLines = lines.filter(l => !l.includes('Snapshot for') && l.includes(':'));
  
  return (
    <div className="space-y-3">
      <SectionHeader 
        icon={AlertTriangle} 
        title={titleLine || "Configuration Snapshot"}
        variant="default"
      />
      
      <div className="space-y-2">
        {dataLines.map((line, i) => {
          const parts = line.split(':');
          const label = parts[0]?.trim();
          const values = parts.slice(1).join(':').trim();
          
          return (
            <div 
              key={i}
              className="p-3 rounded-lg border border-border/40 bg-gradient-to-br from-card/80 to-card/40 hover:border-border/60 transition-all"
            >
              <div className="text-xs font-medium text-foreground mb-1">{label}</div>
              <div className="flex flex-wrap gap-1.5">
                {values.split(',').map((val, j) => {
                  const [key, v] = val.trim().split('=');
                  return (
                    <span 
                      key={j}
                      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-muted/30 border border-border/30 text-[10px]"
                    >
                      <span className="text-muted-foreground">{key?.trim()}</span>
                      {v && <span className="text-foreground font-mono">{v.trim()}</span>}
                    </span>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ============================================================================
// HELP RENDERER - Premium Styled
// ============================================================================

function HelpRenderer({ content }: { content: string }) {
  const sections = content.split('\n\n').filter(s => s.trim());
  
  const getIconForSection = (title: string) => {
    const t = title.toLowerCase();
    if (t.includes('query') || t.includes('analysis')) return Search;
    if (t.includes('set') || t.includes('configuration')) return Sliders;
    if (t.includes('progression')) return TrendingUp;
    if (t.includes('risk') || t.includes('safety')) return ShieldAlert;
    if (t.includes('copy') || t.includes('replication') || t.includes('compare')) return Copy;
    if (t.includes('meta') || t.includes('controls')) return Terminal;
    return Command;
  };

  const getColorForSection = (title: string) => {
    const t = title.toLowerCase();
    if (t.includes('query') || t.includes('analysis')) return "text-blue-400";
    if (t.includes('set') || t.includes('configuration')) return "text-emerald-400";
    if (t.includes('progression')) return "text-purple-400";
    if (t.includes('risk') || t.includes('safety')) return "text-red-400";
    if (t.includes('copy') || t.includes('replication') || t.includes('compare')) return "text-amber-400";
    return "text-muted-foreground";
  };
  
  return (
    <div className="space-y-4">
      <SectionHeader 
        icon={Command} 
        title="Ryiuk Command Center"
        subtitle="Complete reference guide"
        variant="info"
      />
      
      <div className="grid gap-3">
        {sections.slice(1).map((section, i) => {
          const lines = section.split('\n');
          const titleRaw = lines[0]?.replace(/[#*]/g, '').trim();
          const commands = lines.slice(1);
          
          if (!titleRaw) return null;
          
          const Icon = getIconForSection(titleRaw);
          const colorClass = getColorForSection(titleRaw);

          return (
            <div key={i} className="p-3 rounded-lg border border-border/40 bg-card/50 hover:bg-card/80 transition-colors group">
              <div className="flex items-center gap-2 mb-2">
                <div className={cn("p-1.5 rounded-md bg-muted/30 group-hover:bg-muted/50 transition-colors", colorClass)}>
                  <Icon className="w-3.5 h-3.5" />
                </div>
                <h4 className="text-xs font-semibold text-foreground">{titleRaw}</h4>
              </div>
              
              <div className="space-y-1.5 pl-1">
                {commands.map((cmd, j) => {
                  const [commandPart, descPart] = cmd.replace(/^[•-]\s*/, '').split('—');
                  return (
                    <div key={j} className="text-[10px] flex flex-col sm:flex-row sm:items-baseline gap-1 sm:gap-2">
                      <span className="font-mono text-primary/90 font-medium bg-primary/5 px-1 rounded border border-primary/10">
                        {commandPart.trim()}
                      </span>
                      {descPart && (
                        <span className="text-muted-foreground italic">
                           — {descPart.trim()}
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
