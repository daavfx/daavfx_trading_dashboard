// Command Executor - Execute parsed commands against config state
// Now with Transaction Plan support for preview before apply

import type { 
  ParsedCommand, 
  CommandResult, 
  FieldChange, 
  QueryMatch,
  ProgressionType 
} from "./types";
import type { MTConfig, EngineConfig, GroupConfig, LogicConfig, TrailMethod, TrailStepMethod, TrailStepMode, TPSLMode, PartialMode, PartialBalance, LogicReference } from "@/types/mt-config";
import { 
  createProgressionPlan, 
  createSetPlan, 
  applyTransactionPlan, 
  formatPlanForChat,
  type TransactionPlan 
} from "./planner";
import { calculateProgression, validateForMT4 } from "./math";
import { applyOperation, clampToBounds, type SemanticCommand } from "./semanticEngine";

export class CommandExecutor {
  private config: MTConfig | null = null;
  private onConfigChange: ((config: MTConfig) => void) | null = null;
  private pendingPlan: TransactionPlan | null = null;
  private planHistory: TransactionPlan[] = [];
  private autoApproveTransactions: boolean = false;

  setAutoApprove(enabled: boolean) {
    this.autoApproveTransactions = enabled;
  }

  private getHelpMessage(): string {
    return [
      "Command guide:",
      "",
      "# Query & Analysis",
      "• show ... — View settings: \"show grid for all groups\" or \"show engine A\"",
      "• find ... — Search values: \"find high grid\" (shows groups with grid > 500)",
      "• analyze ... — Deep dive: \"analyze power\" (detailed engine diagnostics)",
      "",
      "# Configuration Sets",
      "• set ... — Direct update: \"set grid to 600 for groups 1-8\"",
      "• bulk set ... — Conditional: \"set multiplier to 1.5 where grid > 500\"",
      "• enable/disable — Toggle: \"enable reverse for power groups 1-5\"",
      "",
      "# Progression Logic",
      "• fibonacci — Math sequence: \"create progression for grid from 600 to 3000 fibonacci groups 1-8\"",
      "• linear — Even steps: \"create linear progression for lot from 0.01 to 0.08 groups 1-8\"",
      "• exponential — Multiplier: \"create exponential progression for lot from 0.01 factor 1.5 groups 1-8\"",
      "",
      "# Risk & Safety Protocols",
      "• equity stop — Hard limit: \"set equity_stop_value to 35%\"",
      "• drawdown — Soft limit: \"set max_drawdown_percent to 25%\"",
      "• news filter — Event safety: \"enable news_filter for all\"",
      "",
      "# Replication & Compare",
      "• copy ... — Clone settings: \"copy power settings from group 1 to groups 2-8\"",
      "• compare ... — Diff tool: \"compare grid between group 1 and group 5\"",
      "",
      "# Meta Controls",
      "• apply / cancel — Transaction Plan approval workflow",
      "• /help — Show this comprehensive command reference",
    ].join("\n");
  }

  private createDefaultConfig(): MTConfig {
    const now = new Date();

    const general: MTConfig["general"] = {
      license_key: "",
      license_server_url: "https://license.daavfx.com",
      require_license: false,
      license_check_interval: 3600,
      config_file_name: "DAAVFX_Config.json",
      config_file_is_common: false,
      allow_buy: true,
      allow_sell: true,
      enable_logs: true,
      compounding_enabled: false,
      compounding_type: "Compound_Balance",
      compounding_target: 40,
      compounding_increase: 2,
      restart_policy_power: "Restart_Default",
      restart_policy_non_power: "Restart_Default",
      close_non_power_on_power_close: false,
      hold_timeout_bars: 10,
      magic_number: 777,
      max_slippage_points: 30,
      risk_management: {
        spread_filter_enabled: false,
        max_spread_points: 25,
        equity_stop_enabled: false,
        equity_stop_value: 35,
        drawdown_stop_enabled: false,
        max_drawdown_percent: 35,
      },
      time_filters: {
        priority_settings: {
          news_filter_overrides_session: false,
          session_filter_overrides_news: true,
        },
        sessions: Array.from({ length: 7 }, (_, i) => ({
          session_number: i + 1,
          enabled: false,
          day: i % 7,
          start_hour: 9,
          start_minute: 30,
          end_hour: 17,
          end_minute: 0,
          action: "TriggerAction_StopEA_KeepTrades",
          auto_restart: true,
          restart_mode: "Restart_Immediate",
          restart_bars: 0,
          restart_minutes: 0,
          restart_pips: 0,
        })),
      },
      news_filter: {
        enabled: false,
        api_key: "",
        api_url: "https://www.jblanked.com/news/api/calendar/",
        countries: "US,GB,EU",
        impact_level: 3,
        minutes_before: 30,
        minutes_after: 30,
        action: "TriggerAction_StopEA_KeepTrades",
      },
    };

    const logicNames = ["Power", "Repower", "Scalper", "Stopper", "STO", "SCA", "RPO"] as const;

    const engines: EngineConfig[] = (["A", "B", "C"] as const).map((engineId) => {
      const groups: GroupConfig[] = [];

      for (let g = 1; g <= 20; g++) {
        const logics: LogicConfig[] = logicNames.map((name) => {
          const isPower = name.toLowerCase() === "power";
          const logic_id = `${engineId}_${name}_G${g}`;
          const trail_method: TrailMethod = "Points";
          const trail_step_method: TrailStepMethod = "Step_Points";
          const trail_step_mode: TrailStepMode = "TrailStepMode_Auto";
          const tp_mode: TPSLMode = "TPSL_Points";
          const sl_mode: TPSLMode = "TPSL_Points";
          const order_count_reference: LogicReference = "Logic_Self";

          const base: LogicConfig = {
            logic_name: name,
            logic_id,
            enabled: true,
            initial_lot: 0.02,
            multiplier: 1.2,
            grid: 300,
            trail_method,
            trail_value: 3000,
            trail_start: 1,
            trail_step: 1500,
            trail_step_method,
            close_targets: "Logic_A_Power,Logic_A_Repower,Logic_A_Scalp,Logic_A_Stopper",
            order_count_reference,
            reset_lot_on_restart: false,
            use_tp: false,
            tp_mode,
            tp_value: 0,
            use_sl: false,
            sl_mode,
            sl_value: 0,
            // Reverse/Hedge (V17.04+)
            reverse_enabled: false,
            hedge_enabled: false,
            reverse_scale: 100.0,
            hedge_scale: 50.0,
            reverse_reference: "Logic_None" as LogicReference,
            hedge_reference: "Logic_None" as LogicReference,
            // Trail Step Advanced (V17.04+)
            trail_step_mode,
            trail_step_cycle: 1,
            trail_step_balance: 0,
            // Close Partial
            close_partial: false,
            close_partial_cycle: 3,
            close_partial_mode: "PartialMode_Low",
            close_partial_balance: "PartialBalance_Balanced",
            close_partial_trail_step_mode: trail_step_mode,
          };

          const withLogicSpecific: LogicConfig = {
            ...base,
            ...(isPower
              ? {}
              : {
                  start_level: 4,
                  last_lot: 0.12,
                }),
            ...(g === 1
              ? {
                  trigger_type: "Default",
                  trigger_bars: 3,
                  trigger_minutes: 15,
                }
              : {}),
          };

          return withLogicSpecific;
        });

        groups.push({
          group_number: g,
          enabled: true,
          // Group-level Reverse/Hedge controls (V17.04+)
          reverse_mode: false,
          hedge_mode: false,
          hedge_reference: "Logic_None" as LogicReference,
          entry_delay_bars: 0,
          logics,
        });
      }

      return {
        engine_id: engineId,
        engine_name: `Engine ${engineId}`,
        max_power_orders: 10,
        groups,
      };
    });

    const config: MTConfig = {
      version: "17.04",
      platform: "MT4",
      timestamp: now.toISOString(),
      total_inputs: 11081,
      general,
      engines,
    };

    return config;
  }

  setConfig(config: MTConfig | null) {
    this.config = config;
  }

  setOnConfigChange(callback: (config: MTConfig) => void) {
    this.onConfigChange = callback;
  }

  // Plan management methods
  getPendingPlan(): TransactionPlan | null {
    return this.pendingPlan;
  }

  approvePendingPlan(): CommandResult {
    if (!this.pendingPlan || !this.config) {
      return { success: false, message: "No pending plan to approve" };
    }

    const newConfig = applyTransactionPlan(this.config, this.pendingPlan);
    this.pendingPlan.status = "applied";
    this.pendingPlan.appliedAt = Date.now();
    this.planHistory.push(this.pendingPlan);
    
    const changes = this.pendingPlan.preview.map(p => ({
      engine: p.engine,
      group: p.group,
      logic: p.logic,
      field: p.field,
      oldValue: p.currentValue,
      newValue: p.newValue
    }));

    this.pendingPlan = null;
    this.applyConfig(newConfig);

    return {
      success: true,
      message: `Applied ${changes.length} changes successfully`,
      changes
    };
  }

  rejectPendingPlan(): CommandResult {
    if (!this.pendingPlan) {
      return { success: false, message: "No pending plan to reject" };
    }
    this.pendingPlan.status = "rejected";
    this.pendingPlan = null;
    return { success: true, message: "Plan rejected. No changes made." };
  }

  getHistory(): TransactionPlan[] {
    return this.planHistory;
  }

  execute(command: ParsedCommand): CommandResult {
    if (!this.config) {
      this.config = this.createDefaultConfig();
      if (this.onConfigChange) {
        this.onConfigChange(this.config);
      }
    }

    const rawLower = command.raw.toLowerCase().trim();

    if (
      rawLower === "help" ||
      rawLower === "/help" ||
      rawLower === "#help" ||
      rawLower === "/commands" ||
      rawLower === "#commands"
    ) {
      return {
        success: true,
        message: this.getHelpMessage(),
      };
    }

    if (["hi", "hello", "hey", "yo"].includes(rawLower)) {
      return {
        success: true,
        message: this.getHelpMessage(),
      };
    }

    // Handle approval/rejection commands for pending plans
    if (rawLower === "apply" || rawLower === "yes" || rawLower === "confirm") {
      return this.approvePendingPlan();
    }
    if (rawLower === "cancel" || rawLower === "no" || rawLower === "reject") {
      return this.rejectPendingPlan();
    }

    // If there's a pending plan and user sends new command, reject old plan
    if (this.pendingPlan) {
      this.pendingPlan = null;
    }

    switch (command.type) {
      case "query":
        return this.executeQuery(command);
      case "set":
        return this.executeSet(command);
      case "semantic":
        return this.executeSemantic(command);
      case "progression":
        return this.executeProgression(command);
      case "copy":
        return this.executeCopy(command);
      case "compare":
        return this.executeCompare(command);
      case "reset":
        return this.executeReset(command);
      case "formula":
        return this.executeFormula(command);
      case "unknown":
        return {
          success: false,
          message: `I didn't understand: "${command.raw}".\n\n${this.getHelpMessage()}`,
        };
      default:
        return { success: false, message: `Unknown command: ${command.raw}` };
    }
  }

  private executeQuery(command: ParsedCommand): CommandResult {
    const matches: QueryMatch[] = [];
    const { engines, groups, logics, field } = command.target;
    const { operator, compareValue } = command.params;

    // SNAPSHOT MODE: When no specific field is requested, show key config values
    // Handles: "show me power a group 1 values", "show engine A settings"
    // HYBRID MODE: Auto-navigate to show inputs in canvas for targeted queries
    if (!field) {
      const snapshotFields = [
        "initial_lot",
        "multiplier",
        "grid",
        "trail_value",
        "trail_start",
        "trail_step",
        "tp_value",
        "sl_value",
        "reverse_enabled",
        "hedge_enabled",
        "close_partial",
      ];
    
      const lines: string[] = [];
      const snapshotMatches: QueryMatch[] = [];
    
      this.iterateConfig(engines, groups, logics, (engine, group, logic) => {
        const parts: string[] = [];
        for (const f of snapshotFields) {
          const v = (logic as any)[f];
          if (v !== undefined) {
            // Format booleans nicely
            const display = typeof v === "boolean" ? (v ? "ON" : "OFF") : v;
            parts.push(`${f}=${display}`);
                
            // Add to structured matches for potential navigation
            snapshotMatches.push({
              engine: engine.engine_id,
              group: group.group_number,
              logic: logic.logic_name,
              field: f,
              value: display
            });
          }
        }
        if (parts.length > 0) {
          lines.push(
            `${engine.engine_id} ${logic.logic_name} G${group.group_number}: ${parts.join(", ")}`
          );
        }
      });
    
      // Build target label for message
      const targetParts: string[] = [];
      if (groups && groups.length > 0) {
        targetParts.push(`groups ${groups.join(",")}`);
      }
      if (logics && logics.length > 0) {
        targetParts.push(`logics ${logics.join(",")}`);
      }
      if (engines && engines.length > 0) {
        targetParts.push(`engines ${engines.join(",")}`);
      }
      const targetLabel = targetParts.length > 0 ? targetParts.join(" / ") : "all targets";
    
      const summary = lines.length > 0 ? lines.join("\n") : "No matches found";
    
      // Prepare navigation targets for hybrid mode
      const navigationTargets = {
        engines: engines && engines.length > 0 ? engines : undefined,
        groups: groups && groups.length > 0 ? groups : undefined,
        logics: logics && logics.length > 0 ? logics : undefined,
        fields: undefined
      };
    
      return {
        success: true,
        message: (engines || groups || logics) ? `Opened ${targetLabel} in canvas` : `Snapshot for ${targetLabel}`,
        queryResult: {
          matches: snapshotMatches,
          summary,
          navigationTargets: (engines || groups || logics) ? navigationTargets : undefined,
          isSnapshot: true
        },
      };
    }
    // STANDARD FIELD QUERY: When a specific field is requested
    this.iterateConfig(engines, groups, logics, (engine, group, logic) => {
      const value = (logic as any)[field];
      if (value === undefined) return;

      // Apply comparison if specified
      if (operator && compareValue !== undefined) {
        const numValue = typeof value === "number" ? value : parseFloat(value);
        let matches_condition = false;
        switch (operator) {
          case ">": matches_condition = numValue > compareValue; break;
          case "<": matches_condition = numValue < compareValue; break;
          case ">=": matches_condition = numValue >= compareValue; break;
          case "<=": matches_condition = numValue <= compareValue; break;
          case "=":
          case "==": matches_condition = numValue === compareValue; break;
        }
        if (!matches_condition) return;
      }

      matches.push({
        engine: engine.engine_id,
        group: group.group_number,
        logic: logic.logic_name,
        field,
        value
      });
    });

    // Prepare navigation targets for hybrid mode
    const navigationTargets = {
      engines: engines && engines.length > 0 ? engines : undefined,
      groups: groups && groups.length > 0 ? groups : undefined,
      logics: logics && logics.length > 0 ? logics : undefined,
      fields: field ? [field] : undefined
    };

    return {
      success: true,
      message: `Found ${matches.length} matches`,
      queryResult: {
        matches,
        summary: this.formatQuerySummary(matches, field),
        navigationTargets: (engines || groups || logics) ? navigationTargets : undefined
      }
    };
  }

  private executeSet(command: ParsedCommand): CommandResult {
    const changes: FieldChange[] = [];
    const { engines, groups, logics, field } = command.target;
    const { value } = command.params;

    // DEBUG: Log parsed target (FIX VERIFICATION - Dec 20 2024 11:55 AM)
    console.log('[ExecuteSet v2] Target extracted:', JSON.stringify({
      engines,
      groups,
      logics,
      field,
      value,
      raw: command.raw
    }, null, 2));

    if (!field || value === undefined) {
      return { success: false, message: "Missing field or value" };
    }

    // VALIDATION: Ensure target is not completely empty
    // If all filters are undefined/empty, user likely made a vague command
    if ((!engines || engines.length === 0) && 
        (!groups || groups.length === 0) && 
        (!logics || logics.length === 0)) {
      return { 
        success: false, 
        message: "Target too vague. Please specify at least one of: engine, group, or logic.\n\nExamples:\n• 'set grid to 600 for group 1'\n• 'set grid to 600 for groups 1-8'\n• 'set lot to 0.02 for power'\n• 'set multiplier to 1.5 for engine A'"
      };
    }

    const newConfig = structuredClone(this.config!);
    
    this.iterateConfigMutable(newConfig, engines, groups, logics, (engine, group, logic) => {
      const oldValue = (logic as any)[field];
      (logic as any)[field] = value;
      
      changes.push({
        engine: engine.engine_id,
        group: group.group_number,
        logic: logic.logic_name,
        field,
        oldValue,
        newValue: value
      });
    });

    this.applyConfig(newConfig);

    // Prepare navigation targets for hybrid mode
    const navigationTargets = {
      engines: engines && engines.length > 0 ? engines : undefined,
      groups: groups && groups.length > 0 ? groups : undefined,
      logics: logics && logics.length > 0 ? logics : undefined,
      fields: field ? [field] : undefined
    };

    return {
      success: true,
      message: `Updated ${changes.length} values`,
      changes,
      queryResult: {
        matches: [], 
        summary: "",
        navigationTargets: (engines || groups || logics) ? navigationTargets : undefined
      }
    };
  }

  // SEMANTIC COMMAND EXECUTION
  // Handles natural language like "30% more aggressive", "make it safer"
  private executeSemantic(command: ParsedCommand): CommandResult {
    const { engines, groups, logics } = command.target;
    const semantic = command.semantic;

    if (!semantic || !semantic.operations || semantic.operations.length === 0) {
      return { success: false, message: "No semantic operations found" };
    }

    // VALIDATION: Ensure target is not completely empty
    // If all filters are undefined/empty, apply to all (dangerous - require confirmation)
    const applyToAll = (!engines || engines.length === 0) && 
                       (!groups || groups.length === 0) && 
                       (!logics || logics.length === 0);

    // Build preview of changes
    const previewLines: string[] = [];
    const plannedChanges: Array<{
      engine: string;
      group: number;
      logic: string;
      field: string;
      oldValue: number;
      newValue: number;
    }> = [];

    this.iterateConfig(engines, groups, logics, (engine, group, logic) => {
      for (const op of semantic.operations) {
        const currentValue = (logic as any)[op.field];
        if (currentValue !== undefined && typeof currentValue === "number") {
          const newValue = clampToBounds(op.field, applyOperation(currentValue, op));
          
          // Round for display
          const displayOld = Number(currentValue.toFixed(4));
          const displayNew = Number(newValue.toFixed(4));
          const percentChange = ((newValue - currentValue) / currentValue * 100).toFixed(1);
          
          plannedChanges.push({
            engine: engine.engine_id,
            group: group.group_number,
            logic: logic.logic_name,
            field: op.field,
            oldValue: currentValue,
            newValue,
          });

          previewLines.push(
            `${engine.engine_id} ${logic.logic_name} G${group.group_number}: ${op.field} ${displayOld} → ${displayNew} (${Number(percentChange) >= 0 ? "+" : ""}${percentChange}%)`
          );
        }
      }
    });

    if (plannedChanges.length === 0) {
      return { success: false, message: "No matching config entries to modify" };
    }

    // Build confirmation message
    const targetDesc = applyToAll 
      ? "ALL engines/groups/logics" 
      : [
          engines?.length ? `engines ${engines.join(",")}` : null,
          groups?.length ? `groups ${groups.join(",")}` : null,
          logics?.length ? `logics ${logics.join(",")}` : null,
        ].filter(Boolean).join(" / ");

    // Limit preview lines for readability
    const maxPreview = 15;
    const previewDisplay = previewLines.length > maxPreview
      ? previewLines.slice(0, maxPreview).join("\n") + `\n... and ${previewLines.length - maxPreview} more changes`
      : previewLines.join("\n");

    // Create transaction plan for preview/approval
    const plan: TransactionPlan = {
      description: semantic.description,
      changes: plannedChanges.map(c => ({
        engine: c.engine,
        group: c.group,
        logic: c.logic,
        field: c.field,
        oldValue: c.oldValue,
        newValue: c.newValue,
      })),
    };

    // Store as pending for approval
    this.pendingPlan = plan;

    // AUTO-APPROVE: If enabled, skip confirmation
    if (this.autoApproveTransactions) {
      const approvalResult = this.approvePendingPlan();
      // Enhance message to indicate auto-approval
      approvalResult.message = `✅ [Auto-Approved] ${semantic.description}\n\n${approvalResult.message}`;
      return approvalResult;
    }

    const warningPrefix = applyToAll ? "⚠️ WARNING: Applying to ALL targets!\n\n" : "";

    // Prepare navigation targets for hybrid mode
    const navigationTargets = {
      engines: engines && engines.length > 0 ? engines : undefined,
      groups: groups && groups.length > 0 ? groups : undefined,
      logics: logics && logics.length > 0 ? logics : undefined,
      fields: undefined
    };

    return {
      success: true,
      message: [
        `${warningPrefix}**[SEMANTIC PREVIEW]** ${semantic.description}`,
        `Target: ${targetDesc}`,
        "",
        "Changes:",
        previewDisplay,
        "",
        "**Reply 'apply' to confirm or 'cancel' to discard.**",
      ].join("\n"),
      queryResult: {
        matches: [], 
        summary: "",
        navigationTargets: (engines || groups || logics) ? navigationTargets : undefined
      }
    };
  }

  private executeProgression(command: ParsedCommand): CommandResult {
    const { engines, groups, logics, field } = command.target;
    const { startValue, endValue, progressionType, factor } = command.params;

    if (!field || !groups || groups.length < 2) {
      return { success: false, message: "Need field and at least 2 groups for progression" };
    }

    // Create a transaction plan for preview
    const plan = createProgressionPlan(this.config!, {
      field,
      progressionType: progressionType || "fibonacci",
      startValue: startValue || 600,
      endValue,
      factor,
      engines,
      groups,
      logics
    });

    // Store as pending for approval
    this.pendingPlan = plan;

    // AUTO-APPROVE: If enabled, skip confirmation
    if (this.autoApproveTransactions) {
      const approvalResult = this.approvePendingPlan();
      // Enhance message to indicate auto-approval
      approvalResult.message = `✅ [Auto-Approved] Generated progression for ${field}\n\n${approvalResult.message}`;
      return approvalResult;
    }

    // Prepare navigation targets for hybrid mode
    const navigationTargets = {
      engines: engines && engines.length > 0 ? engines : undefined,
      groups: groups && groups.length > 0 ? groups : undefined,
      logics: logics && logics.length > 0 ? logics : undefined,
      fields: field ? [field] : undefined
    };

    // Return preview for user approval
    return {
      success: true,
      message: formatPlanForChat(plan) + "\n\n**Reply 'apply' to confirm or 'cancel' to discard.**",
      queryResult: {
        matches: [], 
        summary: "",
        navigationTargets: (engines || groups || logics) ? navigationTargets : undefined
      }
    };
  }

  private executeCopy(command: ParsedCommand): CommandResult {
    const changes: FieldChange[] = [];
    const { engines, groups, logics, field } = command.target;
    const { sourceGroup } = command.params;

    if (!sourceGroup || !groups) {
      return { success: false, message: "Need source group and target groups" };
    }

    const newConfig = structuredClone(this.config!);

    // Get source values
    const sourceValues: Record<string, Record<string, any>> = {};
    this.iterateConfig(engines, [sourceGroup], logics, (engine, group, logic) => {
      const key = `${engine.engine_id}_${logic.logic_name}`;
      sourceValues[key] = { ...logic };
    });

    // Apply to target groups
    const targetGroups = groups.filter(g => g !== sourceGroup);
    this.iterateConfigMutable(newConfig, engines, targetGroups, logics, (engine, group, logic) => {
      const key = `${engine.engine_id}_${logic.logic_name}`;
      const source = sourceValues[key];
      if (!source) return;

      const fieldsToСopy = field ? [field] : Object.keys(source).filter(k => 
        !["logic_id", "logic_name"].includes(k)
      );

      for (const f of fieldsToСopy) {
        const oldValue = (logic as any)[f];
        const newValue = source[f];
        if (oldValue !== newValue) {
          (logic as any)[f] = newValue;
          changes.push({
            engine: engine.engine_id,
            group: group.group_number,
            logic: logic.logic_name,
            field: f,
            oldValue,
            newValue
          });
        }
      }
    });

    this.applyConfig(newConfig);

    // Prepare navigation targets for hybrid mode (show modified groups)
    const navigationTargets = {
      engines: engines && engines.length > 0 ? engines : undefined,
      groups: targetGroups && targetGroups.length > 0 ? targetGroups : undefined,
      logics: logics && logics.length > 0 ? logics : undefined,
      fields: field ? [field] : undefined
    };

    return {
      success: true,
      message: `Copied ${changes.length} values from group ${sourceGroup}`,
      changes,
      queryResult: {
        matches: [], 
        summary: "",
        navigationTargets: (engines || targetGroups || logics) ? navigationTargets : undefined
      }
    };
  }

  private executeCompare(command: ParsedCommand): CommandResult {
    const { engines, groups, logics, field } = command.target;
    
    if (!groups || groups.length < 2) {
      return { success: false, message: "Need at least 2 groups to compare" };
    }

    const matches: QueryMatch[] = [];
    const compareField = field || "grid";

    groups.forEach(groupNum => {
      this.iterateConfig(undefined, [groupNum], logics, (engine, group, logic) => {
        matches.push({
          engine: engine.engine_id,
          group: group.group_number,
          logic: logic.logic_name,
          field: compareField,
          value: (logic as any)[compareField]
        });
      });
    });

    // Prepare navigation targets for hybrid mode (show compared groups)
    const navigationTargets = {
      engines: engines && engines.length > 0 ? engines : undefined,
      groups: groups && groups.length > 0 ? groups : undefined,
      logics: logics && logics.length > 0 ? logics : undefined
    };

    return {
      success: true,
      message: `Comparison of ${compareField} across ${groups.length} groups`,
      queryResult: { 
        matches, 
        summary: this.formatComparisonTable(matches, compareField),
        navigationTargets: (engines || groups || logics) ? navigationTargets : undefined
      }
    };
  }

  private executeReset(command: ParsedCommand): CommandResult {
    // For now, just acknowledge - would need default values
    return { success: false, message: "Reset not yet implemented - need default value store" };
  }

  private executeFormula(command: ParsedCommand): CommandResult {
    const changes: FieldChange[] = [];
    const { engines, groups, logics, field } = command.target;
    const { formula } = command.params;

    if (!field || !formula) {
      return { success: false, message: "Need field and formula" };
    }

    const newConfig = structuredClone(this.config!);

    this.iterateConfigMutable(newConfig, engines, groups, logics, (engine, group, logic) => {
      const oldValue = (logic as any)[field];
      const numValue = typeof oldValue === "number" ? oldValue : parseFloat(oldValue) || 0;
      
      // Simple formula evaluation (field * X, field + X, field - X)
      let newValue = numValue;
      const multMatch = formula.match(/\*\s*([\d.]+)/);
      const addMatch = formula.match(/\+\s*([\d.]+)/);
      const subMatch = formula.match(/-\s*([\d.]+)/);
      
      if (multMatch) newValue = numValue * parseFloat(multMatch[1]);
      else if (addMatch) newValue = numValue + parseFloat(addMatch[1]);
      else if (subMatch) newValue = numValue - parseFloat(subMatch[1]);

      (logic as any)[field] = Math.round(newValue * 100) / 100; // 2 decimal places

      changes.push({
        engine: engine.engine_id,
        group: group.group_number,
        logic: logic.logic_name,
        field,
        oldValue,
        newValue: (logic as any)[field]
      });
    });

    this.applyConfig(newConfig);

    // Prepare navigation targets for hybrid mode
    const navigationTargets = {
      engines: engines && engines.length > 0 ? engines : undefined,
      groups: groups && groups.length > 0 ? groups : undefined,
      logics: logics && logics.length > 0 ? logics : undefined,
      fields: field ? [field] : undefined
    };

    return {
      success: true,
      message: `Updated ${changes.length} values with formula ${formula}`,
      changes,
      queryResult: {
        matches: [], 
        summary: "",
        navigationTargets: (engines || groups || logics) ? navigationTargets : undefined
      }
    };
  }

  // Helper: iterate over config matching filters
  private iterateConfig(
    engines: string[] | undefined,
    groups: number[] | undefined,
    logics: string[] | undefined,
    callback: (engine: EngineConfig, group: GroupConfig, logic: LogicConfig) => void
  ) {
    if (!this.config) return;
    
    for (const engine of this.config.engines) {
      // Skip engine if engines filter specified and this engine not in list
      if (engines && engines.length > 0 && !engines.includes(engine.engine_id)) continue;
      
      for (const group of engine.groups) {
        // Skip group if groups filter specified and this group not in list
        if (groups && groups.length > 0 && !groups.includes(group.group_number)) continue;
        
        for (const logic of group.logics) {
          // Skip logic if logics filter specified and this logic not in list
          if (logics && logics.length > 0 && !logics.includes(logic.logic_name.toUpperCase())) continue;
          callback(engine, group, logic);
        }
      }
    }
  }

  private iterateConfigMutable(
    config: MTConfig,
    engines: string[] | undefined,
    groups: number[] | undefined,
    logics: string[] | undefined,
    callback: (engine: EngineConfig, group: GroupConfig, logic: LogicConfig) => void
  ) {
    for (const engine of config.engines) {
      // Skip engine if engines filter specified and this engine not in list
      if (engines && engines.length > 0 && !engines.includes(engine.engine_id)) continue;
      
      for (const group of engine.groups) {
        // CRITICAL FIX: Skip group if groups filter specified and this group not in list
        // Previously: if (groups && !groups.includes(...)) - this allowed undefined/empty to pass through
        // Now: Explicitly check length > 0 to ensure filter is actually applied
        if (groups && groups.length > 0 && !groups.includes(group.group_number)) continue;
        
        for (const logic of group.logics) {
          // Skip logic if logics filter specified and this logic not in list
          if (logics && logics.length > 0 && !logics.includes(logic.logic_name.toUpperCase())) continue;
          callback(engine, group, logic);
        }
      }
    }
  }

  private applyConfig(newConfig: MTConfig) {
    this.config = newConfig;
    if (this.onConfigChange) {
      this.onConfigChange(newConfig);
    }
  }

  private generateProgression(
    type: ProgressionType,
    start: number,
    end: number | undefined,
    steps: number,
    factor?: number
  ): number[] {
    const values: number[] = [];
    
    switch (type) {
      case "linear": {
        const step = end ? (end - start) / (steps - 1) : 100;
        for (let i = 0; i < steps; i++) {
          values.push(Math.round(start + step * i));
        }
        break;
      }
      
      case "fibonacci": {
        // Fibonacci-like scaling
        const fibFactors = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765];
        const baseStep = end ? (end - start) / fibFactors.slice(0, steps).reduce((a, b) => a + b, 0) : 50;
        let cumulative = 0;
        for (let i = 0; i < steps; i++) {
          cumulative += fibFactors[i] || fibFactors[fibFactors.length - 1];
          values.push(Math.round(start + baseStep * cumulative));
        }
        break;
      }
      
      case "exponential": {
        const mult = factor || 1.5;
        let current = start;
        for (let i = 0; i < steps; i++) {
          values.push(Math.round(current));
          current *= mult;
        }
        break;
      }
      
      default:
        for (let i = 0; i < steps; i++) {
          values.push(start);
        }
    }
    
    return values;
  }

  private formatQuerySummary(matches: QueryMatch[], field: string): string {
    if (matches.length === 0) return "No matches found";
    
    const byGroup: Record<number, any[]> = {};
    for (const m of matches) {
      byGroup[m.group] = byGroup[m.group] || [];
      byGroup[m.group].push(m);
    }
    
    return Object.entries(byGroup)
      .map(([g, items]) => `Group ${g}: ${items.map(i => `${i.logic}=${i.value}`).join(", ")}`)
      .join("\n");
  }

  private formatComparisonTable(matches: QueryMatch[], field: string): string {
    const grouped: Record<string, Record<number, any>> = {};
    
    for (const m of matches) {
      const key = `${m.engine}/${m.logic}`;
      grouped[key] = grouped[key] || {};
      grouped[key][m.group] = m.value;
    }
    
    return Object.entries(grouped)
      .map(([key, groups]) => 
        `${key}: ${Object.entries(groups).map(([g, v]) => `G${g}=${v}`).join(" | ")}`
      )
      .join("\n");
  }
}

// Singleton instance
export const commandExecutor = new CommandExecutor();
