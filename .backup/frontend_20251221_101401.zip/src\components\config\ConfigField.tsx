import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip";
import { Info } from "lucide-react";

interface ConfigFieldProps {
  label: string;
  value: string | number;
  type: "number" | "toggle" | "text" | "select";
  unit?: string;
  description?: string;
  options?: string[];
  onChange?: (value: string | number | boolean) => void;
}

export function ConfigField({ label, value, type, unit, description, options, onChange }: ConfigFieldProps) {
  const [localValue, setLocalValue] = useState(value);

  const handleChange = (newValue: string | number | boolean) => {
    setLocalValue(newValue as string | number);
    onChange?.(newValue);
  };

  return (
    <div className="group flex items-center justify-between py-2.5 px-3 rounded-lg bg-background/40 border border-white/5 shadow-sm hover:shadow-md hover:bg-background/60 hover:border-primary/20 hover:ring-1 hover:ring-primary/5 transition-all duration-300 backdrop-blur-sm">
      <div className="flex items-center gap-2">
        <span className="text-[11px] font-medium text-muted-foreground group-hover:text-foreground/90 transition-colors">
          {label}
        </span>
        {description && (
          <TooltipProvider>
            <Tooltip delayDuration={300}>
              <TooltipTrigger asChild>
                <div className="p-0.5 rounded-full hover:bg-primary/10 transition-colors">
                  <Info className="w-3 h-3 text-muted-foreground/40 cursor-help group-hover:text-primary/60 transition-colors" />
                </div>
              </TooltipTrigger>
              <TooltipContent side="top" className="max-w-xs text-xs bg-popover/95 backdrop-blur-md border-border shadow-lg">
                {description}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}
      </div>
      
      {type === "toggle" ? (
        <div className="flex items-center gap-2">
          <Switch
            checked={localValue === "ON"}
            onCheckedChange={(checked) => handleChange(checked ? "ON" : "OFF")}
            className="h-4 w-8 data-[state=checked]:bg-primary data-[state=checked]:shadow-[0_0_12px_rgba(var(--primary),0.5)]"
          />
          <span className={cn(
            "text-[10px] font-mono w-7 text-right transition-colors",
            localValue === "ON" ? "text-primary font-bold shadow-primary/20" : "text-muted-foreground"
          )}>
            {localValue}
          </span>
        </div>
      ) : type === "select" && options ? (
        <Select value={localValue as string} onValueChange={handleChange}>
          <SelectTrigger className="h-7 w-[130px] text-[10px] font-mono bg-black/5 dark:bg-white/5 border-transparent hover:border-primary/30 focus:ring-1 focus:ring-primary/20 transition-all shadow-inner">
            <SelectValue placeholder={localValue} />
          </SelectTrigger>
          <SelectContent className="bg-popover/95 backdrop-blur-xl border-white/10">
            {options.map((option) => (
              <SelectItem key={option} value={option} className="text-[10px] font-mono focus:bg-primary/10 focus:text-primary">
                {option}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      ) : type === "number" ? (
        <div className="flex items-center gap-1.5">
          <Input
            type="text"
            value={localValue}
            onChange={(e) => handleChange(e.target.value)}
            className="w-20 h-7 text-right font-mono text-[11px] px-2 bg-black/5 dark:bg-white/5 border-transparent hover:border-primary/30 text-foreground focus:border-primary/50 focus:bg-background focus:ring-1 focus:ring-primary/20 transition-all rounded-md shadow-inner placeholder:text-muted-foreground/30"
          />
          {unit && (
            <span className="text-[9px] text-muted-foreground/60 w-6 text-left font-medium">{unit}</span>
          )}
        </div>
      ) : type === "text" ? (
        <Input
          type="text"
          value={localValue}
          onChange={(e) => handleChange(e.target.value)}
          className="w-full max-w-[180px] h-7 text-right font-mono text-[10px] px-2 bg-black/5 dark:bg-white/5 border-transparent hover:border-primary/30 text-foreground focus:border-primary/50 focus:bg-background focus:ring-1 focus:ring-primary/20 transition-all rounded-md shadow-inner placeholder:text-muted-foreground/30"
        />
      ) : (
        <span className={cn(
          "text-[11px] font-mono px-2.5 py-1 rounded-md bg-black/5 dark:bg-white/5 border border-transparent",
          value === "-" ? "text-muted-foreground/40" : "text-foreground font-medium"
        )}>
          {value}
        </span>
      )}
    </div>
  );
}
