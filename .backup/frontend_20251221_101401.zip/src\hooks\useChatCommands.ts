// React Hook for Chat Command System
// HOTFIX: Force rebuild Dec 20 2024 11:57 AM

import { useState, useCallback, useEffect } from "react";
import { parseCommand, getSuggestions, commandExecutor } from "@/lib/chat";
import type { ChatMessage, CommandResult } from "@/lib/chat/types";
import type { MTConfig } from "@/types/mt-config";
import { useSettings } from "@/contexts/SettingsContext";
import { invoke } from "@tauri-apps/api/core";
import { save, open } from "@tauri-apps/plugin-dialog";
import { toast } from "sonner";

interface UseChatCommandsOptions {
  config: MTConfig | null;
  onConfigChange: (config: MTConfig) => void;
  onNavigate?: (target: { engines?: string[]; groups?: number[]; logics?: string[] }) => void;
}

export function useChatCommands({ config, onConfigChange, onNavigate }: UseChatCommandsOptions) {
  const { settings } = useSettings();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      role: "system",
      content: "Welcome to Ryiuk! I can help you modify trading parameters.\n\nTry commands like:\n• \"show grid for all groups\"\n• \"set grid to 600 for groups 1-8\"\n• \"create progression for grid fibonacci groups 1-8\"",
      timestamp: Date.now()
    }
  ]);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [inputValue, setInputValue] = useState("");

  // Sync config to executor
  useEffect(() => {
    commandExecutor.setConfig(config);
    commandExecutor.setOnConfigChange(onConfigChange);
    commandExecutor.setAutoApprove(settings.autoApproveTransactions);
  }, [config, onConfigChange, settings.autoApproveTransactions]);

  // Update suggestions as user types
  useEffect(() => {
    if (inputValue.length > 2) {
      setSuggestions(getSuggestions(inputValue));
    } else {
      setSuggestions([]);
    }
  }, [inputValue]);

  const sendMessage = useCallback(async (text: string) => {
    if (!text.trim()) return;

    const trimmed = text.trim();
    const lower = trimmed.toLowerCase();

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      content: text,
      timestamp: Date.now()
    };

    // Handle quick action results (internal messages)
    if (lower.startsWith("/quick-action-result:")) {
      const msg = trimmed.replace("/quick-action-result:", "").trim();
      const assistantMessage: ChatMessage = {
        id: `assistant-${Date.now()}`,
        role: "assistant",
        content: msg,
        timestamp: Date.now(),
      };
      setMessages(prev => [...prev, assistantMessage]);
      setInputValue("");
      setSuggestions([]);
      return;
    }

    // Handle chat-level meta commands: /export, /load
    if (lower.startsWith("/export") || lower.startsWith("#export")) {
      if (!config) {
        const msg = "No configuration in memory to export";
        const assistantMessage: ChatMessage = {
          id: `assistant-${Date.now()}`,
          role: "assistant",
          content: `❌ ${msg}`,
          timestamp: Date.now(),
        };
        setMessages(prev => [...prev, userMessage, assistantMessage]);
        setInputValue("");
        setSuggestions([]);
        return;
      }

      const isJson = lower.includes("json");
      const formatLabel = isJson ? "JSON" : ".set";

      try {
        const platformName = (config.platform || "MT4").toUpperCase();
        const extension = isJson ? "json" : "set";
        const defaultName = `DAAVFX_${platformName}_Config.${extension}`;

        const filePath = await save({
          defaultPath: defaultName,
          filters: isJson
            ? [{ name: "JSON", extensions: ["json"] }]
            : [{ name: "MT4/MT5 Settings", extensions: ["set"] }],
        });

        if (!filePath) {
          const assistantMessage: ChatMessage = {
            id: `assistant-${Date.now()}`,
            role: "assistant",
            content: "❌ Export cancelled",
            timestamp: Date.now(),
          };
          setMessages(prev => [...prev, userMessage, assistantMessage]);
          setInputValue("");
          setSuggestions([]);
          return;
        }

        if (isJson) {
          await invoke("export_json_file", { config, filePath });
        } else {
          await invoke("export_set_file", {
            config,
            filePath,
            platform: platformName,
            include_optimization_hints: false,
          });
        }

        const assistantMessage: ChatMessage = {
          id: `assistant-${Date.now()}`,
          role: "assistant",
          content: `✅ Exported ${formatLabel} file to ${String(filePath)}`,
          timestamp: Date.now(),
        };
        toast.success(`Exported ${formatLabel} file successfully`);
        setMessages(prev => [...prev, userMessage, assistantMessage]);
      } catch (err) {
        const msg = `Export failed: ${err}`;
        const assistantMessage: ChatMessage = {
          id: `assistant-${Date.now()}`,
          role: "assistant",
          content: `❌ ${msg}`,
          timestamp: Date.now(),
        };
        toast.error(msg);
        setMessages(prev => [...prev, userMessage, assistantMessage]);
      }

      setInputValue("");
      setSuggestions([]);
      return;
    }

    if (lower.startsWith("/load") || lower.startsWith("#load")) {
      const isJson = lower.includes("json");
      const formatLabel = isJson ? "JSON" : ".set";

      try {
        const filePath = await open({
          filters: isJson
            ? [{ name: "JSON", extensions: ["json"] }]
            : [{ name: "MT4/MT5 Settings", extensions: ["set"] }],
          multiple: false,
        });

        if (!filePath) {
          const assistantMessage: ChatMessage = {
            id: `assistant-${Date.now()}`,
            role: "assistant",
            content: "❌ Load cancelled",
            timestamp: Date.now(),
          };
          setMessages(prev => [...prev, userMessage, assistantMessage]);
          setInputValue("");
          setSuggestions([]);
          return;
        }

        let newConfig: MTConfig;
        if (isJson) {
          newConfig = await invoke<MTConfig>("import_json_file", { filePath });
        } else {
          newConfig = await invoke<MTConfig>("import_set_file", { filePath });
        }

        const name = Array.isArray(filePath)
          ? String(filePath[0]).split(/[/\\\\]/).pop() || String(filePath[0])
          : String(filePath).split(/[/\\\\]/).pop() || String(filePath);
        newConfig = {
          ...newConfig,
          current_set_name: name,
        };

        onConfigChange(newConfig);
        const assistantMessage: ChatMessage = {
          id: `assistant-${Date.now()}`,
          role: "assistant",
          content: `✅ Loaded ${formatLabel} file (${newConfig.total_inputs} inputs)`,
          timestamp: Date.now(),
        };
        toast.success(`Loaded ${formatLabel} file successfully`);
        setMessages(prev => [...prev, userMessage, assistantMessage]);
      } catch (err) {
        const msg = `Load failed: ${err}`;
        const assistantMessage: ChatMessage = {
          id: `assistant-${Date.now()}`,
          role: "assistant",
          content: `❌ ${msg}`,
          timestamp: Date.now(),
        };
        toast.error(msg);
        setMessages(prev => [...prev, userMessage, assistantMessage]);
      }

      setInputValue("");
      setSuggestions([]);
      return;
    }

    // Normal command path
    const parsed = parseCommand(text);
    const result = commandExecutor.execute(parsed);

    // AUTO-NAVIGATION logic
    if (result.success && result.queryResult?.navigationTargets && onNavigate) {
      onNavigate(result.queryResult.navigationTargets);
    }

    // Smart formatting: If we auto-navigated for a snapshot, suppress the long text output
    const isSnapshotNavigation = result.success && result.queryResult?.isSnapshot && result.queryResult?.navigationTargets;
    
    let content = formatResult(result);
    
    if (isSnapshotNavigation) {
      // If the executor already provided a navigation message, use it
      if (result.message.startsWith("Opened")) {
        content = `✅ ${result.message}`;
      } else {
        const targetLabel = result.message.replace("Snapshot for ", "");
        content = `✅ I've updated the dashboard to show ${targetLabel}.`;
      }
    }

    const assistantMessage: ChatMessage = {
      id: `assistant-${Date.now()}`,
      role: "assistant",
      content,
      timestamp: Date.now(),
      command: parsed,
      result
    };

    setMessages(prev => [...prev, userMessage, assistantMessage]);
    setInputValue("");
    setSuggestions([]);
  }, [config, onConfigChange]);

  const applySuggestion = useCallback((suggestion: string) => {
    setInputValue(suggestion);
    setSuggestions([]);
  }, []);

  const clearHistory = useCallback(() => {
    setMessages([{
      id: "welcome",
      role: "system",
      content: "Chat cleared. Ready for new commands.",
      timestamp: Date.now()
    }]);
  }, []);

  return {
    messages,
    suggestions,
    inputValue,
    setInputValue,
    sendMessage,
    applySuggestion,
    clearHistory
  };
}

function formatResult(result: CommandResult): string {
  if (!result.success) {
    return `❌ ${result.message}`;
  }

  let output = `✅ ${result.message}`;

  if (result.queryResult) {
    output += `\n\n${result.queryResult.summary}`;
  }

  if (result.changes && result.changes.length > 0) {
    const preview = result.changes.slice(0, 5);
    output += "\n\nChanges:";
    for (const change of preview) {
      output += `\n• ${change.logic} G${change.group}: ${change.field} ${change.oldValue} → ${change.newValue}`;
    }
    if (result.changes.length > 5) {
      output += `\n• ... and ${result.changes.length - 5} more`;
    }
  }

  return output;
}
