import { motion, AnimatePresence } from "framer-motion";
import { ChevronRight, Info, Star, ArrowLeftRight, Shield, Layers, Zap, Settings2, RefreshCw, Box } from "lucide-react";
import { cn } from "@/lib/utils";
import { ConfigField } from "./ConfigField";
import { Platform } from "@/components/layout/TopBar";
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip";
import type { LogicConfig, EngineConfig } from "@/types/mt-config";
import { logicInputs, ENGINE_LOGICS, LOGIC_DISPLAY_NAMES } from "@/data/logic-inputs";

interface LogicModuleProps {
  name: string;
  engine: string;
  expanded: boolean;
  onToggle: () => void;
  platform: Platform;
  logicConfig?: LogicConfig;
  groups?: string[];
  engineData?: EngineConfig | null;
  selectedFields?: string[];
}

const logicMeta: Record<string, { color: string; description: string; cssClass: string }> = {
  // Engine A logics
  POWER: { 
    color: "bg-[hsl(43_80%_50%)]", 
    description: "Main trading logic - core position management and entry signals",
    cssClass: "logic-power"
  },
  REPOWER: { 
    color: "bg-[hsl(210_60%_52%)]", 
    description: "Grid recovery system with dynamic lot sizing",
    cssClass: "logic-repower"
  },
  SCALPER: { 
    color: "bg-[hsl(152_55%_48%)]", 
    description: "Fast scalping entries with tight stops",
    cssClass: "logic-scalper"
  },
  STOPPER: { 
    color: "bg-[hsl(0_55%_52%)]", 
    description: "Risk management and position limiting",
    cssClass: "logic-stopper"
  },
  STO: { 
    color: "bg-[hsl(38_70%_52%)]", 
    description: "Stochastic oscillator signals",
    cssClass: "logic-sto"
  },
  SCA: { 
    color: "bg-[hsl(270_50%_58%)]", 
    description: "Scale-in position management",
    cssClass: "logic-sca"
  },
  RPO: { 
    color: "bg-[hsl(175_55%_48%)]", 
    description: "Recovery position optimization",
    cssClass: "logic-rpo"
  },
  // Engine B logics (same colors, different prefix)
  BPOWER: { color: "bg-[hsl(43_80%_50%)]", description: "Engine B - Main trading logic", cssClass: "logic-power" },
  BREPOWER: { color: "bg-[hsl(210_60%_52%)]", description: "Engine B - Grid recovery", cssClass: "logic-repower" },
  BSCALPER: { color: "bg-[hsl(152_55%_48%)]", description: "Engine B - Fast scalping", cssClass: "logic-scalper" },
  BSTOPPER: { color: "bg-[hsl(0_55%_52%)]", description: "Engine B - Risk management", cssClass: "logic-stopper" },
  BSTO: { color: "bg-[hsl(38_70%_52%)]", description: "Engine B - Stochastic", cssClass: "logic-sto" },
  BSCA: { color: "bg-[hsl(270_50%_58%)]", description: "Engine B - Scale-in", cssClass: "logic-sca" },
  BRPO: { color: "bg-[hsl(175_55%_48%)]", description: "Engine B - Recovery", cssClass: "logic-rpo" },
  // Engine C logics
  CPOWER: { color: "bg-[hsl(43_80%_50%)]", description: "Engine C - Main trading logic", cssClass: "logic-power" },
  CREPOWER: { color: "bg-[hsl(210_60%_52%)]", description: "Engine C - Grid recovery", cssClass: "logic-repower" },
  CSCALPER: { color: "bg-[hsl(152_55%_48%)]", description: "Engine C - Fast scalping", cssClass: "logic-scalper" },
  CSTOPPER: { color: "bg-[hsl(0_55%_52%)]", description: "Engine C - Risk management", cssClass: "logic-stopper" },
  CSTO: { color: "bg-[hsl(38_70%_52%)]", description: "Engine C - Stochastic", cssClass: "logic-sto" },
  CSCA: { color: "bg-[hsl(270_50%_58%)]", description: "Engine C - Scale-in", cssClass: "logic-sca" },
  CRPO: { color: "bg-[hsl(175_55%_48%)]", description: "Engine C - Recovery", cssClass: "logic-rpo" },
};

// Category display order and icons
const CATEGORY_ORDER = [
  "Core", "Lots", "Grid", "Trail", "Trail Advanced", "Logic", 
  "TPSL", "Reverse/Hedge", "Close Partial", "Triggers", "Safety", "Restart"
];

const categoryStyles: Record<string, { color: string; bg: string; border: string; icon: any }> = {
  "Core": { color: "text-blue-500", bg: "bg-blue-500/5", border: "border-blue-500/10", icon: Layers },
  "Lots": { color: "text-blue-400", bg: "bg-blue-400/5", border: "border-blue-400/10", icon: Box },
  "Grid": { color: "text-indigo-500", bg: "bg-indigo-500/5", border: "border-indigo-500/10", icon: ArrowLeftRight },
  "Trail": { color: "text-purple-500", bg: "bg-purple-500/5", border: "border-purple-500/10", icon: ChevronRight },
  "Trail Advanced": { color: "text-fuchsia-500", bg: "bg-fuchsia-500/5", border: "border-fuchsia-500/10", icon: Settings2 },
  "Logic": { color: "text-emerald-500", bg: "bg-emerald-500/5", border: "border-emerald-500/10", icon: Zap },
  "TPSL": { color: "text-amber-500", bg: "bg-amber-500/5", border: "border-amber-500/10", icon: Shield },
  "Reverse/Hedge": { color: "text-orange-500", bg: "bg-orange-500/5", border: "border-orange-500/10", icon: ArrowLeftRight },
  "Close Partial": { color: "text-cyan-500", bg: "bg-cyan-500/5", border: "border-cyan-500/10", icon: RefreshCw },
  "Triggers": { color: "text-rose-500", bg: "bg-rose-500/5", border: "border-rose-500/10", icon: Shield },
  "Safety": { color: "text-red-500", bg: "bg-red-500/5", border: "border-red-500/10", icon: Shield },
  "Restart": { color: "text-slate-500", bg: "bg-slate-500/5", border: "border-slate-500/10", icon: RefreshCw },
};

const getCategoryIcon = (category: string) => {
  if (category === "Reverse/Hedge") return <ArrowLeftRight className="w-3 h-3" />;
  if (category === "Safety") return <Shield className="w-3 h-3" />;
  return null;
};


export function LogicModule({ name, engine, expanded, onToggle, platform, logicConfig, groups, engineData }: LogicModuleProps) {
  // Map real config to fields or use mock data
  const getRealFields = () => {
    // Determine if we should show extra fields based on logic type
    const isPower = name === "POWER";
    // Fix Group 1 detection: Look for "Group 1" explicitly or logic_id containing "_G1"
    const isGroup1 = groups?.some(g => g === "Group 1") || logicConfig?.logic_id?.includes("_G1");

    // Default values if logicConfig is missing (fallback/mock)
    const config = logicConfig || {};

    // Get definition for this specific logic type from logicInputs
    const logicInputConfig = logicInputs[name];
    if (!logicInputConfig) return [];
    
    const templateFields = isGroup1 ? logicInputConfig.group_1 : logicInputConfig.standard;

    // Map definition to actual values from config
    const realFields = templateFields.map(field => {
      const configKey = field.id as keyof LogicConfig;
      let val = config[configKey];
      
      // Handle Toggles (Boolean -> "ON"/"OFF")
      if (field.type === "toggle" && typeof val === "boolean") {
        val = val ? "ON" : "OFF";
      }
      
      // Fallback to default in template if config is undefined
      if (val === undefined) {
        val = field.default;
      }

      return {
        ...field,
        value: val
      };
    });

    return realFields;
  };

  const fields = getRealFields();
  const meta = logicMeta[name] || { color: "bg-muted", description: "", cssClass: "" };
  const prefix = engine.replace("Engine ", "").toLowerCase();
  const filledCount = fields.filter(f => f.value !== "-" && f.value !== "").length;
  const isPowerLogic = name === "POWER";

  // Group fields by category with proper ordering
  const categoriesSet = new Set(fields.map(f => f.category || "General"));
  const categories = CATEGORY_ORDER.filter(cat => categoriesSet.has(cat as any));
  // Add any categories not in our order list
  categoriesSet.forEach(cat => {
    // Cast cat to any to avoid strict typing issues with string vs defined union types
    if (!categories.includes(cat as any)) categories.push(cat as any);
  });

  return (
    <div className={cn(
      "rounded-lg border bg-background/40 overflow-hidden transition-all",
      expanded ? "border-border shadow-soft" : "border-border/50",
      isPowerLogic && expanded && "ring-1 ring-primary/20"
    )}>
      <button
        onClick={onToggle}
        className={cn(
          "w-full px-4 py-3 flex items-center justify-between transition-colors",
          expanded ? "bg-card/60" : "hover:bg-card/40"
        )}
      >
        <div className="flex items-center gap-3">
          <div className={cn("w-1 h-6 rounded-full", meta.color)} />
          <motion.div animate={{ rotate: expanded ? 90 : 0 }} transition={{ duration: 0.1 }}>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </motion.div>
          <span className="text-xs font-mono text-foreground flex items-center gap-2">
            <span className="text-muted-foreground">{prefix}/</span>
            <span className="font-semibold">{name}</span>
            {isPowerLogic && (
              <span className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-primary/10 text-primary text-[9px] font-medium">
                <Star className="w-2.5 h-2.5" />
                MAIN
              </span>
            )}
          </span>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Info className="w-3.5 h-3.5 text-muted-foreground/50 cursor-help hover:text-muted-foreground transition-colors" />
              </TooltipTrigger>
              <TooltipContent side="right" className="max-w-xs text-xs bg-popover border-border">
                {meta.description}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-24 h-1.5 bg-muted rounded-full overflow-hidden">
              <div 
                className={cn("h-full rounded-full transition-all", meta.color)} 
                style={{ width: `${(filledCount / fields.length) * 100}%`, opacity: 0.8 }} 
              />
            </div>
            <span className="text-[10px] text-muted-foreground font-mono w-12 text-right">
              {filledCount}/{fields.length}
            </span>
          </div>
        </div>
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: "auto" }}
            exit={{ height: 0 }}
            transition={{ duration: 0.12 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 pt-2 space-y-4">
              {categories.map((category) => {
                const categoryFields = filteredFields.filter(f => (f.category || "General") === category);
                const style = categoryStyles[category] || { color: "text-muted-foreground", bg: "bg-muted/5", border: "border-border/50", icon: ChevronRight };
                const Icon = style.icon;

                return (
                  <div key={category} className={cn(
                    "rounded-xl border p-3.5 shadow-sm relative overflow-hidden group transition-all duration-300",
                    "hover:shadow-lg hover:-translate-y-0.5",
                    style.bg,
                    style.border,
                    `border-l-[3px] ${style.color.replace("text-", "border-")}`
                  )}>
                    {/* Glassmorphism gradient overlay - animated on hover */}
                    <div className="absolute inset-0 bg-gradient-to-br from-white/10 via-transparent to-transparent opacity-50 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
                    
                    <div className="flex items-center gap-2.5 mb-3.5 relative z-10">
                      <div className={cn(
                        "p-1.5 rounded-lg border shadow-sm backdrop-blur-md transition-all duration-300 group-hover:scale-110", 
                        style.bg.replace("/5", "/20"), 
                        style.border,
                        style.color
                      )}>
                        <Icon className="w-3.5 h-3.5" />
                      </div>
                      <div className={cn("text-[11px] uppercase tracking-wider font-bold text-foreground/80 group-hover:text-foreground transition-colors", style.color)}>
                        {category}
                      </div>
                      <div className={cn("flex-1 h-px opacity-20 group-hover:opacity-40 transition-opacity", style.color.replace("text-", "bg-"))} />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-x-4 gap-y-3 relative z-10">
                      {categoryFields.map((field) => (
                        <ConfigField 
                          key={field.id} 
                          label={field.label} 
                          value={field.value} 
                          type={field.type}
                          unit={field.unit}
                          description={field.description}
                          options={(field as any).options}
                        />
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}