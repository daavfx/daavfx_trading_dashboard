import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  X,
  Settings,
  Palette,
  Monitor,
  Grid3X3,
  Type,
  Save,
  RotateCcw,
  Keyboard,
  Bell,
  Shield,
  HardDrive,
  Check,
  Zap
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { cn } from "@/lib/utils";
import { invoke } from "@tauri-apps/api/core";
import { open } from "@tauri-apps/plugin-dialog";
import { toast } from "sonner";
import { useSettings } from "@/contexts/SettingsContext";

interface SettingsDrawerProps {
  open: boolean;
  onClose: () => void;
}

const accentColors = [
  { id: "gold", color: "#B8860B", label: "Gold" },
  { id: "blue", color: "#3B82F6", label: "Blue" },
  { id: "emerald", color: "#10B981", label: "Emerald" },
  { id: "purple", color: "#8B5CF6", label: "Purple" },
  { id: "rose", color: "#F43F5E", label: "Rose" },
  { id: "orange", color: "#F97316", label: "Orange" },
];

const densityOptions = [
  { id: "compact", label: "Compact", description: "Dense layout for power users" },
  { id: "comfortable", label: "Comfortable", description: "Balanced spacing" },
  { id: "spacious", label: "Spacious", description: "More breathing room" },
];

export function SettingsDrawer({ open, onClose }: SettingsDrawerProps) {
  const { settings, updateSetting, saveSettings, resetSettings, hasChanges } = useSettings();
  const [activeTab, setActiveTab] = useState<"appearance" | "behavior" | "data">("appearance");
  const [mt4Path, setMt4Path] = useState<string | null>(null);
  const [mt5Path, setMt5Path] = useState<string | null>(null);


  const setBridgePath = async (platform: "MT4" | "MT5", path: string) => {
    try {
      await invoke("set_mt_path", { platform, path });
      if (platform === "MT4") setMt4Path(path);
      else setMt5Path(path);
      toast.success(`Set ${platform} path`);
    } catch (err) {
      toast.error(`Failed to set ${platform} path: ${err}`);
    }
  };

  const handleDetectPath = async (platform: "MT4" | "MT5") => {
    try {
      const cmd = platform === "MT4" ? "get_default_mt4_path" : "get_default_mt5_path";
      const path = await invoke<string>(cmd);
      await setBridgePath(platform, path);
    } catch (err) {
      toast.error(`Could not detect ${platform} path: ${err}`);
    }
  };

  const handleBrowsePath = async (platform: "MT4" | "MT5") => {
    try {
      const filePath = await open({
        filters: [{ name: "Config JSON", extensions: ["json"] }],
        multiple: false,
      });
      if (!filePath) return;
      const path = Array.isArray(filePath) ? filePath[0] : filePath;
      await setBridgePath(platform, String(path));
    } catch (err) {
      toast.error(`Failed to select ${platform} path: ${err}`);
    }
  };

  const handleTestBridge = async (platform: "MT4" | "MT5") => {
    try {
      await invoke("load_mt_config", { platform });
      toast.success(`${platform} bridge OK (config loadable)`);
    } catch (err) {
      toast.error(`Failed to load ${platform} config: ${err}`);
    }
  };

  const tabs = [
    { id: "appearance", label: "Appearance", icon: Palette },
    { id: "behavior", label: "Behavior", icon: Settings },
    { id: "data", label: "Data & Storage", icon: HardDrive },
  ] as const;

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 z-40"
          />

          {/* Drawer */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 300 }}
            className="fixed right-0 top-0 bottom-0 w-[420px] bg-background border-l border-border z-50 flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-border">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded bg-primary/10">
                  <Settings className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <h2 className="text-sm font-semibold">Settings</h2>
                  <p className="text-[10px] text-muted-foreground">Customize your experience</p>
                </div>
              </div>
              <button onClick={onClose} className="p-2 hover:bg-muted/30 rounded transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Tabs */}
            <div className="flex border-b border-border">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={cn(
                      "flex-1 flex items-center justify-center gap-2 px-4 py-3 text-xs transition-colors",
                      activeTab === tab.id
                        ? "text-foreground border-b-2 border-primary bg-muted/10"
                        : "text-muted-foreground hover:text-foreground"
                    )}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    {tab.label}
                  </button>
                );
              })}
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-5 space-y-6">
              {activeTab === "appearance" && (
                <>
                  {/* Theme */}
                  <div>
                    <h3 className="text-xs font-medium mb-3 flex items-center gap-2">
                      <Monitor className="w-3.5 h-3.5" />
                      Theme
                    </h3>
                    <div className="grid grid-cols-3 gap-2">
                      {(["dark", "light", "system"] as const).map((theme) => (
                        <button
                          key={theme}
                          onClick={() => updateSetting("theme", theme)}
                          className={cn(
                            "px-3 py-2 rounded text-xs border transition-colors capitalize",
                            settings.theme === theme
                              ? "bg-primary/10 border-primary/40 text-primary"
                              : "border-border/40 hover:border-border text-muted-foreground"
                          )}
                        >
                          {theme}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Accent Color */}
                  <div>
                    <h3 className="text-xs font-medium mb-3">Accent Color</h3>
                    <div className="flex gap-2">
                      {accentColors.map((color) => (
                        <button
                          key={color.id}
                          onClick={() => updateSetting("accentColor", color.id)}
                          className={cn(
                            "w-8 h-8 rounded-full border-2 transition-transform hover:scale-110",
                            settings.accentColor === color.id
                              ? "border-foreground scale-110"
                              : "border-transparent"
                          )}
                          style={{ backgroundColor: color.color }}
                          title={color.label}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Density */}
                  <div>
                    <h3 className="text-xs font-medium mb-3 flex items-center gap-2">
                      <Grid3X3 className="w-3.5 h-3.5" />
                      Density
                    </h3>
                    <div className="space-y-2">
                      {densityOptions.map((option) => (
                        <button
                          key={option.id}
                          onClick={() => updateSetting("density", option.id as any)}
                          className={cn(
                            "w-full px-3 py-2 rounded border text-left transition-colors",
                            settings.density === option.id
                              ? "bg-primary/10 border-primary/40"
                              : "border-border/40 hover:border-border"
                          )}
                        >
                          <div className="text-xs font-medium">{option.label}</div>
                          <div className="text-[10px] text-muted-foreground">{option.description}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Font Size */}
                  <div>
                    <h3 className="text-xs font-medium mb-3 flex items-center gap-2">
                      <Type className="w-3.5 h-3.5" />
                      Font Size: {settings.fontSize}px
                    </h3>
                    <Slider
                      value={[settings.fontSize]}
                      onValueChange={([v]) => updateSetting("fontSize", v)}
                      min={11}
                      max={16}
                      step={1}
                      className="w-full"
                    />
                  </div>

                  {/* Animations */}
                  <SettingToggle
                    label="Animations"
                    description="Enable smooth transitions and animations"
                    checked={settings.animations}
                    onCheckedChange={(v) => updateSetting("animations", v)}
                  />
                </>
              )}

              {activeTab === "behavior" && (
                <>
                  {/* Autosave */}
                  <SettingToggle
                    label="Autosave"
                    description="Automatically save changes"
                    checked={settings.autosave}
                    onCheckedChange={(v) => updateSetting("autosave", v)}
                  />

                  {settings.autosave && (
                    <div>
                      <h3 className="text-xs font-medium mb-2">
                        Autosave Interval: {settings.autosaveInterval}s
                      </h3>
                      <Slider
                        value={[settings.autosaveInterval]}
                        onValueChange={([v]) => updateSetting("autosaveInterval", v)}
                        min={10}
                        max={120}
                        step={10}
                        className="w-full"
                      />
                    </div>
                  )}

                  {/* Notifications */}
                  <SettingToggle
                    label="Notifications"
                    description="Show desktop notifications"
                    icon={<Bell className="w-3.5 h-3.5" />}
                    checked={settings.notifications}
                    onCheckedChange={(v) => updateSetting("notifications", v)}
                  />

                  {/* Sound Effects */}
                  <SettingToggle
                    label="Sound Effects"
                    description="Play sounds for actions"
                    checked={settings.soundEffects}
                    onCheckedChange={(v) => updateSetting("soundEffects", v)}
                  />

                  {/* Confirm on Close */}
                  <SettingToggle
                    label="Confirm on Close"
                    description="Ask before closing with unsaved changes"
                    icon={<Shield className="w-3.5 h-3.5" />}
                    checked={settings.confirmOnClose}
                    onCheckedChange={(v) => updateSetting("confirmOnClose", v)}
                  />

                  {/* Auto-Approve Transactions */}
                  <SettingToggle
                    label="Auto-Approve Transactions"
                    description="Automatically apply chat-generated plans"
                    icon={<Zap className="w-3.5 h-3.5" />}
                    checked={settings.autoApproveTransactions}
                    onCheckedChange={(v) => updateSetting("autoApproveTransactions", v)}
                  />

                  {/* Keyboard Shortcuts */}
                  <SettingToggle
                    label="Keyboard Shortcuts"
                    description="Enable keyboard shortcuts"
                    icon={<Keyboard className="w-3.5 h-3.5" />}
                    checked={settings.keyboardShortcuts}
                    onCheckedChange={(v) => updateSetting("keyboardShortcuts", v)}
                  />

                  {/* Tooltips */}
                  <SettingToggle
                    label="Show Tooltips"
                    description="Display helpful tooltips on hover"
                    checked={settings.showTooltips}
                    onCheckedChange={(v) => updateSetting("showTooltips", v)}
                  />
                </>
              )}

              {activeTab === "data" && (
                <>
                  {/* MT4 / MT5 Bridge */}
                  <div className="p-4 rounded border border-border/40 bg-muted/10 space-y-3">
                    <h3 className="text-xs font-medium mb-1 flex items-center gap-2">
                      <HardDrive className="w-3.5 h-3.5" />
                      MT4 / MT5 Bridge
                    </h3>
                    <p className="text-[10px] text-muted-foreground mb-1">
                      Configure connection to your MetaTrader config files (DAAVFX_Config.json).
                    </p>

                    {/* MT4 */}
                    <div className="mt-1 space-y-1 text-[10px]">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-medium">MT4</span>
                        <span className="text-muted-foreground truncate max-w-[220px]">
                          {mt4Path || "Path not set"}
                        </span>
                      </div>
                      <div className="flex gap-2 mt-1">
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-7 text-[10px] px-2"
                          onClick={() => handleDetectPath("MT4")}
                        >
                          Detect
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-7 text-[10px] px-2"
                          onClick={() => handleBrowsePath("MT4")}
                        >
                          Browse…
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-7 text-[10px] px-2"
                          onClick={() => handleTestBridge("MT4")}
                        >
                          Test
                        </Button>
                      </div>
                    </div>

                    {/* MT5 */}
                    <div className="mt-3 space-y-1 text-[10px]">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-medium">MT5</span>
                        <span className="text-muted-foreground truncate max-w-[220px]">
                          {mt5Path || "Path not set"}
                        </span>
                      </div>
                      <div className="flex gap-2 mt-1">
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-7 text-[10px] px-2"
                          onClick={() => handleDetectPath("MT5")}
                        >
                          Detect
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-7 text-[10px] px-2"
                          onClick={() => handleBrowsePath("MT5")}
                        >
                          Browse…
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-7 text-[10px] px-2"
                          onClick={() => handleTestBridge("MT5")}
                        >
                          Test
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Grid Lines */}
                  <SettingToggle
                    label="Grid Lines"
                    description="Show grid lines in tables"
                    checked={settings.gridLines}
                    onCheckedChange={(v) => updateSetting("gridLines", v)}
                  />

                  {/* Highlight Changes */}
                  <SettingToggle
                    label="Highlight Changes"
                    description="Highlight modified values"
                    checked={settings.highlightChanges}
                    onCheckedChange={(v) => updateSetting("highlightChanges", v)}
                  />

                  {/* Storage Info */}
                  <div className="p-4 rounded border border-border/40 bg-muted/10">
                    <h3 className="text-xs font-medium mb-3">Local Storage</h3>
                    <div className="space-y-2 text-[10px]">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Settings</span>
                        <span>1.2 KB</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Vault Snapshots</span>
                        <span>24.5 KB</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Autosave Data</span>
                        <span>8.3 KB</span>
                      </div>
                    </div>
                    <Button variant="outline" size="sm" className="w-full mt-3 h-7 text-xs">
                      Clear Local Data
                    </Button>
                  </div>
                </>
              )}
            </div>

            {/* Footer */}
            <div className="border-t border-border p-4 flex items-center justify-between">
              <Button variant="outline" size="sm" onClick={resetSettings} className="h-8 text-xs gap-1">
                <RotateCcw className="w-3 h-3" />
                Reset to Default
              </Button>
              <Button
                size="sm"
                onClick={saveSettings}
                disabled={!hasChanges}
                className="h-8 text-xs gap-1"
              >
                <Save className="w-3 h-3" />
                Save Settings
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

function SettingToggle({
  label,
  description,
  icon,
  checked,
  onCheckedChange,
}: {
  label: string;
  description: string;
  icon?: React.ReactNode;
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between py-2">
      <div>
        <div className="text-xs font-medium flex items-center gap-2">
          {icon}
          {label}
        </div>
        <p className="text-[10px] text-muted-foreground">{description}</p>
      </div>
      <Switch checked={checked} onCheckedChange={onCheckedChange} />
    </div>
  );
}