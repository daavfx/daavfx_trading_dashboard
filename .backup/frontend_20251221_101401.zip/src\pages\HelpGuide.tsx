import { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ArrowLeft, Search, BookOpen, Lightbulb, AlertCircle, Link2 } from "lucide-react";
import { HELP_CATEGORIES, HELP_ENTRIES, getHelpByCategory, searchHelp, HelpEntry, HelpCategory } from "@/data/help-docs";

export default function HelpGuide() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedEntry, setSelectedEntry] = useState<HelpEntry | null>(null);

  // Search results
  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return null;
    return searchHelp(searchQuery);
  }, [searchQuery]);

  // Category entries
  const categoryEntries = useMemo(() => {
    if (!selectedCategory) return [];
    return getHelpByCategory(selectedCategory);
  }, [selectedCategory]);

  // Render markdown-like content
  const renderContent = (text: string) => {
    return text.split('\n').map((line, i) => {
      // Headers
      if (line.startsWith('**') && line.endsWith('**')) {
        return <p key={i} className="font-bold text-foreground mt-3 mb-1">{line.replace(/\*\*/g, '')}</p>;
      }
      // Bold inline
      if (line.includes('**')) {
        const parts = line.split(/\*\*(.+?)\*\*/g);
        return (
          <p key={i} className="text-muted-foreground leading-relaxed">
            {parts.map((part, j) => j % 2 === 1 ? <strong key={j} className="text-foreground">{part}</strong> : part)}
          </p>
        );
      }
      // List items
      if (line.startsWith('- ')) {
        return <li key={i} className="text-muted-foreground ml-4">{line.substring(2)}</li>;
      }
      // Numbered items
      if (/^\d+\./.test(line)) {
        return <li key={i} className="text-muted-foreground ml-4 list-decimal">{line.substring(line.indexOf('.') + 2)}</li>;
      }
      // Empty lines
      if (!line.trim()) return <br key={i} />;
      // Regular text
      return <p key={i} className="text-muted-foreground leading-relaxed">{line}</p>;
    });
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={() => navigate("/")}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
            <div className="flex-1">
              <h1 className="text-xl font-bold flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-primary" />
                DAAVFX Help & Guide
              </h1>
            </div>
          </div>
          
          {/* Search */}
          <div className="mt-4 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search inputs, concepts, or trading terms..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setSelectedCategory(null);
                setSelectedEntry(null);
              }}
              className="pl-10 bg-card border-border"
            />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-12 gap-6">
          {/* Sidebar - Categories */}
          <div className="col-span-3">
            <Card className="sticky top-32">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Categories</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[calc(100vh-280px)]">
                  <div className="p-2 space-y-1">
                    {HELP_CATEGORIES.map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => {
                          setSelectedCategory(cat.id);
                          setSelectedEntry(null);
                          setSearchQuery("");
                        }}
                        className={`w-full text-left px-3 py-2 rounded-md text-sm flex items-center gap-2 transition-colors ${
                          selectedCategory === cat.id
                            ? "bg-primary/10 text-primary"
                            : "hover:bg-muted text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        <span>{cat.icon}</span>
                        <span>{cat.name}</span>
                        <Badge variant="secondary" className="ml-auto text-[10px]">
                          {getHelpByCategory(cat.id).length}
                        </Badge>
                      </button>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="col-span-9">
            {/* Search Results */}
            {searchResults && (
              <div className="space-y-4">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <Search className="w-4 h-4" />
                  Search Results
                  <Badge variant="outline">{searchResults.length} found</Badge>
                </h2>
                {searchResults.length === 0 ? (
                  <Card className="p-8 text-center">
                    <AlertCircle className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
                    <p className="text-muted-foreground">No results found for "{searchQuery}"</p>
                    <p className="text-sm text-muted-foreground/60 mt-1">Try different keywords or browse categories</p>
                  </Card>
                ) : (
                  <div className="grid gap-3">
                    {searchResults.map((entry) => (
                      <Card
                        key={entry.id}
                        className="cursor-pointer hover:border-primary/50 transition-colors"
                        onClick={() => {
                          setSelectedEntry(entry);
                          setSearchQuery("");
                        }}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between gap-4">
                            <div>
                              <h3 className="font-medium">{entry.title}</h3>
                              <p className="text-sm text-muted-foreground mt-1">{entry.shortDesc}</p>
                            </div>
                            <Badge variant="secondary">{HELP_CATEGORIES.find(c => c.id === entry.category)?.name}</Badge>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Category View */}
            {!searchResults && selectedCategory && !selectedEntry && (
              <div className="space-y-4">
                <div className="flex items-center gap-3 mb-6">
                  <span className="text-2xl">{HELP_CATEGORIES.find(c => c.id === selectedCategory)?.icon}</span>
                  <div>
                    <h2 className="text-xl font-bold">{HELP_CATEGORIES.find(c => c.id === selectedCategory)?.name}</h2>
                    <p className="text-muted-foreground">{HELP_CATEGORIES.find(c => c.id === selectedCategory)?.description}</p>
                  </div>
                </div>
                
                <Accordion type="single" collapsible className="space-y-2">
                  {categoryEntries.map((entry) => (
                    <AccordionItem key={entry.id} value={entry.id} className="border rounded-lg px-4">
                      <AccordionTrigger className="hover:no-underline py-4">
                        <div className="flex items-center gap-3 text-left">
                          <div>
                            <div className="font-medium">{entry.title}</div>
                            <div className="text-sm text-muted-foreground">{entry.shortDesc}</div>
                          </div>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="pb-4">
                        <div className="space-y-4">
                          <div className="prose prose-sm dark:prose-invert max-w-none">
                            {renderContent(entry.fullDesc)}
                          </div>
                          
                          {entry.examples && entry.examples.length > 0 && (
                            <div className="bg-blue-500/5 border border-blue-500/20 rounded-lg p-4">
                              <h4 className="font-medium flex items-center gap-2 text-blue-400 mb-2">
                                <Lightbulb className="w-4 h-4" />
                                Examples
                              </h4>
                              <ul className="space-y-1">
                                {entry.examples.map((ex, i) => (
                                  <li key={i} className="text-sm text-muted-foreground">• {ex}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                          
                          {entry.tips && entry.tips.length > 0 && (
                            <div className="bg-green-500/5 border border-green-500/20 rounded-lg p-4">
                              <h4 className="font-medium flex items-center gap-2 text-green-400 mb-2">
                                <AlertCircle className="w-4 h-4" />
                                Pro Tips
                              </h4>
                              <ul className="space-y-1">
                                {entry.tips.map((tip, i) => (
                                  <li key={i} className="text-sm text-muted-foreground">• {tip}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                          
                          {entry.relatedInputs && entry.relatedInputs.length > 0 && (
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-sm text-muted-foreground flex items-center gap-1">
                                <Link2 className="w-3 h-3" /> Related:
                              </span>
                              {entry.relatedInputs.map((rel) => (
                                <Badge key={rel} variant="outline" className="cursor-pointer hover:bg-primary/10"
                                  onClick={() => {
                                    const relEntry = HELP_ENTRIES.find(e => e.id === rel);
                                    if (relEntry) setSelectedEntry(relEntry);
                                  }}>
                                  {rel}
                                </Badge>
                              ))}
                            </div>
                          )}
                          
                          {entry.mt4Variable && (
                            <div className="text-xs text-muted-foreground/60 font-mono bg-muted/30 rounded px-2 py-1 inline-block">
                              MT4/MT5: {entry.mt4Variable}
                            </div>
                          )}
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            )}

            {/* Single Entry Detail View */}
            {selectedEntry && (
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-2 mb-2">
                    <Button variant="ghost" size="sm" onClick={() => {
                      setSelectedEntry(null);
                      if (!selectedCategory) {
                        setSelectedCategory(selectedEntry.category);
                      }
                    }}>
                      <ArrowLeft className="w-4 h-4 mr-1" /> Back
                    </Button>
                    <Badge variant="secondary">
                      {HELP_CATEGORIES.find(c => c.id === selectedEntry.category)?.icon}{" "}
                      {HELP_CATEGORIES.find(c => c.id === selectedEntry.category)?.name}
                    </Badge>
                  </div>
                  <CardTitle className="text-2xl">{selectedEntry.title}</CardTitle>
                  <p className="text-muted-foreground">{selectedEntry.shortDesc}</p>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="prose prose-sm dark:prose-invert max-w-none">
                    {renderContent(selectedEntry.fullDesc)}
                  </div>
                  
                  {selectedEntry.examples && selectedEntry.examples.length > 0 && (
                    <div className="bg-blue-500/5 border border-blue-500/20 rounded-lg p-4">
                      <h4 className="font-medium flex items-center gap-2 text-blue-400 mb-3">
                        <Lightbulb className="w-4 h-4" />
                        Examples
                      </h4>
                      <ul className="space-y-2">
                        {selectedEntry.examples.map((ex, i) => (
                          <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                            <span className="text-blue-400">•</span> {ex}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  {selectedEntry.tips && selectedEntry.tips.length > 0 && (
                    <div className="bg-green-500/5 border border-green-500/20 rounded-lg p-4">
                      <h4 className="font-medium flex items-center gap-2 text-green-400 mb-3">
                        <AlertCircle className="w-4 h-4" />
                        Pro Tips
                      </h4>
                      <ul className="space-y-2">
                        {selectedEntry.tips.map((tip, i) => (
                          <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                            <span className="text-green-400">•</span> {tip}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  {selectedEntry.relatedInputs && selectedEntry.relatedInputs.length > 0 && (
                    <div className="border-t pt-4">
                      <h4 className="text-sm font-medium mb-3 flex items-center gap-2">
                        <Link2 className="w-4 h-4" /> Related Inputs
                      </h4>
                      <div className="flex gap-2 flex-wrap">
                        {selectedEntry.relatedInputs.map((rel) => (
                          <Badge key={rel} variant="outline" className="cursor-pointer hover:bg-primary/10"
                            onClick={() => {
                              const relEntry = HELP_ENTRIES.find(e => e.id === rel);
                              if (relEntry) setSelectedEntry(relEntry);
                            }}>
                            {rel}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {selectedEntry.mt4Variable && (
                    <div className="border-t pt-4">
                      <span className="text-xs text-muted-foreground">MT4/MT5 Variable Pattern:</span>
                      <code className="block mt-1 text-sm font-mono bg-muted/50 rounded px-3 py-2">
                        {selectedEntry.mt4Variable}
                      </code>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Welcome View */}
            {!searchResults && !selectedCategory && !selectedEntry && (
              <div className="space-y-6">
                <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
                  <CardContent className="p-6">
                    <h2 className="text-2xl font-bold mb-2">Welcome to DAAVFX Documentation</h2>
                    <p className="text-muted-foreground mb-4">
                      Complete guide to all trading inputs, strategies, and system concepts.
                      Use the search bar or browse categories to find what you need.
                    </p>
                    <div className="grid grid-cols-3 gap-4 mt-6">
                      <div className="text-center p-4 bg-background/50 rounded-lg">
                        <div className="text-3xl font-bold text-primary">{HELP_ENTRIES.length}</div>
                        <div className="text-sm text-muted-foreground">Documented Inputs</div>
                      </div>
                      <div className="text-center p-4 bg-background/50 rounded-lg">
                        <div className="text-3xl font-bold text-primary">{HELP_CATEGORIES.length}</div>
                        <div className="text-sm text-muted-foreground">Categories</div>
                      </div>
                      <div className="text-center p-4 bg-background/50 rounded-lg">
                        <div className="text-3xl font-bold text-primary">21</div>
                        <div className="text-sm text-muted-foreground">Trading Logics</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <h3 className="text-lg font-semibold">Quick Start Categories</h3>
                <div className="grid grid-cols-2 gap-4">
                  {HELP_CATEGORIES.slice(0, 6).map((cat) => (
                    <Card
                      key={cat.id}
                      className="cursor-pointer hover:border-primary/50 transition-colors"
                      onClick={() => setSelectedCategory(cat.id)}
                    >
                      <CardContent className="p-4 flex items-start gap-3">
                        <span className="text-2xl">{cat.icon}</span>
                        <div>
                          <h4 className="font-medium">{cat.name}</h4>
                          <p className="text-sm text-muted-foreground">{cat.description}</p>
                          <Badge variant="secondary" className="mt-2 text-[10px]">
                            {getHelpByCategory(cat.id).length} entries
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                <h3 className="text-lg font-semibold mt-6">Most Important Inputs</h3>
                <div className="grid gap-3">
                  {["close_targets", "initial_lot", "multiplier", "grid", "trail_method"].map((id) => {
                    const entry = HELP_ENTRIES.find(e => e.id === id);
                    if (!entry) return null;
                    return (
                      <Card
                        key={id}
                        className="cursor-pointer hover:border-primary/50 transition-colors"
                        onClick={() => setSelectedEntry(entry)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between gap-4">
                            <div>
                              <h4 className="font-medium">{entry.title}</h4>
                              <p className="text-sm text-muted-foreground mt-1">{entry.shortDesc}</p>
                            </div>
                            <Badge variant="outline">{HELP_CATEGORIES.find(c => c.id === entry.category)?.name}</Badge>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
