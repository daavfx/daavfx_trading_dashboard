import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Save, Tag, FolderOpen, FileText, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

interface VaultSaveModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (data: VaultSaveData) => void;
}

interface VaultSaveData {
  name: string;
  category: string;
  strategyType: "buy" | "sell" | "both";
  tags: string[];
  comments: string;
}

export function VaultSaveModal({ open, onClose, onSave }: VaultSaveModalProps) {
  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [strategyType, setStrategyType] = useState<"buy" | "sell" | "both">("both");
  const [tags, setTags] = useState("");
  const [comments, setComments] = useState("");

  const handleSave = () => {
    onSave({
      name,
      category,
      strategyType,
      tags: tags.split(",").map((t) => t.trim()).filter(Boolean),
      comments,
    });
    onClose();
  };

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50"
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-md z-50"
          >
            <div className="card-gradient-border rounded-xl shadow-elevated">
              <div className="bg-card rounded-xl p-6">
                {/* Header */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Save className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h2 className="text-lg font-semibold text-foreground">Save to Vault</h2>
                      <p className="text-sm text-muted-foreground">Store your configuration</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" onClick={onClose} className="text-muted-foreground">
                    <X className="w-5 h-5" />
                  </Button>
                </div>

                {/* Form */}
                <div className="space-y-4">
                  {/* Name */}
                  <div className="space-y-2">
                    <Label className="text-sm text-muted-foreground flex items-center gap-2">
                      <FileText className="w-4 h-4" />
                      Name
                    </Label>
                    <Input
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Enter configuration name"
                      className="bg-background border-border-subtle"
                    />
                  </div>

                  {/* Category */}
                  <div className="space-y-2">
                    <Label className="text-sm text-muted-foreground flex items-center gap-2">
                      <FolderOpen className="w-4 h-4" />
                      Category
                    </Label>
                    <Select value={category} onValueChange={setCategory}>
                      <SelectTrigger className="bg-background border-border-subtle">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent className="bg-popover border-border">
                        <SelectItem value="scalping">Scalping</SelectItem>
                        <SelectItem value="swing">Swing Trading</SelectItem>
                        <SelectItem value="hedge">Hedge</SelectItem>
                        <SelectItem value="grid">Grid</SelectItem>
                        <SelectItem value="custom">Custom</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Strategy Type */}
                  <div className="space-y-2">
                    <Label className="text-sm text-muted-foreground">Strategy Type</Label>
                    <div className="flex gap-2">
                      {(["buy", "sell", "both"] as const).map((type) => (
                        <button
                          key={type}
                          onClick={() => setStrategyType(type)}
                          className={cn(
                            "flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-all",
                            strategyType === type
                              ? "bg-primary text-primary-foreground"
                              : "bg-background border border-border text-muted-foreground hover:border-primary/50"
                          )}
                        >
                          {type.charAt(0).toUpperCase() + type.slice(1)}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Tags */}
                  <div className="space-y-2">
                    <Label className="text-sm text-muted-foreground flex items-center gap-2">
                      <Tag className="w-4 h-4" />
                      Tags
                    </Label>
                    <Input
                      value={tags}
                      onChange={(e) => setTags(e.target.value)}
                      placeholder="Enter tags, separated by commas"
                      className="bg-background border-border-subtle"
                    />
                  </div>

                  {/* Comments */}
                  <div className="space-y-2">
                    <Label className="text-sm text-muted-foreground flex items-center gap-2">
                      <MessageSquare className="w-4 h-4" />
                      Comments
                    </Label>
                    <Textarea
                      value={comments}
                      onChange={(e) => setComments(e.target.value)}
                      placeholder="Add any notes or comments"
                      rows={3}
                      className="bg-background border-border-subtle resize-none"
                    />
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-3 mt-6">
                  <Button variant="outline" onClick={onClose} className="flex-1">
                    Cancel
                  </Button>
                  <Button onClick={handleSave} className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 glow-gold">
                    <Save className="w-4 h-4 mr-2" />
                    Save Configuration
                  </Button>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
