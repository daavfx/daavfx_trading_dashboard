import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  X,
  Settings,
  Palette,
  Monitor,
  Grid3X3,
  Type,
  Save,
  RotateCcw,
  Keyboard,
  Bell,
  Shield,
  HardDrive,
  Check,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { cn } from "@/lib/utils";

interface SettingsDrawerProps {
  open: boolean;
  onClose: () => void;
}

interface SettingsState {
  theme: "dark" | "light" | "system";
  accentColor: string;
  density: "compact" | "comfortable" | "spacious";
  fontSize: number;
  animations: boolean;
  autosave: boolean;
  autosaveInterval: number;
  notifications: boolean;
  soundEffects: boolean;
  confirmOnClose: boolean;
  keyboardShortcuts: boolean;
  showTooltips: boolean;
  gridLines: boolean;
  highlightChanges: boolean;
}

const defaultSettings: SettingsState = {
  theme: "dark",
  accentColor: "gold",
  density: "comfortable",
  fontSize: 13,
  animations: true,
  autosave: true,
  autosaveInterval: 30,
  notifications: true,
  soundEffects: false,
  confirmOnClose: true,
  keyboardShortcuts: true,
  showTooltips: true,
  gridLines: true,
  highlightChanges: true,
};

const accentColors = [
  { id: "gold", color: "#B8860B", label: "Gold" },
  { id: "blue", color: "#3B82F6", label: "Blue" },
  { id: "emerald", color: "#10B981", label: "Emerald" },
  { id: "purple", color: "#8B5CF6", label: "Purple" },
  { id: "rose", color: "#F43F5E", label: "Rose" },
  { id: "orange", color: "#F97316", label: "Orange" },
];

const densityOptions = [
  { id: "compact", label: "Compact", description: "Dense layout for power users" },
  { id: "comfortable", label: "Comfortable", description: "Balanced spacing" },
  { id: "spacious", label: "Spacious", description: "More breathing room" },
];

export function SettingsDrawer({ open, onClose }: SettingsDrawerProps) {
  const [settings, setSettings] = useState<SettingsState>(defaultSettings);
  const [activeTab, setActiveTab] = useState<"appearance" | "behavior" | "data">("appearance");
  const [hasChanges, setHasChanges] = useState(false);

  const updateSetting = <K extends keyof SettingsState>(key: K, value: SettingsState[K]) => {
    setSettings((prev) => ({ ...prev, [key]: value }));
    setHasChanges(true);
  };

  const saveSettings = () => {
    localStorage.setItem("daavfx-settings", JSON.stringify(settings));
    setHasChanges(false);
    console.log("Settings saved:", settings);
  };

  const resetSettings = () => {
    setSettings(defaultSettings);
    setHasChanges(true);
  };

  const tabs = [
    { id: "appearance", label: "Appearance", icon: Palette },
    { id: "behavior", label: "Behavior", icon: Settings },
    { id: "data", label: "Data & Storage", icon: HardDrive },
  ] as const;

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 z-40"
          />

          {/* Drawer */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 300 }}
            className="fixed right-0 top-0 bottom-0 w-[420px] bg-background border-l border-border z-50 flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-border">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded bg-primary/10">
                  <Settings className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <h2 className="text-sm font-semibold">Settings</h2>
                  <p className="text-[10px] text-muted-foreground">Customize your experience</p>
                </div>
              </div>
              <button onClick={onClose} className="p-2 hover:bg-muted/30 rounded transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Tabs */}
            <div className="flex border-b border-border">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={cn(
                      "flex-1 flex items-center justify-center gap-2 px-4 py-3 text-xs transition-colors",
                      activeTab === tab.id
                        ? "text-foreground border-b-2 border-primary bg-muted/10"
                        : "text-muted-foreground hover:text-foreground"
                    )}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    {tab.label}
                  </button>
                );
              })}
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-5 space-y-6">
              {activeTab === "appearance" && (
                <>
                  {/* Theme */}
                  <div>
                    <h3 className="text-xs font-medium mb-3 flex items-center gap-2">
                      <Monitor className="w-3.5 h-3.5" />
                      Theme
                    </h3>
                    <div className="grid grid-cols-3 gap-2">
                      {(["dark", "light", "system"] as const).map((theme) => (
                        <button
                          key={theme}
                          onClick={() => updateSetting("theme", theme)}
                          className={cn(
                            "px-3 py-2 rounded text-xs border transition-colors capitalize",
                            settings.theme === theme
                              ? "bg-primary/10 border-primary/40 text-primary"
                              : "border-border/40 hover:border-border text-muted-foreground"
                          )}
                        >
                          {theme}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Accent Color */}
                  <div>
                    <h3 className="text-xs font-medium mb-3">Accent Color</h3>
                    <div className="flex gap-2">
                      {accentColors.map((color) => (
                        <button
                          key={color.id}
                          onClick={() => updateSetting("accentColor", color.id)}
                          className={cn(
                            "w-8 h-8 rounded-full border-2 transition-transform hover:scale-110",
                            settings.accentColor === color.id
                              ? "border-foreground scale-110"
                              : "border-transparent"
                          )}
                          style={{ backgroundColor: color.color }}
                          title={color.label}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Density */}
                  <div>
                    <h3 className="text-xs font-medium mb-3 flex items-center gap-2">
                      <Grid3X3 className="w-3.5 h-3.5" />
                      Density
                    </h3>
                    <div className="space-y-2">
                      {densityOptions.map((option) => (
                        <button
                          key={option.id}
                          onClick={() => updateSetting("density", option.id as any)}
                          className={cn(
                            "w-full px-3 py-2 rounded border text-left transition-colors",
                            settings.density === option.id
                              ? "bg-primary/10 border-primary/40"
                              : "border-border/40 hover:border-border"
                          )}
                        >
                          <div className="text-xs font-medium">{option.label}</div>
                          <div className="text-[10px] text-muted-foreground">{option.description}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Font Size */}
                  <div>
                    <h3 className="text-xs font-medium mb-3 flex items-center gap-2">
                      <Type className="w-3.5 h-3.5" />
                      Font Size: {settings.fontSize}px
                    </h3>
                    <Slider
                      value={[settings.fontSize]}
                      onValueChange={([v]) => updateSetting("fontSize", v)}
                      min={11}
                      max={16}
                      step={1}
                      className="w-full"
                    />
                  </div>

                  {/* Animations */}
                  <SettingToggle
                    label="Animations"
                    description="Enable smooth transitions and animations"
                    checked={settings.animations}
                    onCheckedChange={(v) => updateSetting("animations", v)}
                  />
                </>
              )}

              {activeTab === "behavior" && (
                <>
                  {/* Autosave */}
                  <SettingToggle
                    label="Autosave"
                    description="Automatically save changes"
                    checked={settings.autosave}
                    onCheckedChange={(v) => updateSetting("autosave", v)}
                  />

                  {settings.autosave && (
                    <div>
                      <h3 className="text-xs font-medium mb-2">
                        Autosave Interval: {settings.autosaveInterval}s
                      </h3>
                      <Slider
                        value={[settings.autosaveInterval]}
                        onValueChange={([v]) => updateSetting("autosaveInterval", v)}
                        min={10}
                        max={120}
                        step={10}
                        className="w-full"
                      />
                    </div>
                  )}

                  {/* Notifications */}
                  <SettingToggle
                    label="Notifications"
                    description="Show desktop notifications"
                    icon={<Bell className="w-3.5 h-3.5" />}
                    checked={settings.notifications}
                    onCheckedChange={(v) => updateSetting("notifications", v)}
                  />

                  {/* Sound Effects */}
                  <SettingToggle
                    label="Sound Effects"
                    description="Play sounds for actions"
                    checked={settings.soundEffects}
                    onCheckedChange={(v) => updateSetting("soundEffects", v)}
                  />

                  {/* Confirm on Close */}
                  <SettingToggle
                    label="Confirm on Close"
                    description="Ask before closing with unsaved changes"
                    icon={<Shield className="w-3.5 h-3.5" />}
                    checked={settings.confirmOnClose}
                    onCheckedChange={(v) => updateSetting("confirmOnClose", v)}
                  />

                  {/* Keyboard Shortcuts */}
                  <SettingToggle
                    label="Keyboard Shortcuts"
                    description="Enable keyboard shortcuts"
                    icon={<Keyboard className="w-3.5 h-3.5" />}
                    checked={settings.keyboardShortcuts}
                    onCheckedChange={(v) => updateSetting("keyboardShortcuts", v)}
                  />

                  {/* Tooltips */}
                  <SettingToggle
                    label="Show Tooltips"
                    description="Display helpful tooltips on hover"
                    checked={settings.showTooltips}
                    onCheckedChange={(v) => updateSetting("showTooltips", v)}
                  />
                </>
              )}

              {activeTab === "data" && (
                <>
                  {/* Grid Lines */}
                  <SettingToggle
                    label="Grid Lines"
                    description="Show grid lines in tables"
                    checked={settings.gridLines}
                    onCheckedChange={(v) => updateSetting("gridLines", v)}
                  />

                  {/* Highlight Changes */}
                  <SettingToggle
                    label="Highlight Changes"
                    description="Highlight modified values"
                    checked={settings.highlightChanges}
                    onCheckedChange={(v) => updateSetting("highlightChanges", v)}
                  />

                  {/* Storage Info */}
                  <div className="p-4 rounded border border-border/40 bg-muted/10">
                    <h3 className="text-xs font-medium mb-3">Local Storage</h3>
                    <div className="space-y-2 text-[10px]">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Settings</span>
                        <span>1.2 KB</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Vault Snapshots</span>
                        <span>24.5 KB</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Autosave Data</span>
                        <span>8.3 KB</span>
                      </div>
                    </div>
                    <Button variant="outline" size="sm" className="w-full mt-3 h-7 text-xs">
                      Clear Local Data
                    </Button>
                  </div>
                </>
              )}
            </div>

            {/* Footer */}
            <div className="border-t border-border p-4 flex items-center justify-between">
              <Button variant="outline" size="sm" onClick={resetSettings} className="h-8 text-xs gap-1">
                <RotateCcw className="w-3 h-3" />
                Reset to Default
              </Button>
              <Button
                size="sm"
                onClick={saveSettings}
                disabled={!hasChanges}
                className="h-8 text-xs gap-1"
              >
                <Save className="w-3 h-3" />
                Save Settings
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

function SettingToggle({
  label,
  description,
  icon,
  checked,
  onCheckedChange,
}: {
  label: string;
  description: string;
  icon?: React.ReactNode;
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between py-2">
      <div>
        <div className="text-xs font-medium flex items-center gap-2">
          {icon}
          {label}
        </div>
        <p className="text-[10px] text-muted-foreground">{description}</p>
      </div>
      <Switch checked={checked} onCheckedChange={onCheckedChange} />
    </div>
  );
}