import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ChevronRight,
  Shield,
  Newspaper,
  Clock,
  Key,
  Settings2,
  Palette,
  FileText,
  TrendingDown,
  Calendar,
  Globe,
  Lock,
  Eye,
  Terminal,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { ConfigField } from "./ConfigField";
import { Platform } from "@/components/layout/TopBar";

interface GeneralCategoriesProps {
  platform: Platform;
  allCollapsed?: boolean;
}

const categoryFields = {
  risk: [
    { id: "max_drawdown", label: "Max Drawdown %", value: 20, type: "number" as const, unit: "%" },
    { id: "daily_loss_limit", label: "Daily Loss Limit", value: 500, type: "number" as const, unit: "$" },
    { id: "weekly_loss_limit", label: "Weekly Loss Limit", value: 2000, type: "number" as const, unit: "$" },
    { id: "max_position_size", label: "Max Position Size", value: 5.0, type: "number" as const, unit: "lots" },
    { id: "risk_per_trade", label: "Risk Per Trade", value: 2, type: "number" as const, unit: "%" },
    { id: "equity_stop", label: "Equity Stop", value: "ON", type: "toggle" as const },
    { id: "equity_stop_level", label: "Equity Stop Level", value: 10000, type: "number" as const, unit: "$" },
    { id: "margin_call_level", label: "Margin Call Level", value: 50, type: "number" as const, unit: "%" },
  ],
  news: [
    { id: "news_filter", label: "News Filter", value: "ON", type: "toggle" as const },
    { id: "high_impact", label: "High Impact", value: "ON", type: "toggle" as const },
    { id: "medium_impact", label: "Medium Impact", value: "OFF", type: "toggle" as const },
    { id: "low_impact", label: "Low Impact", value: "OFF", type: "toggle" as const },
    { id: "minutes_before", label: "Minutes Before", value: 30, type: "number" as const },
    { id: "minutes_after", label: "Minutes After", value: 30, type: "number" as const },
    { id: "nfp_filter", label: "NFP Filter", value: "ON", type: "toggle" as const },
    { id: "fomc_filter", label: "FOMC Filter", value: "ON", type: "toggle" as const },
  ],
  time: [
    { id: "time_filter", label: "Time Filter", value: "ON", type: "toggle" as const },
    { id: "monday", label: "Monday", value: "ON", type: "toggle" as const },
    { id: "tuesday", label: "Tuesday", value: "ON", type: "toggle" as const },
    { id: "wednesday", label: "Wednesday", value: "ON", type: "toggle" as const },
    { id: "thursday", label: "Thursday", value: "ON", type: "toggle" as const },
    { id: "friday", label: "Friday", value: "ON", type: "toggle" as const },
    { id: "start_hour", label: "Start Hour", value: 8, type: "number" as const },
    { id: "end_hour", label: "End Hour", value: 22, type: "number" as const },
    { id: "gmt_offset", label: "GMT Offset", value: 0, type: "number" as const },
  ],
  license: [
    { id: "license_key", label: "License Key", value: "****-****-****", type: "text" as const },
    { id: "account_number", label: "Account Number", value: "12345678", type: "text" as const },
    { id: "expiry_date", label: "Expiry Date", value: "2025-12-31", type: "text" as const },
    { id: "demo_allowed", label: "Demo Allowed", value: "ON", type: "toggle" as const },
    { id: "live_allowed", label: "Live Allowed", value: "ON", type: "toggle" as const },
  ],
  general: [
    { id: "magic_number", label: "Magic Number", value: 123456, type: "number" as const },
    { id: "comment", label: "Order Comment", value: "DAAVFX", type: "text" as const },
    { id: "max_spread", label: "Max Spread", value: 30, type: "number" as const, unit: "pts" },
    { id: "slippage", label: "Slippage", value: 3, type: "number" as const, unit: "pts" },
    { id: "fill_policy", label: "Fill Policy", value: "FOK", type: "text" as const },
    { id: "retry_count", label: "Retry Count", value: 3, type: "number" as const },
  ],
  ui: [
    { id: "show_panel", label: "Show Panel", value: "ON", type: "toggle" as const },
    { id: "panel_x", label: "Panel X", value: 20, type: "number" as const },
    { id: "panel_y", label: "Panel Y", value: 50, type: "number" as const },
    { id: "show_trades", label: "Show Trades", value: "ON", type: "toggle" as const },
    { id: "show_levels", label: "Show Levels", value: "ON", type: "toggle" as const },
    { id: "chart_color_scheme", label: "Color Scheme", value: "Dark", type: "text" as const },
  ],
  logs: [
    { id: "logging_enabled", label: "Logging", value: "ON", type: "toggle" as const },
    { id: "log_level", label: "Log Level", value: "INFO", type: "text" as const },
    { id: "log_to_file", label: "Log to File", value: "ON", type: "toggle" as const },
    { id: "log_trades", label: "Log Trades", value: "ON", type: "toggle" as const },
    { id: "log_errors", label: "Log Errors", value: "ON", type: "toggle" as const },
    { id: "max_log_size", label: "Max Log Size", value: 10, type: "number" as const, unit: "MB" },
  ],
};

const categories = [
  { id: "risk", label: "Risk Management", icon: Shield, color: "text-red-400" },
  { id: "news", label: "News Filter", icon: Newspaper, color: "text-amber-400" },
  { id: "time", label: "Time Filter", icon: Clock, color: "text-blue-400" },
  { id: "license", label: "License", icon: Key, color: "text-purple-400" },
  { id: "general", label: "General", icon: Settings2, color: "text-slate-400" },
  { id: "ui", label: "UI Settings", icon: Palette, color: "text-teal-400" },
  { id: "logs", label: "Logs", icon: Terminal, color: "text-green-400" },
] as const;

export function GeneralCategories({ platform, allCollapsed }: GeneralCategoriesProps) {
  const [expandedCategories, setExpandedCategories] = useState<string[]>(["risk"]);

  const toggleCategory = (id: string) => {
    setExpandedCategories((prev) =>
      prev.includes(id) ? prev.filter((c) => c !== id) : [...prev, id]
    );
  };

  const expandAll = () => setExpandedCategories(categories.map((c) => c.id));
  const collapseAll = () => setExpandedCategories([]);

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs text-muted-foreground">General Parameters</span>
        <div className="flex gap-1">
          <button
            onClick={expandAll}
            className="text-[10px] text-muted-foreground hover:text-foreground px-2 py-1 rounded hover:bg-muted/30 transition-colors"
          >
            Expand All
          </button>
          <button
            onClick={collapseAll}
            className="text-[10px] text-muted-foreground hover:text-foreground px-2 py-1 rounded hover:bg-muted/30 transition-colors"
          >
            Collapse All
          </button>
        </div>
      </div>

      {categories.map((category) => {
        const Icon = category.icon;
        const fields = categoryFields[category.id];
        const expanded = expandedCategories.includes(category.id);
        const filledCount = fields.filter((f) => f.value !== "-" && f.value !== "").length;

        return (
          <div
            key={category.id}
            className="rounded border border-border/40 bg-card/30 overflow-hidden"
          >
            <button
              onClick={() => toggleCategory(category.id)}
              className="w-full px-4 py-3 flex items-center justify-between hover:bg-muted/20 transition-colors"
            >
              <div className="flex items-center gap-3">
                <motion.div
                  animate={{ rotate: expanded ? 90 : 0 }}
                  transition={{ duration: 0.1 }}
                >
                  <ChevronRight className="w-3.5 h-3.5 text-muted-foreground" />
                </motion.div>
                <Icon className={cn("w-4 h-4", category.color)} />
                <span className="text-sm font-medium">{category.label}</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-16 h-1.5 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-accent/70 rounded-full transition-all"
                    style={{ width: `${(filledCount / fields.length) * 100}%` }}
                  />
                </div>
                <span className="text-[10px] text-muted-foreground font-mono w-8">
                  {filledCount}/{fields.length}
                </span>
              </div>
            </button>

            <AnimatePresence>
              {expanded && (
                <motion.div
                  initial={{ height: 0 }}
                  animate={{ height: "auto" }}
                  exit={{ height: 0 }}
                  transition={{ duration: 0.15 }}
                  className="overflow-hidden"
                >
                  <div className="px-4 pb-4 pt-1 grid grid-cols-2 gap-2">
                    {fields.map((field) => (
                      <ConfigField
                        key={field.id}
                        label={field.label}
                        value={field.value}
                        type={field.type}
                        unit={(field as any).unit}
                      />
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
}
