import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip";
import { Info } from "lucide-react";

interface ConfigFieldProps {
  label: string;
  value: string | number;
  type: "number" | "toggle" | "text";
  unit?: string;
  description?: string;
  onChange?: (value: string | number | boolean) => void;
}

export function ConfigField({ label, value, type, unit, description, onChange }: ConfigFieldProps) {
  const [localValue, setLocalValue] = useState(value);

  const handleChange = (newValue: string | number | boolean) => {
    setLocalValue(newValue as string | number);
    onChange?.(newValue);
  };

  return (
    <div className="group flex items-center justify-between py-2 px-2.5 rounded-md bg-card/40 border border-border/30 hover:border-border/50 hover:bg-card/60 transition-all">
      <div className="flex items-center gap-1.5">
        <span className="text-[11px] text-muted-foreground group-hover:text-foreground/80 transition-colors">
          {label}
        </span>
        {description && (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Info className="w-3 h-3 text-muted-foreground/50 cursor-help" />
              </TooltipTrigger>
              <TooltipContent side="top" className="max-w-xs text-xs">
                {description}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}
      </div>
      
      {type === "toggle" ? (
        <div className="flex items-center gap-2">
          <Switch
            checked={localValue === "ON"}
            onCheckedChange={(checked) => handleChange(checked ? "ON" : "OFF")}
            className="h-4 w-8 data-[state=checked]:bg-accent"
          />
          <span className={cn(
            "text-[10px] font-mono w-7 text-right",
            localValue === "ON" ? "text-accent" : "text-muted-foreground"
          )}>
            {localValue}
          </span>
        </div>
      ) : type === "number" ? (
        <div className="flex items-center gap-1.5">
          <Input
            type="text"
            value={localValue}
            onChange={(e) => handleChange(e.target.value)}
            className="w-16 h-6 text-right font-mono text-[11px] px-2 bg-background/80 border-border/40 text-foreground focus:border-primary/50 focus:ring-1 focus:ring-primary/20"
          />
          {unit && (
            <span className="text-[9px] text-muted-foreground/60 w-6 text-left">{unit}</span>
          )}
        </div>
      ) : (
        <span className={cn(
          "text-[11px] font-mono px-2 py-0.5 rounded bg-background/50",
          value === "-" ? "text-muted-foreground/40" : "text-foreground"
        )}>
          {value}
        </span>
      )}
    </div>
  );
}
