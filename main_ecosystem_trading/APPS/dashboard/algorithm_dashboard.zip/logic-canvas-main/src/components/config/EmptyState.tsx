import { motion } from "framer-motion";
import { Layers, Zap, Settings, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

interface EmptyStateProps {
  onLoadSetfile: () => void;
  onChooseEngine: () => void;
}

export function EmptyState({ onLoadSetfile, onChooseEngine }: EmptyStateProps) {
  const steps = [
    {
      icon: Layers,
      title: "Select an Engine",
      description: "Choose from Engine A, B, or C to configure trading logic",
    },
    {
      icon: Settings,
      title: "Configure Groups",
      description: "Set up groups 1-15 with your preferred parameters",
    },
    {
      icon: Zap,
      title: "Tune Logics",
      description: "Adjust REPOWER, SCALPER, STOPPER and more",
    },
    {
      icon: ArrowRight,
      title: "Export & Deploy",
      description: "Generate setfiles for MT4, MT5, or other platforms",
    },
  ];

  return (
    <div className="flex-1 flex items-center justify-center p-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-2xl w-full"
      >
        {/* Logo and welcome */}
        <div className="text-center mb-12">
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.1, type: "spring" }}
            className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center shadow-glow-gold"
          >
            <span className="text-primary-foreground font-bold text-3xl">D</span>
          </motion.div>
          <h1 className="text-3xl font-bold text-foreground mb-3">
            Welcome to <span className="text-gradient-gold">DAAVFX</span>
          </h1>
          <p className="text-muted-foreground text-lg">
            Configure your trading engines with precision and elegance
          </p>
        </div>

        {/* Steps */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          {steps.map((step, index) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + index * 0.1 }}
              className="card-gradient-border rounded-lg p-4"
            >
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                  <step.icon className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <div className="text-xs text-muted-foreground mb-1">Step {index + 1}</div>
                  <h3 className="text-sm font-medium text-foreground mb-1">{step.title}</h3>
                  <p className="text-xs text-muted-foreground">{step.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Quick actions */}
        <div className="flex justify-center gap-4">
          <Button
            variant="outline"
            size="lg"
            onClick={onLoadSetfile}
            className="gap-2"
          >
            <Layers className="w-4 h-4" />
            Load Base Setfile
          </Button>
          <Button
            size="lg"
            onClick={onChooseEngine}
            className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90 glow-gold"
          >
            <Zap className="w-4 h-4" />
            Choose Engine
          </Button>
        </div>
      </motion.div>
    </div>
  );
}
