import { useState } from "react";
import { motion } from "framer-motion";
import {
  Grid3X3,
  Layers,
  ChevronRight,
  Check,
  X,
  Search,
  Filter,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { Platform } from "@/components/layout/TopBar";
import { GridBatchEditor } from "./GridBatchEditor";

interface BatchEditTabProps {
  platform: Platform;
}

const engines = ["Engine A", "Engine B", "Engine C"];
const groups = Array.from({ length: 15 }, (_, i) => `Group ${i + 1}`);
const logics = ["REPOWER", "SCALPER", "STOPPER", "STO", "SCA", "RPO"];

export function BatchEditTab({ platform }: BatchEditTabProps) {
  const [selectedEngines, setSelectedEngines] = useState<string[]>([]);
  const [selectedGroups, setSelectedGroups] = useState<string[]>([]);
  const [selectedLogics, setSelectedLogics] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState("");

  const toggleItem = (
    item: string,
    list: string[],
    setter: React.Dispatch<React.SetStateAction<string[]>>
  ) => {
    setter((prev) =>
      prev.includes(item) ? prev.filter((i) => i !== item) : [...prev, item]
    );
  };

  const selectAllEngines = () => setSelectedEngines(engines);
  const selectAllGroups = () => setSelectedGroups(groups.slice(1)); // Skip Group 1
  const selectAllLogics = () => setSelectedLogics(logics);

  const clearAll = () => {
    setSelectedEngines([]);
    setSelectedGroups([]);
    setSelectedLogics([]);
  };

  const totalSelected =
    selectedEngines.length + selectedGroups.length + selectedLogics.length;

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="px-5 py-4 border-b border-border/30">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded bg-primary/10">
              <Grid3X3 className="w-4 h-4 text-primary" />
            </div>
            <div>
              <h2 className="text-sm font-semibold">Batch Edit</h2>
              <p className="text-[10px] text-muted-foreground">
                Edit multiple inputs across selections
              </p>
            </div>
          </div>
          {totalSelected > 0 && (
            <Button variant="outline" size="sm" onClick={clearAll} className="h-7 text-xs gap-1">
              <X className="w-3 h-3" />
              Clear ({totalSelected})
            </Button>
          )}
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search engines, groups, logics..."
            className="pl-9 h-8 text-xs"
          />
        </div>
      </div>

      {/* Selection Area */}
      <div className="grid grid-cols-3 gap-4 p-5 border-b border-border/30">
        {/* Engines */}
        <SelectionColumn
          title="Engines"
          items={engines}
          selectedItems={selectedEngines}
          onToggle={(item) => toggleItem(item, selectedEngines, setSelectedEngines)}
          onSelectAll={selectAllEngines}
          onClear={() => setSelectedEngines([])}
          color="blue"
          searchQuery={searchQuery}
        />

        {/* Groups */}
        <SelectionColumn
          title="Groups"
          items={groups}
          selectedItems={selectedGroups}
          onToggle={(item) => {
            if (item === "Group 1") return; // Group 1 cannot be multi-selected
            toggleItem(item, selectedGroups, setSelectedGroups);
          }}
          onSelectAll={selectAllGroups}
          onClear={() => setSelectedGroups([])}
          color="emerald"
          searchQuery={searchQuery}
          disabledItems={["Group 1"]}
          disabledTooltip="Group 1 has unique inputs"
        />

        {/* Logics */}
        <SelectionColumn
          title="Logics"
          items={logics}
          selectedItems={selectedLogics}
          onToggle={(item) => toggleItem(item, selectedLogics, setSelectedLogics)}
          onSelectAll={selectAllLogics}
          onClear={() => setSelectedLogics([])}
          color="purple"
          searchQuery={searchQuery}
        />
      </div>

      {/* Grid Editor */}
      <ScrollArea className="flex-1 p-5">
        <GridBatchEditor
          platform={platform}
          selectedEngines={selectedEngines}
          selectedGroups={selectedGroups}
          selectedLogics={selectedLogics}
        />
      </ScrollArea>
    </div>
  );
}

interface SelectionColumnProps {
  title: string;
  items: string[];
  selectedItems: string[];
  onToggle: (item: string) => void;
  onSelectAll: () => void;
  onClear: () => void;
  color: "blue" | "emerald" | "purple";
  searchQuery: string;
  disabledItems?: string[];
  disabledTooltip?: string;
}

function SelectionColumn({
  title,
  items,
  selectedItems,
  onToggle,
  onSelectAll,
  onClear,
  color,
  searchQuery,
  disabledItems = [],
  disabledTooltip,
}: SelectionColumnProps) {
  const colorClasses = {
    blue: "bg-blue-500/10 text-blue-400 border-blue-500/30",
    emerald: "bg-emerald-500/10 text-emerald-400 border-emerald-500/30",
    purple: "bg-purple-500/10 text-purple-400 border-purple-500/30",
  };

  const filteredItems = items.filter((item) =>
    item.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="border border-border/40 rounded bg-card/20 overflow-hidden">
      {/* Header */}
      <div className="px-3 py-2 border-b border-border/30 flex items-center justify-between bg-muted/10">
        <span className="text-xs font-medium">{title}</span>
        <div className="flex gap-1">
          <button
            onClick={onSelectAll}
            className="text-[9px] px-1.5 py-0.5 rounded hover:bg-muted/30 text-muted-foreground"
          >
            All
          </button>
          <button
            onClick={onClear}
            className="text-[9px] px-1.5 py-0.5 rounded hover:bg-muted/30 text-muted-foreground"
          >
            Clear
          </button>
        </div>
      </div>

      {/* Items */}
      <div className="max-h-[140px] overflow-y-auto">
        {filteredItems.map((item) => {
          const isSelected = selectedItems.includes(item);
          const isDisabled = disabledItems.includes(item);

          return (
            <button
              key={item}
              onClick={() => !isDisabled && onToggle(item)}
              disabled={isDisabled}
              title={isDisabled ? disabledTooltip : undefined}
              className={cn(
                "w-full px-3 py-1.5 text-left text-xs flex items-center justify-between transition-colors",
                isSelected && !isDisabled && colorClasses[color],
                !isSelected && !isDisabled && "hover:bg-muted/20",
                isDisabled && "opacity-40 cursor-not-allowed"
              )}
            >
              {item}
              {isSelected && !isDisabled && <Check className="w-3 h-3" />}
            </button>
          );
        })}
      </div>

      {/* Footer */}
      <div className="px-3 py-1.5 border-t border-border/30 bg-muted/5">
        <span className="text-[10px] text-muted-foreground">
          {selectedItems.length} of {items.length} selected
        </span>
      </div>
    </div>
  );
}