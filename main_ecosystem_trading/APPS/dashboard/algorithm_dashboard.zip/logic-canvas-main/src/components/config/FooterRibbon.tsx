import { FileJson, FileText, FileCode, Clock, Undo, Redo, Columns, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { Platform } from "@/components/layout/TopBar";

interface FooterRibbonProps {
  platform: Platform;
}

const platformLabels: Record<Platform, string> = {
  mt4: "MetaTrader 4", mt5: "MetaTrader 5", python: "Python", c: "C", cpp: "C++", rust: "Rust",
};

const platformText: Record<Platform, string> = {
  mt4: "text-platform-mt4", mt5: "text-platform-mt5", python: "text-platform-python",
  c: "text-platform-c", cpp: "text-platform-cpp", rust: "text-platform-rust",
};

export function FooterRibbon({ platform }: FooterRibbonProps) {
  return (
    <footer className="h-9 border-t border-border bg-background-elevated flex items-center justify-between px-4 text-[10px]">
      <div className="flex items-center gap-1">
        <span className="text-muted-foreground mr-2">Export:</span>
        {[".set", "JSON", "YAML", "INI"].map((fmt) => (
          <Button key={fmt} variant="ghost" size="sm" className="h-6 px-2 text-[10px] text-muted-foreground hover:text-foreground">
            {fmt}
          </Button>
        ))}
      </div>

      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5 text-muted-foreground">
          <Clock className="w-3 h-3" />
          <span>Saved {new Date().toLocaleTimeString()}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <Check className="w-3 h-3 text-chart-3" />
          <span className="text-chart-3">Autosave</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-muted-foreground">Target:</span>
          <span className={cn("font-medium", platformText[platform])}>{platformLabels[platform]}</span>
        </div>
      </div>

      <div className="flex items-center gap-1">
        <Button variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground">
          <Undo className="w-3 h-3" />
        </Button>
        <Button variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground">
          <Redo className="w-3 h-3" />
        </Button>
        <div className="w-px h-4 bg-border mx-1" />
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-6 px-2 text-[10px] text-muted-foreground">
              <Columns className="w-3 h-3 mr-1" />Density
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-32">
            <DropdownMenuItem className="text-xs">Compact</DropdownMenuItem>
            <DropdownMenuItem className="text-xs">Comfortable</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </footer>
  );
}
