import { motion, AnimatePresence } from "framer-motion";
import { ChevronRight, Info, Star } from "lucide-react";
import { cn } from "@/lib/utils";
import { ConfigField } from "./ConfigField";
import { Platform } from "@/components/layout/TopBar";
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip";

interface LogicModuleProps {
  name: string;
  engine: string;
  expanded: boolean;
  onToggle: () => void;
  platform: Platform;
}

const logicMeta: Record<string, { color: string; description: string; cssClass: string }> = {
  POWER: { 
    color: "bg-[hsl(43_80%_50%)]", 
    description: "Main trading logic - core position management and entry signals",
    cssClass: "logic-power"
  },
  REPOWER: { 
    color: "bg-[hsl(210_60%_52%)]", 
    description: "Grid recovery system with dynamic lot sizing",
    cssClass: "logic-repower"
  },
  SCALPER: { 
    color: "bg-[hsl(152_55%_48%)]", 
    description: "Fast scalping entries with tight stops",
    cssClass: "logic-scalper"
  },
  STOPPER: { 
    color: "bg-[hsl(0_55%_52%)]", 
    description: "Risk management and position limiting",
    cssClass: "logic-stopper"
  },
  STO: { 
    color: "bg-[hsl(38_70%_52%)]", 
    description: "Stochastic oscillator signals",
    cssClass: "logic-sto"
  },
  SCA: { 
    color: "bg-[hsl(270_50%_58%)]", 
    description: "Scale-in position management",
    cssClass: "logic-sca"
  },
  RPO: { 
    color: "bg-[hsl(175_55%_48%)]", 
    description: "Recovery position optimization",
    cssClass: "logic-rpo"
  },
};

const logicFields: Record<string, Array<{ 
  id: string; 
  label: string; 
  value: string | number; 
  type: "number" | "toggle" | "text";
  unit?: string;
  description?: string;
  category?: string;
}>> = {
  POWER: [
    { id: "enabled", label: "Enable Logic", value: "ON", type: "toggle", description: "Activate POWER trading logic", category: "Core" },
    { id: "direction", label: "Direction", value: "BOTH", type: "text", description: "Trading direction (BUY/SELL/BOTH)", category: "Core" },
    { id: "initial_lot", label: "Initial Lot", value: 1.0, type: "number", unit: "lots", description: "Starting position size", category: "Lots" },
    { id: "max_lot", label: "Max Lot", value: 10.0, type: "number", unit: "lots", description: "Maximum position size", category: "Lots" },
    { id: "lot_multiplier", label: "Lot Multiplier", value: 1.5, type: "number", description: "Lot increase factor on recovery", category: "Lots" },
    { id: "tp", label: "Take Profit", value: 5.0, type: "number", unit: "pts", description: "Target profit in points", category: "TP/SL" },
    { id: "sl", label: "Stop Loss", value: 0, type: "number", unit: "pts", description: "Maximum loss in points (0=disabled)", category: "TP/SL" },
    { id: "virtual_sl", label: "Virtual SL", value: 50, type: "number", unit: "pts", description: "Hidden stop loss level", category: "TP/SL" },
    { id: "trail_start", label: "Trail Start", value: 3.0, type: "number", unit: "pts", category: "Trail" },
    { id: "trail_step", label: "Trail Step", value: 1.0, type: "number", unit: "pts", category: "Trail" },
    { id: "magic_number", label: "Magic Number", value: 12345, type: "number", description: "Unique order identifier", category: "System" },
    { id: "comment", label: "Order Comment", value: "POWER_A", type: "text", category: "System" },
    { id: "slippage", label: "Slippage", value: 3, type: "number", unit: "pts", category: "System" },
  ],
  REPOWER: [
    { id: "grid", label: "Grid Mode", value: "ON", type: "toggle", description: "Enable grid trading system", category: "Core" },
    { id: "initial_lot", label: "Initial Lot", value: 1.0, type: "number", unit: "lots", description: "Starting position size", category: "Lots" },
    { id: "last_lot", label: "Last Lot", value: 1.0, type: "number", unit: "lots", description: "Maximum position size", category: "Lots" },
    { id: "multiplier", label: "Lot Multiplier", value: 1.5, type: "number", description: "Lot increase factor", category: "Lots" },
    { id: "avg_close_logics", label: "Avg Close Logics", value: "-", type: "text", category: "Logic" },
    { id: "hedge_reference", label: "Hedge Reference", value: "-", type: "text", category: "Logic" },
    { id: "tp", label: "Take Profit", value: 5.3, type: "number", unit: "pts", description: "Target profit in points", category: "TP/SL" },
    { id: "sl", label: "Stop Loss", value: 4.0, type: "number", unit: "pts", description: "Maximum loss in points", category: "TP/SL" },
    { id: "trail_start", label: "Trail Start", value: 3.0, type: "number", unit: "pts", category: "Trail" },
    { id: "trail_step", label: "Trail Step", value: 1.0, type: "number", unit: "pts", category: "Trail" },
    { id: "start_level", label: "Start Level", value: 10, type: "number", description: "Grid start level", category: "Grid" },
    { id: "max_level", label: "Max Level", value: 20, type: "number", description: "Maximum grid levels", category: "Grid" },
  ],
  SCALPER: [
    { id: "grid", label: "Grid Mode", value: "OFF", type: "toggle", category: "Core" },
    { id: "initial_lot", label: "Initial Lot", value: 0.5, type: "number", unit: "lots", category: "Lots" },
    { id: "tp", label: "Take Profit", value: 3.5, type: "number", unit: "pts", category: "TP/SL" },
    { id: "sl", label: "Stop Loss", value: 2.0, type: "number", unit: "pts", category: "TP/SL" },
    { id: "spread_filter", label: "Spread Filter", value: 15, type: "number", unit: "pts", category: "Filter" },
    { id: "quick_close", label: "Quick Close", value: "ON", type: "toggle", category: "Core" },
  ],
  STOPPER: [
    { id: "enabled", label: "Enabled", value: "ON", type: "toggle", category: "Core" },
    { id: "max_loss", label: "Max Loss", value: 100, type: "number", unit: "$", category: "Limits" },
    { id: "daily_limit", label: "Daily Limit", value: 50, type: "number", unit: "$", category: "Limits" },
    { id: "weekly_limit", label: "Weekly Limit", value: 200, type: "number", unit: "$", category: "Limits" },
    { id: "equity_stop", label: "Equity Stop", value: "ON", type: "toggle", category: "Core" },
  ],
  STO: [
    { id: "period", label: "Period", value: 14, type: "number", category: "Settings" },
    { id: "overbought", label: "Overbought", value: 80, type: "number", category: "Levels" },
    { id: "oversold", label: "Oversold", value: 20, type: "number", category: "Levels" },
    { id: "smoothing", label: "Smoothing", value: 3, type: "number", category: "Settings" },
  ],
  SCA: [
    { id: "scale_factor", label: "Scale Factor", value: 1.5, type: "number", category: "Settings" },
    { id: "max_orders", label: "Max Orders", value: 5, type: "number", category: "Limits" },
    { id: "distance", label: "Distance", value: 10, type: "number", unit: "pts", category: "Settings" },
  ],
  RPO: [
    { id: "recovery_enabled", label: "Recovery", value: "ON", type: "toggle", category: "Core" },
    { id: "recovery_ratio", label: "Ratio", value: 2.0, type: "number", category: "Settings" },
    { id: "break_even", label: "Break Even", value: "ON", type: "toggle", category: "Core" },
  ],
};

export function LogicModule({ name, engine, expanded, onToggle, platform }: LogicModuleProps) {
  const fields = logicFields[name] || [];
  const meta = logicMeta[name] || { color: "bg-muted", description: "", cssClass: "" };
  const prefix = engine.replace("Engine ", "").toLowerCase();
  const filledCount = fields.filter(f => f.value !== "-" && f.value !== "").length;
  const isPowerLogic = name === "POWER";

  // Group fields by category
  const categories = Array.from(new Set(fields.map(f => f.category || "General")));

  return (
    <div className={cn(
      "rounded-lg border bg-background/40 overflow-hidden transition-all",
      expanded ? "border-border shadow-soft" : "border-border/50",
      isPowerLogic && expanded && "ring-1 ring-primary/20"
    )}>
      <button
        onClick={onToggle}
        className={cn(
          "w-full px-4 py-3 flex items-center justify-between transition-colors",
          expanded ? "bg-card/60" : "hover:bg-card/40"
        )}
      >
        <div className="flex items-center gap-3">
          <div className={cn("w-1 h-6 rounded-full", meta.color)} />
          <motion.div animate={{ rotate: expanded ? 90 : 0 }} transition={{ duration: 0.1 }}>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </motion.div>
          <span className="text-xs font-mono text-foreground flex items-center gap-2">
            <span className="text-muted-foreground">{prefix}/</span>
            <span className="font-semibold">{name}</span>
            {isPowerLogic && (
              <span className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-primary/10 text-primary text-[9px] font-medium">
                <Star className="w-2.5 h-2.5" />
                MAIN
              </span>
            )}
          </span>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Info className="w-3.5 h-3.5 text-muted-foreground/50 cursor-help hover:text-muted-foreground transition-colors" />
              </TooltipTrigger>
              <TooltipContent side="right" className="max-w-xs text-xs bg-popover border-border">
                {meta.description}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-24 h-1.5 bg-muted rounded-full overflow-hidden">
              <div 
                className={cn("h-full rounded-full transition-all", meta.color)} 
                style={{ width: `${(filledCount / fields.length) * 100}%`, opacity: 0.8 }} 
              />
            </div>
            <span className="text-[10px] text-muted-foreground font-mono w-12 text-right">
              {filledCount}/{fields.length}
            </span>
          </div>
        </div>
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: "auto" }}
            exit={{ height: 0 }}
            transition={{ duration: 0.12 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 pt-2 space-y-4">
              {categories.map((category) => {
                const categoryFields = fields.filter(f => (f.category || "General") === category);
                return (
                  <div key={category}>
                    <div className="flex items-center gap-2 mb-2">
                      <div className="text-[10px] text-muted-foreground/70 uppercase tracking-wider font-medium">
                        {category}
                      </div>
                      <div className="flex-1 h-px bg-border/30" />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      {categoryFields.map((field) => (
                        <ConfigField 
                          key={field.id} 
                          label={field.label} 
                          value={field.value} 
                          type={field.type}
                          unit={field.unit}
                          description={field.description}
                        />
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}