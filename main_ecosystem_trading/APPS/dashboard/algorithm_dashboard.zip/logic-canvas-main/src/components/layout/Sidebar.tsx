import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  ChevronRight,
  ChevronDown,
  Layers,
  FolderOpen,
  Zap,
  Grid3X3,
  Check,
  AlertCircle,
  Settings2,
  TableProperties,
  X,
  Sparkles,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { Platform } from "./TopBar";

const engines = ["Engine A", "Engine B", "Engine C"] as const;
const groups = Array.from({ length: 20 }, (_, i) => `Group ${i + 1}`);
const logics = ["POWER", "REPOWER", "SCALPER", "STOPPER", "STO", "SCA", "RPO"] as const;

export type ViewMode = "logics" | "general" | "batch";

interface SidebarProps {
  selectedEngines: string[];
  selectedGroups: string[];
  selectedLogics: string[];
  onSelectionChange: (type: "engines" | "groups" | "logics", items: string[]) => void;
  platform: Platform;
  viewMode: ViewMode;
  onViewModeChange: (mode: ViewMode) => void;
}

const platformBorder: Record<Platform, string> = {
  mt4: "border-l-platform-mt4/50",
  mt5: "border-l-platform-mt5/50",
  python: "border-l-platform-python/50",
  c: "border-l-platform-c/50",
  cpp: "border-l-platform-cpp/50",
  rust: "border-l-platform-rust/50",
};

const logicColors: Record<string, string> = {
  POWER: "bg-[hsl(43_80%_50%)]",
  REPOWER: "bg-[hsl(210_60%_52%)]",
  SCALPER: "bg-[hsl(152_55%_48%)]",
  STOPPER: "bg-[hsl(0_55%_52%)]",
  STO: "bg-[hsl(38_70%_52%)]",
  SCA: "bg-[hsl(270_50%_58%)]",
  RPO: "bg-[hsl(175_55%_48%)]",
};

export function Sidebar({
  selectedEngines,
  selectedGroups,
  selectedLogics,
  onSelectionChange,
  platform,
  viewMode,
  onViewModeChange,
}: SidebarProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedSections, setExpandedSections] = useState({
    engines: true,
    groups: true,
    logics: true,
    vault: false,
  });

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections((prev) => ({ ...prev, [section]: !prev[section] }));
  };

  const collapseAll = () => {
    setExpandedSections({ engines: false, groups: false, logics: false, vault: false });
  };

  const expandAll = () => {
    setExpandedSections({ engines: true, groups: true, logics: true, vault: true });
  };

  // Group 1 unique selection logic
  const hasGroup1Selected = selectedGroups.includes("Group 1");
  const hasOtherGroupsSelected = selectedGroups.some((g) => g !== "Group 1");

  const toggleItem = (type: "engines" | "groups" | "logics", item: string) => {
    if (type === "groups") {
      const isGroup1 = item === "Group 1";
      const current = selectedGroups;
      
      if (isGroup1) {
        if (current.includes("Group 1")) {
          onSelectionChange("groups", []);
        } else {
          onSelectionChange("groups", ["Group 1"]);
        }
      } else {
        const withoutGroup1 = current.filter((g) => g !== "Group 1");
        const updated = withoutGroup1.includes(item)
          ? withoutGroup1.filter((g) => g !== item)
          : [...withoutGroup1, item];
        onSelectionChange("groups", updated);
      }
      return;
    }

    const current = type === "engines" ? selectedEngines : selectedLogics;
    const updated = current.includes(item)
      ? current.filter((i) => i !== item)
      : [...current, item];
    onSelectionChange(type, updated);
  };

  const selectAll = (type: "engines" | "groups" | "logics") => {
    if (type === "groups") {
      onSelectionChange("groups", groups.filter((g) => g !== "Group 1"));
      return;
    }
    const items = type === "engines" ? [...engines] : [...logics];
    onSelectionChange(type, items);
  };

  // Filter items based on search
  const filteredEngines = useMemo(() => {
    if (!searchQuery) return [...engines];
    return engines.filter((e) => e.toLowerCase().includes(searchQuery.toLowerCase()));
  }, [searchQuery]);

  const filteredGroups = useMemo(() => {
    if (!searchQuery) return groups;
    return groups.filter((g) => g.toLowerCase().includes(searchQuery.toLowerCase()));
  }, [searchQuery]);

  const filteredLogics = useMemo(() => {
    if (!searchQuery) return [...logics];
    return logics.filter((l) => l.toLowerCase().includes(searchQuery.toLowerCase()));
  }, [searchQuery]);

  const hasSearchResults = filteredEngines.length > 0 || filteredGroups.length > 0 || filteredLogics.length > 0;

  return (
    <aside className={cn(
      "w-64 border-r border-border bg-sidebar flex flex-col border-l-2",
      platformBorder[platform]
    )}>
      {/* View Mode Toggle */}
      <div className="p-3 border-b border-border">
        <div className="flex rounded-lg bg-muted/40 p-1">
          <button
            onClick={() => onViewModeChange("logics")}
            className={cn(
              "flex-1 flex items-center justify-center gap-1.5 py-2 px-2 rounded-md text-[11px] font-medium transition-all",
              viewMode === "logics"
                ? "bg-background text-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            <Zap className="w-3.5 h-3.5" />
            Logics
          </button>
          <button
            onClick={() => onViewModeChange("general")}
            className={cn(
              "flex-1 flex items-center justify-center gap-1.5 py-2 px-2 rounded-md text-[11px] font-medium transition-all",
              viewMode === "general"
                ? "bg-background text-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            <Settings2 className="w-3.5 h-3.5" />
            General
          </button>
          <button
            onClick={() => onViewModeChange("batch")}
            className={cn(
              "flex-1 flex items-center justify-center gap-1.5 py-2 px-2 rounded-md text-[11px] font-medium transition-all",
              viewMode === "batch"
                ? "bg-background text-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            <TableProperties className="w-3.5 h-3.5" />
            Batch
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="p-3 border-b border-border">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search engines, groups, logics..."
            className="pl-9 pr-8 h-9 text-xs input-refined"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
        {searchQuery && (
          <div className="mt-2 text-[10px] text-muted-foreground">
            {hasSearchResults ? (
              <span>{filteredEngines.length + filteredGroups.length + filteredLogics.length} results</span>
            ) : (
              <span className="text-destructive">No results found</span>
            )}
          </div>
        )}
      </div>

      {/* Collapse/Expand All */}
      <div className="px-3 py-2 border-b border-border/50 flex items-center justify-between">
        <span className="text-[10px] text-muted-foreground font-medium uppercase tracking-wider">Navigation</span>
        <div className="flex gap-1">
          <button
            onClick={expandAll}
            className="text-[10px] text-muted-foreground hover:text-foreground px-2 py-1 rounded hover:bg-muted/40 transition-colors"
          >
            Expand
          </button>
          <button
            onClick={collapseAll}
            className="text-[10px] text-muted-foreground hover:text-foreground px-2 py-1 rounded hover:bg-muted/40 transition-colors"
          >
            Collapse
          </button>
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-3 space-y-1">
          <Section
            title="Engines"
            icon={<Grid3X3 className="w-3.5 h-3.5" />}
            expanded={expandedSections.engines}
            onToggle={() => toggleSection("engines")}
            onSelectAll={() => selectAll("engines")}
            count={`${selectedEngines.length}/${engines.length}`}
          >
            {filteredEngines.map((engine) => (
              <TreeItem
                key={engine}
                label={engine}
                selected={selectedEngines.includes(engine)}
                onToggle={() => toggleItem("engines", engine)}
                highlight={searchQuery}
              />
            ))}
          </Section>

          <Section
            title="Groups"
            icon={<FolderOpen className="w-3.5 h-3.5" />}
            expanded={expandedSections.groups}
            onToggle={() => toggleSection("groups")}
            onSelectAll={() => selectAll("groups")}
            count={`${selectedGroups.length}/${groups.length}`}
            warning={hasGroup1Selected && hasOtherGroupsSelected ? "Invalid selection" : undefined}
          >
            <div className="max-h-56 overflow-y-auto space-y-0.5">
              {/* Group 1 - Special */}
              {filteredGroups.includes("Group 1") && (
                <TreeItem
                  label="Group 1"
                  selected={selectedGroups.includes("Group 1")}
                  onToggle={() => toggleItem("groups", "Group 1")}
                  badge="main"
                  disabled={hasOtherGroupsSelected}
                  highlight={searchQuery}
                  badgeColor="bg-primary/20 text-primary"
                />
              )}
              
              {/* Separator */}
              {filteredGroups.includes("Group 1") && filteredGroups.length > 1 && (
                <div className="flex items-center gap-2 py-2 px-2">
                  <div className="flex-1 h-px bg-border/50" />
                  <span className="text-[9px] text-muted-foreground/60 font-medium">GROUPS 2-20</span>
                  <div className="flex-1 h-px bg-border/50" />
                </div>
              )}

              {/* Groups 2-20 */}
              {filteredGroups.filter(g => g !== "Group 1").map((group) => (
                <TreeItem
                  key={group}
                  label={group}
                  selected={selectedGroups.includes(group)}
                  onToggle={() => toggleItem("groups", group)}
                  disabled={hasGroup1Selected}
                  highlight={searchQuery}
                />
              ))}
            </div>
          </Section>

          {viewMode === "logics" && (
            <Section
              title="Logics"
              icon={<Zap className="w-3.5 h-3.5" />}
              expanded={expandedSections.logics}
              onToggle={() => toggleSection("logics")}
              onSelectAll={() => selectAll("logics")}
              count={`${selectedLogics.length}/${logics.length}`}
            >
              {filteredLogics.map((logic) => (
                <TreeItem
                  key={logic}
                  label={logic}
                  selected={selectedLogics.includes(logic)}
                  onToggle={() => toggleItem("logics", logic)}
                  mono
                  highlight={searchQuery}
                  indicator={logicColors[logic]}
                  badge={logic === "POWER" ? "main" : undefined}
                  badgeColor={logic === "POWER" ? "bg-primary/20 text-primary" : undefined}
                />
              ))}
            </Section>
          )}

          <Section
            title="Vault"
            icon={<Layers className="w-3.5 h-3.5" />}
            expanded={expandedSections.vault}
            onToggle={() => toggleSection("vault")}
            muted
          >
            <div className="py-4 text-center text-xs text-muted-foreground/60">
              No saved configurations
            </div>
          </Section>
        </div>
      </ScrollArea>

      {/* Selection Summary */}
      {(selectedEngines.length > 1 || selectedGroups.length > 1 || selectedLogics.length > 1) && (
        <div className="p-3 border-t border-border bg-muted/20">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-3 h-3 text-primary" />
            <span className="text-[10px] text-foreground font-medium">Multi-Edit Mode</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {selectedEngines.length > 1 && (
              <span className="px-2 py-1 rounded-md bg-accent/15 text-accent text-[10px] font-medium">
                {selectedEngines.length} engines
              </span>
            )}
            {selectedGroups.length > 1 && (
              <span className="px-2 py-1 rounded-md bg-success/15 text-success text-[10px] font-medium">
                {selectedGroups.length} groups
              </span>
            )}
            {selectedLogics.length > 1 && (
              <span className="px-2 py-1 rounded-md bg-primary/15 text-primary text-[10px] font-medium">
                {selectedLogics.length} logics
              </span>
            )}
          </div>
        </div>
      )}
    </aside>
  );
}

interface SectionProps {
  title: string;
  icon: React.ReactNode;
  expanded: boolean;
  onToggle: () => void;
  onSelectAll?: () => void;
  count?: string;
  muted?: boolean;
  warning?: string;
  children: React.ReactNode;
}

function Section({ title, icon, expanded, onToggle, onSelectAll, count, muted, warning, children }: SectionProps) {
  return (
    <div className="rounded-lg overflow-hidden">
      <button
        onClick={onToggle}
        className={cn(
          "w-full flex items-center gap-2 px-3 py-2.5 text-xs font-medium transition-colors rounded-lg",
          expanded ? "bg-muted/40" : "hover:bg-muted/30",
          muted && "text-muted-foreground"
        )}
      >
        {expanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
        <span className="text-muted-foreground">{icon}</span>
        <span>{title}</span>
        {warning && <AlertCircle className="w-3 h-3 text-warning ml-1" />}
        {count && <span className="ml-auto text-[10px] text-muted-foreground font-mono">{count}</span>}
        {onSelectAll && (
          <button
            onClick={(e) => { e.stopPropagation(); onSelectAll(); }}
            className="text-[10px] text-muted-foreground hover:text-primary ml-1 px-1.5 py-0.5 rounded hover:bg-primary/10 transition-colors"
          >
            all
          </button>
        )}
      </button>
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="overflow-hidden"
          >
            <div className="pl-3 py-1.5">{children}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

interface TreeItemProps {
  label: string;
  selected: boolean;
  onToggle: () => void;
  mono?: boolean;
  badge?: string;
  badgeColor?: string;
  disabled?: boolean;
  highlight?: string;
  indicator?: string;
}

function TreeItem({ label, selected, onToggle, mono, badge, badgeColor, disabled, highlight, indicator }: TreeItemProps) {
  const highlightText = (text: string, query: string) => {
    if (!query) return text;
    const parts = text.split(new RegExp(`(${query})`, 'gi'));
    return parts.map((part, i) => 
      part.toLowerCase() === query.toLowerCase() 
        ? <span key={i} className="search-match">{part}</span>
        : part
    );
  };

  return (
    <button
      onClick={disabled ? undefined : onToggle}
      disabled={disabled}
      className={cn(
        "w-full flex items-center gap-2.5 py-2 px-2.5 text-xs rounded-md transition-all",
        disabled && "opacity-40 cursor-not-allowed",
        !disabled && selected && "bg-primary/10 text-foreground border border-primary/20",
        !disabled && !selected && "text-muted-foreground hover:text-foreground hover:bg-muted/30 border border-transparent"
      )}
    >
      {indicator && <div className={cn("w-1 h-4 rounded-full", indicator)} />}
      <div className={cn(
        "w-4 h-4 rounded border flex items-center justify-center transition-all",
        selected ? "bg-primary border-primary" : "border-border hover:border-muted-foreground/50"
      )}>
        {selected && <Check className="w-3 h-3 text-primary-foreground" />}
      </div>
      <span className={cn(mono && "font-mono")}>{highlightText(label, highlight || "")}</span>
      {badge && (
        <span className={cn(
          "ml-auto text-[9px] px-1.5 py-0.5 rounded-md font-medium",
          badgeColor || "bg-muted text-muted-foreground"
        )}>
          {badge}
        </span>
      )}
    </button>
  );
}