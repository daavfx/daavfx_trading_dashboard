import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Send, 
  Bot, 
  User, 
  Command, 
  ChevronLeft, 
  ChevronRight, 
  ArrowRight, 
  Paperclip, 
  Image, 
  Check, 
  X,
  Undo2,
  FileText,
  Sparkles
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

interface ConfigChange {
  field: string;
  from: string | number;
  to: string | number;
  targets: string[];
  reason?: string;
}

interface Message {
  id: string;
  type: "bot" | "user";
  content: string;
  timestamp: Date;
  changes?: ConfigChange[];
  attachment?: { name: string; type: "file" | "image"; size?: string };
}

const initialMessages: Message[] = [
  {
    id: "1",
    type: "bot",
    content: "DAAVFX Assistant ready. I can modify configurations, explain settings, and help optimize your trading setup. Try: \"Set Power A TP to 5.5\" or \"Randomize lots for Group 2\"",
    timestamp: new Date(),
  },
];

const sampleChanges: ConfigChange[] = [
  { field: "tp", from: 5.0, to: 5.5, targets: ["Engine A", "POWER", "Group 1"], reason: "Increased TP by 10% for better profit capture" },
  { field: "sl", from: 0, to: 10, targets: ["Engine A", "POWER", "Group 1"], reason: "Added protective stop loss" },
];

export function ChatPanel() {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState("");
  const [collapsed, setCollapsed] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [pendingChanges, setPendingChanges] = useState<ConfigChange[] | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;
    
    const newMsg: Message = { 
      id: Date.now().toString(), 
      type: "user", 
      content: input, 
      timestamp: new Date() 
    };
    setMessages((prev) => [...prev, newMsg]);
    setInput("");
    setIsTyping(true);
    
    // Simulate AI response with config changes
    setTimeout(() => {
      setIsTyping(false);
      const hasConfigCommand = /set|change|modify|update|random|increase|decrease/i.test(input);
      
      const response: Message = {
        id: (Date.now() + 1).toString(),
        type: "bot",
        content: hasConfigCommand 
          ? "I'll make these changes to your configuration. Review the diff below:"
          : "I understand. Let me help you with that.",
        timestamp: new Date(),
        changes: hasConfigCommand ? sampleChanges : undefined,
      };
      setMessages((prev) => [...prev, response]);
      if (hasConfigCommand) {
        setPendingChanges(sampleChanges);
      }
    }, 1200);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const isImage = file.type.startsWith("image/");
    const newMsg: Message = {
      id: Date.now().toString(),
      type: "user",
      content: `Uploaded ${isImage ? "image" : "file"}: ${file.name}`,
      timestamp: new Date(),
      attachment: { 
        name: file.name, 
        type: isImage ? "image" : "file",
        size: `${(file.size / 1024).toFixed(1)} KB`
      },
    };
    setMessages((prev) => [...prev, newMsg]);

    // Simulate bot response
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      const response: Message = {
        id: (Date.now() + 1).toString(),
        type: "bot",
        content: isImage 
          ? "I've received your image. I can analyze it for trading patterns or use it as reference. What would you like me to do?"
          : `I've received "${file.name}". I can parse this file and import configurations. Shall I proceed?`,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, response]);
    }, 800);
  };

  const applyChanges = () => {
    console.log("Applied changes:", pendingChanges);
    setPendingChanges(null);
    const confirmMsg: Message = {
      id: Date.now().toString(),
      type: "bot",
      content: "✓ Changes applied successfully. The configuration has been updated.",
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, confirmMsg]);
  };

  const rejectChanges = () => {
    setPendingChanges(null);
    const rejectMsg: Message = {
      id: Date.now().toString(),
      type: "bot",
      content: "Changes discarded. No modifications were made.",
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, rejectMsg]);
  };

  if (collapsed) {
    return (
      <aside className="w-12 border-l border-border bg-background-elevated flex flex-col items-center py-4">
        <button 
          onClick={() => setCollapsed(false)} 
          className="p-2 text-muted-foreground hover:text-foreground rounded-md hover:bg-muted/30 transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
        <div className="mt-4 writing-mode-vertical text-[10px] text-muted-foreground tracking-widest uppercase font-medium">
          Assistant
        </div>
        <div className="mt-2">
          <Sparkles className="w-3.5 h-3.5 text-primary" />
        </div>
      </aside>
    );
  }

  return (
    <aside className="w-80 border-l border-border bg-background-elevated flex flex-col">
      {/* Header */}
      <div className="h-12 border-b border-border flex items-center justify-between px-4">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded-md bg-primary/10">
            <Bot className="w-4 h-4 text-primary" />
          </div>
          <div>
            <span className="text-xs font-semibold text-foreground">AI Assistant</span>
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" />
              <span className="text-[10px] text-muted-foreground">Online</span>
            </div>
          </div>
        </div>
        <button 
          onClick={() => setCollapsed(true)} 
          className="p-1.5 text-muted-foreground hover:text-foreground rounded-md hover:bg-muted/30 transition-colors"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1" ref={scrollRef}>
        <div className="p-4 space-y-4">
          <AnimatePresence>
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className={cn("flex gap-3", msg.type === "user" && "flex-row-reverse")}
              >
                <div className={cn(
                  "w-7 h-7 rounded-lg flex items-center justify-center shrink-0",
                  msg.type === "bot" ? "bg-primary/10" : "bg-accent/10"
                )}>
                  {msg.type === "bot" 
                    ? <Bot className="w-3.5 h-3.5 text-primary" /> 
                    : <User className="w-3.5 h-3.5 text-accent" />
                  }
                </div>
                <div className="flex-1 space-y-2 max-w-[85%]">
                  {/* Attachment preview */}
                  {msg.attachment && (
                    <div className="p-2.5 rounded-lg bg-muted/30 border border-border/50 flex items-center gap-2">
                      {msg.attachment.type === "image" ? (
                        <Image className="w-4 h-4 text-accent" />
                      ) : (
                        <FileText className="w-4 h-4 text-muted-foreground" />
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="text-xs text-foreground truncate">{msg.attachment.name}</div>
                        {msg.attachment.size && (
                          <div className="text-[10px] text-muted-foreground">{msg.attachment.size}</div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Message content */}
                  <div className={cn(
                    "px-3.5 py-2.5 rounded-lg text-xs leading-relaxed",
                    msg.type === "bot" 
                      ? "bg-card border border-border/60 text-foreground" 
                      : "bg-accent/10 border border-accent/20 text-foreground"
                  )}>
                    {msg.content}
                  </div>

                  {/* Config changes diff */}
                  {msg.changes && (
                    <div className="p-3 rounded-lg bg-background border border-border/60 space-y-3">
                      <div className="flex items-center gap-2 text-[10px] text-muted-foreground font-medium uppercase tracking-wider">
                        <Sparkles className="w-3 h-3 text-primary" />
                        Configuration Changes
                      </div>
                      
                      {msg.changes.map((change, idx) => (
                        <div key={idx} className="p-2.5 rounded-md bg-muted/20 border border-border/30 space-y-1.5">
                          <div className="flex items-center gap-2 text-[11px]">
                            <span className="font-mono text-muted-foreground">{change.field}</span>
                            <span className="text-destructive/80 line-through font-mono">{change.from}</span>
                            <ArrowRight className="w-3 h-3 text-muted-foreground" />
                            <span className="text-success font-semibold font-mono">{change.to}</span>
                          </div>
                          <div className="flex flex-wrap gap-1">
                            {change.targets.map((t) => (
                              <span key={t} className="text-[9px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                                {t}
                              </span>
                            ))}
                          </div>
                          {change.reason && (
                            <div className="text-[10px] text-muted-foreground/80 italic">
                              {change.reason}
                            </div>
                          )}
                        </div>
                      ))}

                      {pendingChanges && (
                        <div className="flex gap-2 pt-2">
                          <Button 
                            size="sm" 
                            className="h-7 text-[11px] flex-1 btn-gold"
                            onClick={applyChanges}
                          >
                            <Check className="w-3 h-3 mr-1" />
                            Apply
                          </Button>
                          <Button 
                            size="sm" 
                            variant="ghost" 
                            className="h-7 text-[11px] text-muted-foreground"
                            onClick={rejectChanges}
                          >
                            <X className="w-3 h-3 mr-1" />
                            Discard
                          </Button>
                          <Button 
                            size="sm" 
                            variant="ghost" 
                            className="h-7 text-[11px] text-muted-foreground"
                          >
                            <Undo2 className="w-3 h-3" />
                          </Button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          
          {isTyping && (
            <div className="flex gap-3">
              <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center">
                <Bot className="w-3.5 h-3.5 text-primary" />
              </div>
              <div className="px-3.5 py-2.5 rounded-lg bg-card border border-border/60">
                <div className="flex gap-1.5">
                  {[0, 1, 2].map((i) => (
                    <span 
                      key={i} 
                      className="w-2 h-2 rounded-full bg-muted-foreground/40 animate-pulse" 
                      style={{ animationDelay: `${i * 150}ms` }} 
                    />
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Input */}
      <div className="p-4 border-t border-border">
        <div className="relative">
          <Command className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            placeholder="Type a command or question..."
            className="pl-10 pr-20 h-10 text-xs input-refined"
          />
          <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
            <input
              type="file"
              ref={fileInputRef}
              className="hidden"
              onChange={handleFileUpload}
              accept="image/*,.txt,.json,.set,.yaml,.yml,.csv"
            />
            <Button
              size="icon"
              variant="ghost"
              className="h-7 w-7 text-muted-foreground hover:text-foreground"
              onClick={() => fileInputRef.current?.click()}
            >
              <Paperclip className="w-3.5 h-3.5" />
            </Button>
            <Button
              size="icon"
              onClick={handleSend}
              disabled={!input.trim()}
              className="h-7 w-7 btn-gold"
            >
              <Send className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
        <div className="mt-2 flex items-center gap-2 text-[10px] text-muted-foreground/60">
          <span>Try:</span>
          <button 
            className="hover:text-muted-foreground transition-colors"
            onClick={() => setInput("Set Power A TP to 5.5 pts")}
          >
            "Set Power A TP to 5.5"
          </button>
          <span>·</span>
          <button 
            className="hover:text-muted-foreground transition-colors"
            onClick={() => setInput("Randomize lots for Group 2")}
          >
            "Randomize lots"
          </button>
        </div>
      </div>
    </aside>
  );
}