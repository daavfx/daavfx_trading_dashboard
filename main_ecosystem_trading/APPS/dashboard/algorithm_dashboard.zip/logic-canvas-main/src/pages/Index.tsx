import { useState } from "react";
import { TopBar, Platform } from "@/components/layout/TopBar";
import { Sidebar, ViewMode } from "@/components/layout/Sidebar";
import { ChatPanel } from "@/components/layout/ChatPanel";
import { BatchEditPanel } from "@/components/config/BatchEditPanel";
import { EngineCard } from "@/components/config/EngineCard";
import { GeneralCategories } from "@/components/config/GeneralCategories";
import { MultiEditIndicator } from "@/components/config/MultiEditIndicator";
import { EmptyState } from "@/components/config/EmptyState";
import { FooterRibbon } from "@/components/config/FooterRibbon";
import { VaultSaveModal } from "@/components/config/VaultSaveModal";
import { SettingsDrawer } from "@/components/config/SettingsDrawer";
import { BatchEditTab } from "@/components/config/BatchEditTab";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

const engineConfigs = [
  { engine: "Engine A", tradingType: "Reverse Trading" },
  { engine: "Engine B", tradingType: "Hedge Trading" },
  { engine: "Engine C", tradingType: "Direct Trading" },
];

const canvasClasses: Record<Platform, string> = {
  mt4: "canvas-mt4", mt5: "canvas-mt5", python: "canvas-python",
  c: "canvas-c", cpp: "canvas-cpp", rust: "canvas-rust",
};

export default function Index() {
  const [selectedEngines, setSelectedEngines] = useState<string[]>(["Engine A"]);
  const [selectedGroups, setSelectedGroups] = useState<string[]>(["Group 1"]);
  const [selectedLogics, setSelectedLogics] = useState<string[]>(["REPOWER"]);
  const [vaultModalOpen, setVaultModalOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [hasStarted, setHasStarted] = useState(true);
  const [platform, setPlatform] = useState<Platform>("mt5");
  const [viewMode, setViewMode] = useState<ViewMode>("logics");

  const handleSelectionChange = (type: "engines" | "groups" | "logics", items: string[]) => {
    if (type === "engines") setSelectedEngines(items);
    if (type === "groups") setSelectedGroups(items);
    if (type === "logics") setSelectedLogics(items);
  };

  const handleVaultSave = (data: { name: string; category: string; strategyType: "buy" | "sell" | "both"; tags: string[]; comments: string }) => {
    console.log("Saving to vault:", data);
  };

  const clearSelection = () => {
    setSelectedEngines([]);
    setSelectedGroups([]);
    setSelectedLogics([]);
  };

  const isGroup1Mode = selectedGroups.includes("Group 1") && selectedGroups.length === 1;
  const isMultiEdit = selectedEngines.length > 1 || selectedGroups.length > 1 || selectedLogics.length > 1;

  return (
    <div className="h-screen flex flex-col bg-background">
      <TopBar onSaveToVault={() => setVaultModalOpen(true)} platform={platform} onPlatformChange={setPlatform} onOpenSettings={() => setSettingsOpen(true)} />
      
      <div className="flex-1 flex overflow-hidden">
        <Sidebar
          selectedEngines={selectedEngines}
          selectedGroups={selectedGroups}
          selectedLogics={selectedLogics}
          onSelectionChange={handleSelectionChange}
          platform={platform}
          viewMode={viewMode}
          onViewModeChange={setViewMode}
        />

        {hasStarted ? (
          <main className={cn("flex-1 flex flex-col overflow-hidden transition-colors duration-300", canvasClasses[platform])}>
            <ScrollArea className="flex-1">
              <div className="p-5 max-w-4xl">
                {/* Multi-Edit Indicator */}
                {isMultiEdit && (
                  <MultiEditIndicator
                    selectedEngines={selectedEngines}
                    selectedGroups={selectedGroups}
                    selectedLogics={selectedLogics}
                    isGroup1Mode={isGroup1Mode}
                    onClearSelection={clearSelection}
                  />
                )}

                <BatchEditPanel
                  selectedCount={{ 
                    engines: selectedEngines.length, 
                    groups: selectedGroups.length, 
                    logics: selectedLogics.length 
                  }}
                  platform={platform}
                  onClearEngines={() => setSelectedEngines([])}
                  onClearGroups={() => setSelectedGroups([])}
                  onClearLogics={() => setSelectedLogics([])}
                />

                {viewMode === "logics" && (
                  <div className="space-y-3 mt-4">
                    {engineConfigs.map((config, idx) => (
                      <EngineCard
                        key={`${config.engine}-${idx}`}
                        engine={config.engine}
                        tradingType={config.tradingType}
                        groups={selectedGroups}
                        platform={platform}
                      />
                    ))}
                  </div>
                )}
                
                {viewMode === "general" && (
                  <div className="mt-4">
                    <GeneralCategories platform={platform} />
                  </div>
                )}

                {viewMode === "batch" && (
                  <div className="mt-4">
                    <BatchEditTab platform={platform} />
                  </div>
                )}
              </div>
            </ScrollArea>
          </main>
        ) : (
          <EmptyState onLoadSetfile={() => setHasStarted(true)} onChooseEngine={() => setHasStarted(true)} />
        )}

        <ChatPanel />
      </div>

      <FooterRibbon platform={platform} />
      <VaultSaveModal open={vaultModalOpen} onClose={() => setVaultModalOpen(false)} onSave={handleVaultSave} />
      <SettingsDrawer open={settingsOpen} onClose={() => setSettingsOpen(false)} />
    </div>
  );
}
